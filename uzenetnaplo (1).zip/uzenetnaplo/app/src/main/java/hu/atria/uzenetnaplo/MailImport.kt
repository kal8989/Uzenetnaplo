package hu.atria.uzenetnaplo

import android.content.Context
import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Levélarchívum (mbox) beolvasása a naplómappába, havi `mail_<címke>_ÉÉÉÉ-HH.txt` fájlokba.
 * Forrás lehet Thunderbird-export, Google Takeout vagy bármely mbox-ot adó eszköz.
 * Ugyanazzal a címkével megismételve felülírja a korábbi importot.
 */
object MailImport {

    class Message(val ts: Long, val who: String, val subject: String, val body: String)

    class Result(val count: Int, val months: Int, val skipped: Int)

    private val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    private val month = SimpleDateFormat("yyyy-MM", Locale.US)

    fun slug(s: String): String {
        val n = MsgIndex.norm(s).map { if (it.isLetterOrDigit()) it else '-' }.joinToString("")
        return n.trim('-').replace(Regex("-+"), "-").take(20).ifEmpty { "mail" }
    }

    /** Egy nyers RFC822-levél feldolgozása. [mine]: a saját címek, ezekből lesz „Én → …”. */
    fun parseMessage(raw: String, mine: Collection<String>, maxBody: Int): Message? {
        val sep = blankLine(raw)
        val header = if (sep > 0) raw.substring(0, sep) else raw
        val bodyRaw = if (sep > 0) raw.substring(sep) else ""
        val h = Mime.headers(header)
        val ts = ImapClient.parseDate(h["date"]) ?: return null
        if (ts < 788_918_400_000L) return null   // 1995 előtti dátum: hibás fejléc
        val from = Mime.decodeHeader(h["from"].orEmpty())
        val to = Mime.decodeHeader(h["to"].orEmpty()).ifBlank { Mime.decodeHeader(h["cc"].orEmpty()) }
        val subject = Mime.decodeHeader(h["subject"].orEmpty()).ifBlank { "(tárgy nélkül)" }
        val sentByMe = mine.any { it.isNotBlank() && from.contains(it, true) }
        val who = if (sentByMe) "Én → ${to.take(120)}" else from
        val body = try {
            Mime.trimQuoted(Mime.bodyText(header, bodyRaw)).take(maxBody)
        } catch (e: Exception) {
            ""
        }
        return Message(ts, who, subject, body)
    }

    private fun blankLine(s: String): Int {
        val a = s.indexOf("\r\n\r\n")
        if (a >= 0) return a + 4
        val b = s.indexOf("\n\n")
        return if (b >= 0) b + 2 else -1
    }

    /** Egy naplósor a levélből. */
    fun line(m: Message, label: String): String = listOf(
        stamp.format(Date(m.ts)), label, "mail", m.who,
        (m.subject + "\n" + m.body).trim(),
    ).joinToString("\t") { NotificationLogService.clean(it) }

    /**
     * Blokkoló import. [progress]: állapotszöveg.
     */
    fun importMbox(
        ctx: Context,
        uri: Uri,
        label: String,
        source: String,
        mine: Collection<String>,
        maxBody: Int = 3000,
        progress: ((String) -> Unit)? = null,
    ): Result {
        val app = ctx.applicationContext
        if (LogWriter.treeUri(app) == null) throw IllegalStateException("Nincs kiválasztva naplómappa.")
        // A címke a megjelenítésé, a forrásfájl neve a fájlok elkülönítéséé: így a Beérkezett és az
        // Elküldött mappa egy címke alatt, mégis külön fájlokban él, és az újraimport felülírja magát.
        val slug = slug(label) + "-" + slug(source)
        val buffers = HashMap<String, StringBuilder>()
        val opened = HashSet<String>()
        var count = 0
        var skipped = 0

        fun name(mon: String) = "mail_${slug}_$mon.txt"

        fun flush(mon: String) {
            val sb = buffers[mon] ?: return
            if (sb.isEmpty()) return
            val n = name(mon)
            val ok = if (opened.add(n)) LogWriter.writeWhole(app, n, sb.toString(), "text/plain")
            else LogWriter.appendTo(app, n, sb.toString())
            if (!ok) throw IllegalStateException("A $n fájl nem írható.")
            sb.setLength(0)
        }

        fun handle(raw: String) {
            if (raw.isBlank()) return
            val m = parseMessage(raw, mine, maxBody)
            if (m == null) { skipped++; return }
            val mon = month.format(Date(m.ts))
            val sb = buffers.getOrPut(mon) { StringBuilder() }
            sb.append(line(m, label)).append('\n')
            count++
            if (sb.length > 200_000) flush(mon)
            if (count % 200 == 0) progress?.invoke("Beolvasva: $count levél…")
        }

        app.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.ISO_8859_1)?.use { r ->
            splitMbox(r) { handle(it) }
        } ?: throw IllegalStateException("A fájl nem olvasható.")

        buffers.keys.toList().forEach { flush(it) }
        return Result(count, opened.size, skipped)
    }

    /** Az mbox szétbontása levelekre, soronként olvasva (nagy fájlhoz is). */
    fun splitMbox(r: java.io.BufferedReader, onMessage: (String) -> Unit) {
        val cur = StringBuilder()
        var started = false
        var prevBlank = true   // a szabvány szerint az elválasztó előtt üres sor áll
        while (true) {
            val l = r.readLine() ?: break
            val blank = l.isBlank()
            if (isSeparator(l) && (prevBlank || !started)) {
                prevBlank = false
                if (started) onMessage(cur.toString())
                cur.setLength(0)
                started = true
                continue
            }
            prevBlank = blank
            if (!started) continue   // a fájl eleji szemét
            // az mbox a törzsbeli „From ” sorokat „>From ”-ra cseréli
            cur.append(if (l.startsWith(">From ")) l.substring(1) else l).append('\n')
            if (cur.length > 4_000_000) cur.setLength(2_000_000)   // kifutott levél elvágása
        }
        if (started) onMessage(cur.toString())
    }

    /**
     * mbox-elválasztó: „From <feladó> <nap hó nap óra:perc:mp év>”.
     * A dátumrészt is megköveteli, különben egy törzsbeli „From …” sor új levelet nyitna.
     */
    private val SEP = Regex(
        """^From\s+\S+\s+(Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s+""" +
            """(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}\s+\d{1,2}:\d{2}(:\d{2})?\s+\d{4}"""
    )

    fun isSeparator(line: String): Boolean = SEP.containsMatchIn(line)
}
