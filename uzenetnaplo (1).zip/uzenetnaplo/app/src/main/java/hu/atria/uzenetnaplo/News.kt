package hu.atria.uzenetnaplo

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NewsItem(
    val source: String, val title: String, val link: String,
    val ts: Long, val desc: String, val image: String = "",
)

/** Hírösszeállítás RSS-csatornákból, óránként a háttérben. */
object News {
    const val ACTION = "hu.atria.uzenetnaplo.NEWS"
    private const val MAX_IMAGES = 14

    val DEFAULT_FEEDS = """
        Telex|https://telex.hu/rss
        444|https://444.hu/feed
        Index|https://index.hu/24ora/rss/
        24.hu|https://24.hu/feed/
        Portfolio|https://www.portfolio.hu/rss/all.xml
    """.trimIndent()

    private val SPORT = Regex("(^|[/.])sport|futball|foci|kezilabda|kézilabda|olimpi|bajnoks|forma-?1|f1/", RegexOption.IGNORE_CASE)

    fun feeds(ctx: Context): List<Pair<String, String>> =
        Prefs.newsFeeds(ctx).lines().mapNotNull { l ->
            val t = l.trim()
            if (t.isEmpty() || !t.contains('|')) null
            else t.substringBefore('|').trim() to t.substringAfter('|').trim()
        }

    private fun digestFile(ctx: Context) = File(ctx.filesDir, "news.md")

    fun digest(ctx: Context): String =
        try { digestFile(ctx).takeIf { it.exists() }?.readText().orEmpty() } catch (e: Exception) { "" }

    // ---------------- RSS ----------------

    private fun fetchFeed(name: String, url: String): List<NewsItem> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15_000
            c.readTimeout = 25_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "Uzenetnaplo/1.0")
            c.setRequestProperty("Accept", "application/rss+xml, application/xml, text/xml, */*")
            if (c.responseCode != 200) throw java.io.IOException("HTTP ${c.responseCode}")
            val p = Xml.newPullParser()
            p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            p.setInput(c.inputStream, null)
            val out = ArrayList<NewsItem>()
            var title = ""; var link = ""; var desc = ""; var date = ""; var cat = ""; var img = ""
            var inItem = false
            var tag = ""
            while (p.next() != XmlPullParser.END_DOCUMENT) {
                when (p.eventType) {
                    XmlPullParser.START_TAG -> {
                        tag = p.name.lowercase(Locale.US)
                        if (tag == "item" || tag == "entry") {
                            inItem = true; title = ""; link = ""; desc = ""; date = ""; cat = ""; img = ""
                        } else if (inItem && tag == "link") {
                            p.getAttributeValue(null, "href")?.let { link = it }
                        } else if (inItem && img.isBlank() &&
                            (tag == "enclosure" || tag.endsWith("content") || tag.endsWith("thumbnail"))
                        ) {
                            val u = p.getAttributeValue(null, "url").orEmpty()
                            val type = p.getAttributeValue(null, "type").orEmpty()
                            val medium = p.getAttributeValue(null, "medium").orEmpty()
                            val isImg = type.startsWith("image", true) ||
                                medium.equals("image", true) ||
                                (type.isEmpty() && medium.isEmpty() && isImageUrl(u))
                            if (u.startsWith("http") && isImg) img = u
                        }
                    }
                    XmlPullParser.TEXT -> if (inItem) {
                        val t = p.text ?: ""
                        when (tag) {
                            "title" -> title += t
                            "link", "guid" -> if (link.isBlank() && t.startsWith("http")) link = t.trim()
                            "description", "summary", "content:encoded" -> if (desc.length < 3000) desc += t
                            "pubdate", "published", "updated", "dc:date" -> date += t
                            "category" -> cat += " $t"
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        val e = p.name.lowercase(Locale.US)
                        if (e == "item" || e == "entry") {
                            inItem = false
                            if (title.isNotBlank() && link.isNotBlank()) {
                                if (img.isBlank()) img = imgInHtml(desc)
                                out.add(
                                    NewsItem(
                                        name, Mime.stripHtml(title).trim(), link.trim(),
                                        parseDate(date.trim()) ?: System.currentTimeMillis(),
                                        Mime.stripHtml(desc).take(400).trim(), img,
                                    ).takeIf { !SPORT.containsMatchIn(it.link + cat) } ?: continue
                                )
                            }
                        }
                        tag = ""
                    }
                }
            }
            return out
        } finally {
            c.disconnect()
        }
    }

    private val IMG_TAG = Regex("<img[^>]+src=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE)
    private val IMG_EXT = Regex("\\.(jpe?g|png|webp|gif)(\\?|$)", RegexOption.IGNORE_CASE)

    private fun isImageUrl(u: String) = IMG_EXT.containsMatchIn(u)

    private fun imgInHtml(html: String): String {
        for (m in IMG_TAG.findAll(html)) {
            val u = m.groupValues[1].trim()
            if (u.startsWith("http")) return u
        }
        return ""
    }

    /** Link (lekérdezés nélkül) → képcím. */
    fun linkKey(url: String): String = url.substringBefore('?').trimEnd('/')

    private fun imagesFile(ctx: Context) = File(ctx.filesDir, "news_images.json")

    fun images(ctx: Context): Map<String, String> = try {
        val o = org.json.JSONObject(imagesFile(ctx).readText())
        o.keys().asSequence().associateWith { o.getString(it) }
    } catch (e: Exception) {
        emptyMap()
    }

    private fun saveImages(ctx: Context, map: Map<String, String>) {
        try {
            val o = org.json.JSONObject()
            map.forEach { (k, v) -> o.put(k, v) }
            imagesFile(ctx).writeText(o.toString())
        } catch (_: Exception) {
        }
    }

    private fun cacheDir(ctx: Context) = File(ctx.cacheDir, "newsimg").apply { mkdirs() }

    fun cachedImage(ctx: Context, url: String): File =
        File(cacheDir(ctx), Integer.toHexString(url.hashCode()) + ".img")

    /** Egy kép letöltése a gyorsítótárba, ha még nincs meg. Blokkoló. */
    fun downloadImage(ctx: Context, url: String): File? {
        val f = cachedImage(ctx, url)
        if (f.exists() && f.length() > 0) return f
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 12_000
            c.readTimeout = 20_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "Uzenetnaplo/1.0")
            if (c.responseCode != 200) throw java.io.IOException("HTTP ${c.responseCode}")
            val tmp = File(f.parentFile, f.name + ".part")
            c.inputStream.use { inp -> tmp.outputStream().use { out -> inp.copyTo(out) } }
            c.disconnect()
            if (tmp.length() > 500 && tmp.renameTo(f)) f else { tmp.delete(); null }
        } catch (e: Exception) {
            null
        }
    }

    /** A régi, már nem hivatkozott képek törlése. */
    private fun pruneImages(ctx: Context, keep: Collection<String>) {
        val names = keep.map { cachedImage(ctx, it).name }.toSet()
        cacheDir(ctx).listFiles()?.forEach { if (it.name !in names) it.delete() }
    }

    private fun parseDate(s: String): Long? {
        if (s.isBlank()) return null
        ImapClient.parseDate(s)?.let { return it }
        for (f in listOf("yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd HH:mm:ss")) {
            try {
                return SimpleDateFormat(f, Locale.US).parse(s)?.time
            } catch (_: Exception) {
            }
        }
        return null
    }

    /** Minden csatorna letöltése; visszaad: (hírek, hibák). Blokkoló. */
    fun fetchAll(ctx: Context, progress: ((String) -> Unit)? = null): Pair<List<NewsItem>, List<String>> {
        val items = ArrayList<NewsItem>()
        val errors = ArrayList<String>()
        val seen = HashSet<String>()
        for ((name, url) in feeds(ctx)) {
            progress?.invoke("Letöltés: $name…")
            try {
                for (it in fetchFeed(name, url)) {
                    val key = it.link.substringBefore('?')
                    if (seen.add(key)) items.add(it)
                }
            } catch (e: Exception) {
                errors.add("$name: ${e.message}")
            }
        }
        val since = System.currentTimeMillis() - 30 * 3600_000L
        val recent = items.filter { it.ts >= since }.sortedByDescending { it.ts }
        return (if (recent.size < 15) items.sortedByDescending { it.ts }.take(120) else recent) to errors
    }

    /** Letöltés + AI-válogatás; az eredményt elmenti. Blokkoló. */
    fun refresh(ctx: Context, progress: ((String) -> Unit)? = null): String {
        val app = ctx.applicationContext
        val (items, errors) = fetchAll(app, progress)
        if (items.isEmpty()) {
            return "Nem sikerült hírt letölteni." + if (errors.isEmpty()) "" else "\n" + errors.joinToString("\n")
        }
        val model = Prefs.newsModel(app)
        val client = AiClient(app, model, Prefs.newsKey(app).ifBlank { null })
        if (!client.hasKey()) throw IllegalStateException("Nincs API-kulcs a hírekhez (⚙ → Hírek).")
        val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.US)
        val sb = StringBuilder()
        var used = 0
        for (i in items) {
            val line = "${i.source} | ${fmt.format(Date(i.ts))} | ${i.title} | ${i.desc.take(220)} | ${i.link}\n"
            if (used + line.length > 90_000) break
            used += line.length
            sb.append(line)
        }
        progress?.invoke("${items.size} hír feldolgozása…")
        val prompt = buildString {
            append("Az alábbi sorok magyar hírportálok friss RSS-tételei, soronként: forrás | idő | cím | bevezető | link.\n\n")
            append("Készíts belőlük hírösszefoglalót magyarul, Markdownban, ezekkel a szabályokkal:\n")
            append("- A sportot teljesen hagyd ki. Minden más téma érdekes: belföld, külföld, gazdaság, tudomány, kultúra, tech.\n")
            append("- Az azonos eseményről szóló tételeket vond össze egy pontba, több forráslinkkel.\n")
            append("- Témák szerint csoportosíts (## címsorokkal), a fontosabb témával kezdd.\n")
            append("- Minden pont így nézzen ki: - **Cím** – egy-két mondat a bevezető alapján. [forrás](link)\n")
            append("- Ne találj ki semmit: csak a megadott címekre és bevezetőkre támaszkodj, a cikkeket nem olvastad.\n")
            append("- A végén „## További címek” szakaszban sorold fel a kimaradt tételeket: - Cím [forrás](link)\n\n")
            append("--- HÍREK ---\n")
            append(sb)
        }
        val a = client.ask(prompt)
        val usd = Cost.record(app, model, a.inTok, a.outTok)
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
        // a válaszban szereplő linkekhez tartozó képek
        val byLink = HashMap<String, String>()
        items.forEach { if (it.image.isNotBlank()) byLink[linkKey(it.link)] = it.image }
        val used2 = LinkedHashMap<String, String>()
        for (m in Regex("\\((https?://[^)\\s]+)\\)").findAll(a.text)) {
            val img = byLink[linkKey(m.groupValues[1])] ?: continue
            if (used2.size >= MAX_IMAGES) break
            used2[linkKey(m.groupValues[1])] = img
        }
        saveImages(app, used2)
        if (Prefs.newsImages(app)) {
            progress?.invoke("${used2.size} kép letöltése…")
            used2.values.forEach { downloadImage(app, it) }
            pruneImages(app, used2.values)
        }
        val text = a.text.trim() + "\n\n_(${items.size} hír, $stamp, ${Models.label(model)}" +
            (if (usd != null) ", " + Cost.format(app, usd) else "") +
            (if (errors.isEmpty()) "" else "; hibák: " + errors.joinToString("; ")) + ")_"
        try {
            digestFile(app).writeText(text)
        } catch (_: Exception) {
        }
        Prefs.setNewsTs(app, System.currentTimeMillis())
        return text
    }

    // ---------------- ütemezés ----------------

    private fun pending(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 11, Intent(ctx, NewsReceiver::class.java).setAction(ACTION),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val pi = pending(ctx)
        am.cancel(pi)
        if (!Prefs.newsEnabled(ctx)) return
        val hours = Prefs.newsInterval(ctx).coerceIn(1, 12)
        val at = System.currentTimeMillis() + hours * 3600_000L
        // pontosság itt nem számít, ablakos ébresztés elég
        am.setWindow(AlarmManager.RTC_WAKEUP, at, 20 * 60_000L, pi)
    }

    fun runScheduled(ctx: Context) {
        val app = ctx.applicationContext
        Thread {
            try {
                refresh(app)
            } catch (_: Exception) {
            }
            try {
                Weather.refresh(app)
            } catch (_: Exception) {
            }
            try {
                Weather.refreshLocal(app)
                Health.sample(app)
            } catch (_: Exception) {
            } finally {
                schedule(app)
            }
        }.start()
    }
}

class NewsReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != News.ACTION) return
        News.runScheduled(ctx)
    }
}
