package hu.atria.uzenetnaplo

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.text.method.LinkMovementMethod
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/** A reggelre elkészült hírösszeállítás, hírenként egy fotóval. */
class NewsActivity : Activity() {

    private lateinit var pal: Palette
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var refreshBtn: Button
    private val imgExec = Executors.newFixedThreadPool(3)
    private val linkRe = Regex("\\((https?://[^)\\s]+)\\)")

    override fun onCreate(savedInstanceState: Bundle?) {
        pal = Ui.apply(this)
        super.onCreate(savedInstanceState)
        title = "Hírek"
        val pad = dp(16)

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(pal.muted)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        refreshBtn = Button(this).apply {
            text = "Frissítés"
            isAllCaps = false
            setOnClickListener { refresh() }
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, dp(8), dp(8), 0)
            addView(status)
            addView(refreshBtn)
        }
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(8), pad, dp(40))
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.background(this@NewsActivity, pal)
            addView(top)
            addView(ScrollView(this@NewsActivity).apply {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                addView(list)
            })
        })

        show()
        if (News.digest(this).isBlank()) refresh()
    }

    override fun onDestroy() {
        imgExec.shutdownNow()
        super.onDestroy()
    }

    // ---------------- megjelenítés ----------------

    private fun show() {
        list.removeAllViews()
        val text = News.digest(this)
        if (text.isBlank()) {
            list.addView(paragraph(Md.toSpanned("Még nincs letöltött hírösszeállítás. Nyomd meg a Frissítés gombot.")))
        } else {
            render(text)
        }
        val ts = Prefs.newsTs(this)
        status.text = if (ts == 0L) "" else
            "Frissítve: " + SimpleDateFormat("MM-dd HH:mm", Locale.US).format(Date(ts)) +
                " · óránként magától is"
    }

    /** A Markdown bekezdésenként, a hírekhez tartozó képekkel. */
    private fun render(text: String) {
        val images = if (Prefs.newsImages(this)) News.images(this) else emptyMap()
        val shown = HashSet<String>()
        var tail = false   // a „További címek” szakaszban már nincs kép
        for (raw in text.lines()) {
            val line = raw.trimEnd()
            if (line.isBlank()) continue
            val heading = line.trimStart().startsWith("#")
            if (heading && line.contains("További", true)) tail = true

            if (!heading && !tail) {
                val img = linkRe.findAll(line)
                    .map { News.linkKey(it.groupValues[1]) }
                    .firstOrNull { it in images && shown.add(it) }
                    ?.let { images[it] }
                if (img != null) list.addView(imageView(img))
            }
            list.addView(paragraph(Md.toSpanned(line), heading))
        }
    }

    private fun paragraph(text: CharSequence, heading: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = if (heading) 18f else 15f
        setTextColor(pal.text)
        setLinkTextColor(pal.accent)
        setTextIsSelectable(true)
        movementMethod = LinkMovementMethod.getInstance()
        setPadding(0, if (heading) dp(16) else dp(2), 0, dp(6))
    }

    private fun imageView(url: String): ImageView {
        val iv = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170)).apply {
                topMargin = dp(10)
            }
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(pal.dayBg)
            visibility = View.GONE
            setOnClickListener {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } catch (_: Exception) {
                }
            }
        }
        val app = applicationContext
        val width = resources.displayMetrics.widthPixels
        imgExec.execute {
            val f = News.downloadImage(app, url) ?: return@execute
            val bmp = decode(f, width, dp(170) * 2) ?: return@execute
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                iv.setImageBitmap(bmp)
                iv.visibility = View.VISIBLE
            }
        }
        return iv
    }

    /** Memóriakímélő betöltés: a képernyőhöz igazított méretben. */
    private fun decode(f: File, reqW: Int, reqH: Int): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, bounds)
        var sample = 1
        while (bounds.outWidth / sample > reqW * 2 || bounds.outHeight / sample > reqH * 2) sample *= 2
        BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
    } catch (e: Exception) {
        null
    } catch (e: OutOfMemoryError) {
        null
    }

    // ---------------- frissítés ----------------

    private fun refresh() {
        refreshBtn.isEnabled = false
        status.text = "Hírek letöltése…"
        val app = applicationContext
        Thread {
            val err = try {
                News.refresh(app) { p -> runOnUiThread { status.text = p } }
                null
            } catch (e: Exception) {
                e.message ?: "ismeretlen hiba"
            }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                refreshBtn.isEnabled = true
                show()
                if (err != null) status.text = "Nem sikerült: $err"
            }
        }.start()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
