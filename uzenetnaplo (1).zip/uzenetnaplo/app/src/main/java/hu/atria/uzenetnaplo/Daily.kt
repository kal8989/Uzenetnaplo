package hu.atria.uzenetnaplo

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Reggeli (időzített) AI-összefoglaló. */
object Daily {
    const val ACTION_RUN = "hu.atria.uzenetnaplo.DAILY"
    const val EXTRA_ATTEMPT = "attempt"
    const val EXTRA_SHOW_SUMMARY = "show_summary"
    private const val CHANNEL = "daily"
    private const val MAX_MAILS = 30
    private const val MAIL_CHARS = 2500
    private const val NOTIF_ID = 6

    /** Szálas módban az előzményként behúzott, teljes szöveg nélküli levelek felső száma. */
    private const val MAX_HIST_MAILS = 150

    /** Szálas módban az ablakból figyelembe vett üzenetek felső száma (a legfrissebbek). */
    private const val MAX_WINDOW_MSGS = 4000

    private fun pending(ctx: Context, code: Int, attempt: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code,
            Intent(ctx, DailyReceiver::class.java).setAction(ACTION_RUN).putExtra(EXTRA_ATTEMPT, attempt),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    fun nextTime(ctx: Context): Long = Calendar.getInstance().run {
        set(Calendar.HOUR_OF_DAY, Prefs.dailyHour(ctx))
        set(Calendar.MINUTE, Prefs.dailyMinute(ctx))
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        if (timeInMillis <= System.currentTimeMillis() + 5_000) add(Calendar.DAY_OF_MONTH, 1)
        timeInMillis
    }

    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val pi = pending(ctx, 1, 0)
        am.cancel(pi)
        if (!Prefs.dailyEnabled(ctx)) return
        setAlarm(ctx, am, nextTime(ctx), pi)
    }

    private fun scheduleRetry(ctx: Context, attempt: Int) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        setAlarm(ctx, am, System.currentTimeMillis() + 15 * 60_000L, pending(ctx, 2, attempt))
    }

    private fun setAlarm(ctx: Context, am: AlarmManager, at: Long, pi: PendingIntent) {
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else am.setWindow(AlarmManager.RTC_WAKEUP, at, 10 * 60_000L, pi)
    }

    /**
     * Elkészíti az elmúlt 24 óra összefoglalóját (háttérszálon), elmenti és értesítést küld.
     * [done]: (siker, üzenet) – a hívó szálán nem garantált.
     */
    fun run(ctx: Context, attempt: Int = 0, done: ((Boolean, String) -> Unit)? = null) {
        val app = ctx.applicationContext
        val pm = app.getSystemService(PowerManager::class.java)
        val wl = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "uzenetnaplo:daily")
        wl?.acquire(10 * 60_000L)
        val now = System.currentTimeMillis()
        val from = now - 24 * 3600_000L
        val threadMode = Prefs.threadMode(app)
        // Szálas módban az előzményhez egy hétre visszanyúlunk; az összefoglaló a friss részről szól.
        val winFrom = if (threadMode) now - Threads.WINDOW_DAYS * 86_400_000L else from
        MsgIndex.exec.execute {
            SmsImport.quickSyncIfDue(app)
            val err = MsgIndex.sync(app)
            var ids = MsgIndex.ids(app, Filter(winFrom, now, null, true, emptyList()))
            if (ids.size > MAX_WINDOW_MSGS) ids = ids.copyOf(MAX_WINDOW_MSGS) // a legfrissebbek elöl
            val mails = if (Prefs.dailyMail(app)) fetchMails(app, winFrom, now, from) else emptyList()
            Thread {
                try {
                    if (err != null && ids.isEmpty() && mails.isEmpty()) throw IllegalStateException(err)
                    val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
                    val text: String
                    if (ids.isEmpty() && mails.isEmpty()) {
                        text = "Az elmúlt 24 órában nem érkezett figyelembe vehető üzenet."
                    } else {
                        val model = Prefs.model(app)
                        val client = AiClient(app, model)
                        if (!client.hasKey()) throw IllegalStateException(
                            "Nincs megadva ${client.providerName} API-kulcs a beállításokban."
                        )
                        val period = "${stamp.format(Date(from))} – ${stamp.format(Date(now))}"
                        val built = if (threadMode) threadPrompt(app, ids, mails, from, period)
                        else flatPrompt(app, ids, mails, period)
                        if (built == null) {
                            text = "Az elmúlt 24 órában nem volt új üzenet a beszélgetésekben."
                        } else {
                            val a = client.ask(built.prompt)
                            val usd = Cost.record(app, model, a.inTok, a.outTok)
                            text = a.text.trim() +
                                "\n\n(" + built.note +
                                ", ${Models.label(model)}" +
                                (if (a.truncated) ", a válasz csonka" else "") +
                                (if (usd != null) ", " + Cost.format(app, usd) else "") + ")"
                        }
                    }
                    Prefs.setLastSummary(app, text, now)
                    val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(now))
                    LogWriter.writeWhole(app, "osszefoglalo_$day.md",
                        "# Reggeli összefoglaló – ${stamp.format(Date(now))}\n\n$text\n")
                    notify(app, "Reggeli összefoglaló", Md.plain(text))
                    done?.invoke(true, "Kész.")
                } catch (e: Exception) {
                    val msg = e.message ?: "ismeretlen hiba"
                    if (done == null && attempt < 3) {
                        scheduleRetry(app, attempt + 1)
                    } else {
                        notify(app, "Az összefoglaló nem készült el", msg)
                    }
                    done?.invoke(false, msg)
                } finally {
                    try { if (wl?.isHeld == true) wl.release() } catch (_: Exception) {}
                }
            }.start()
        }
    }

    private class Built(val prompt: String, val note: String)

    /**
     * A „Mi történt” gombhoz: a friss beszélgetési szálak prompt-ja és a hozzá tartozó
     * rövid leírás. Blokkoló – háttérszálról hívandó. Null, ha nincs friss szál.
     */
    fun freshThreads(
        ctx: Context, budget: Int, withMail: Boolean, status: ((String) -> Unit)? = null,
    ): Pair<String, String>? {
        val now = System.currentTimeMillis()
        val freshFrom = now - Threads.FRESH_HOURS * 3600_000L
        val winFrom = now - Threads.WINDOW_DAYS * 86_400_000L
        var ids = MsgIndex.ids(ctx, Filter(winFrom, now, null, true, emptyList()))
        if (ids.size > MAX_WINDOW_MSGS) ids = ids.copyOf(MAX_WINDOW_MSGS)
        if (withMail) status?.invoke("Levelek letöltése…")
        val mails = if (withMail) fetchMails(ctx, winFrom, now, freshFrom) else emptyList()
        status?.invoke("Beszélgetések összefűzése…")
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        val period = "${stamp.format(Date(freshFrom))} – ${stamp.format(Date(now))}"
        val b = threadPrompt(ctx, ids, mails, freshFrom, period) ?: return null
        return b.prompt to b.note
    }

    /** Szálas összefoglaló: a csatornák egy szálra fűzve, idézet nélkül. Null, ha nincs friss szál. */
    private fun threadPrompt(
        ctx: Context, ids: LongArray, mails: List<Msg>, freshFrom: Long, period: String,
    ): Built? {
        val all = ArrayList<Msg>(ids.size + mails.size)
        MsgIndex.sequence(ctx, ids).forEach { all.add(it) }
        all.addAll(mails)
        val res = Threads.build(all, freshFrom)
        if (res.threads.isEmpty()) return null
        val (prompt, nth, nmsg) = Threads.prompt(res, period, Prefs.charBudget(ctx))
        val note = "$nth szál, $nmsg üzenet" +
            (if (res.noiseThreads > 0) ", ${res.noiseMsgs} automatikus kihagyva" else "")
        return Built(prompt, note)
    }

    /** A korábbi, szálak nélküli összefoglaló – egyszerű időrendi lista. */
    private fun flatPrompt(ctx: Context, ids: LongArray, mails: List<Msg>, period: String): Built {
        val merged = Prompts.merge(MsgIndex.sequence(ctx, ids), mails.asSequence())
        val (prompt, n) = Prompts.build(merged, Prompts.TASK_DAILY, period, Prefs.charBudget(ctx))
        return Built(
            prompt,
            "$n üzenet alapján" + (if (mails.isNotEmpty()) ", ebből ${mails.size} levél" else "")
        )
    }

    /**
     * Levelek a Gmail-fiókokból [from]..[to] között – a beérkezettek és az elküldöttek egyaránt.
     * A teljes szöveg csak a [bodyFrom] utáni leveleknél töltődik le; a korábbiak tárggyal
     * kerülnek be előzményként. Blokkoló; hiba esetén üres lista, hogy az összefoglaló
     * attól még elkészüljön.
     */
    private fun fetchMails(ctx: Context, from: Long, to: Long, bodyFrom: Long): List<Msg> {
        val accounts = MailStore.enabledAccounts(ctx).map { it.address.lowercase(Locale.US) }
        if (accounts.isEmpty()) return emptyList()
        return try {
            val res = MailStore.search(ctx, emptyList(), from, to)
            val items = res.items.filter { it.ts in from..to }.sortedByDescending { it.ts }
            val fresh = items.filter { it.ts >= bodyFrom }.take(MAX_MAILS)
            val older = items.filter { it.ts < bodyFrom }.take(MAX_HIST_MAILS)
            (fresh + older).map { mi ->
                val body = if (mi.ts >= bodyFrom) {
                    try {
                        MailStore.body(ctx, mi)
                    } catch (e: Exception) {
                        ""
                    }
                } else ""
                val sentByMe = accounts.any { mi.from.lowercase(Locale.US).contains(it) }
                val who = if (sentByMe) "Én → ${mi.to.take(80)}"
                else "${mi.from} → ${mi.account}"
                Msg(-1, mi.ts, "Gmail", "gmail", who,
                    (mi.subject + (if (body.isEmpty()) "" else "\n$body")).take(MAIL_CHARS))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun notify(ctx: Context, title: String, body: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Reggeli összefoglaló", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val open = PendingIntent.getActivity(
            ctx, 3,
            Intent(ctx, MainActivity::class.java)
                .putExtra(EXTRA_SHOW_SUMMARY, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val short = body.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty()
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle(title)
            .setContentText(short)
            .setStyle(Notification.BigTextStyle().bigText(body.take(4000)))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try { nm.notify(NOTIF_ID, n) } catch (_: SecurityException) {}
    }
}

/** Az időzített ébresztés fogadója (nem exportált). */
class DailyReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Daily.ACTION_RUN) return
        val attempt = intent.getIntExtra(Daily.EXTRA_ATTEMPT, 0)
        if (attempt == 0) Daily.schedule(ctx) // a következő napi futás
        // A munka a saját szálán fut; a folyamatot az értesítésfigyelő szolgáltatás életben tartja.
        Daily.run(ctx, attempt)
    }
}

/** Újraindítás és frissítés után újraütemez. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> {
                Daily.schedule(ctx)
                News.schedule(ctx)
            }
        }
    }
}
