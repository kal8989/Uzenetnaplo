package hu.atria.uzenetnaplo

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Reggeli (időzített) AI-összefoglaló. */
object Daily {
    const val ACTION_RUN = "hu.atria.uzenetnaplo.DAILY"
    const val EXTRA_ATTEMPT = "attempt"
    const val EXTRA_SHOW_SUMMARY = "show_summary"
    private const val CHANNEL = "daily"
    private const val NOTIF_ID = 6

    private fun pending(ctx: Context, code: Int, attempt: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, code,
            Intent(ctx, DailyReceiver::class.java).setAction(ACTION_RUN).putExtra(EXTRA_ATTEMPT, attempt),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    fun nextTime(ctx: Context): Long = Calendar.getInstance().run {
        set(Calendar.HOUR_OF_DAY, Prefs.dailyHour(ctx))
        set(Calendar.MINUTE, Prefs.dailyMinute(ctx))
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        if (timeInMillis <= System.currentTimeMillis() + 5_000) add(Calendar.DAY_OF_MONTH, 1)
        timeInMillis
    }

    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val pi = pending(ctx, 1, 0)
        am.cancel(pi)
        if (!Prefs.dailyEnabled(ctx)) return
        setAlarm(ctx, am, nextTime(ctx), pi)
    }

    private fun scheduleRetry(ctx: Context, attempt: Int) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        setAlarm(ctx, am, System.currentTimeMillis() + 15 * 60_000L, pending(ctx, 2, attempt))
    }

    private fun setAlarm(ctx: Context, am: AlarmManager, at: Long, pi: PendingIntent) {
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else am.setWindow(AlarmManager.RTC_WAKEUP, at, 10 * 60_000L, pi)
    }

    /**
     * Elkészíti az elmúlt 24 óra összefoglalóját (háttérszálon), elmenti és értesítést küld.
     * [done]: (siker, üzenet) – a hívó szálán nem garantált.
     */
    fun run(ctx: Context, attempt: Int = 0, done: ((Boolean, String) -> Unit)? = null) {
        val app = ctx.applicationContext
        val pm = app.getSystemService(PowerManager::class.java)
        val wl = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "uzenetnaplo:daily")
        wl?.acquire(10 * 60_000L)
        val now = System.currentTimeMillis()
        val from = now - 24 * 3600_000L
        val month = SimpleDateFormat("yyyy-MM", Locale.US)
        LogStore.load(app, month.format(Date(from)), month.format(Date(now))) { all, err ->
            Thread {
                try {
                    if (err != null) throw IllegalStateException(err)
                    val msgs = all.filter { it.ts in from..now && it.pkg !in Prompts.SYS_PKGS }
                    val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
                    val text: String
                    if (msgs.isEmpty()) {
                        text = "Az elmúlt 24 órában nem érkezett figyelembe vehető üzenet."
                    } else {
                        val model = Prefs.model(app)
                        val client = AiClient(app, model)
                        if (!client.hasKey()) throw IllegalStateException(
                            "Nincs megadva ${client.providerName} API-kulcs a beállításokban."
                        )
                        val (prompt, n) = Prompts.build(
                            msgs, Prompts.TASK_DAILY,
                            "${stamp.format(Date(from))} – ${stamp.format(Date(now))}"
                        )
                        val (answer, cut) = client.ask(prompt)
                        text = answer.trim() +
                            "\n\n(${n} üzenet alapján, ${Models.label(model)}" +
                            (if (cut) ", a válasz csonka" else "") + ")"
                    }
                    Prefs.setLastSummary(app, text, now)
                    val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(now))
                    LogWriter.writeWhole(app, "osszefoglalo_$day.md",
                        "# Reggeli összefoglaló – ${stamp.format(Date(now))}\n\n$text\n")
                    notify(app, "Reggeli összefoglaló", Md.plain(text))
                    done?.invoke(true, "Kész.")
                } catch (e: Exception) {
                    val msg = e.message ?: "ismeretlen hiba"
                    if (done == null && attempt < 3) {
                        scheduleRetry(app, attempt + 1)
                    } else {
                        notify(app, "Az összefoglaló nem készült el", msg)
                    }
                    done?.invoke(false, msg)
                } finally {
                    try { if (wl?.isHeld == true) wl.release() } catch (_: Exception) {}
                }
            }.start()
        }
    }

    private fun notify(ctx: Context, title: String, body: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Reggeli összefoglaló", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val open = PendingIntent.getActivity(
            ctx, 3,
            Intent(ctx, MainActivity::class.java)
                .putExtra(EXTRA_SHOW_SUMMARY, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val short = body.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty()
        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_email)
            .setContentTitle(title)
            .setContentText(short)
            .setStyle(Notification.BigTextStyle().bigText(body.take(4000)))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try { nm.notify(NOTIF_ID, n) } catch (_: SecurityException) {}
    }
}

/** Az időzített ébresztés fogadója (nem exportált). */
class DailyReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Daily.ACTION_RUN) return
        val attempt = intent.getIntExtra(Daily.EXTRA_ATTEMPT, 0)
        if (attempt == 0) Daily.schedule(ctx) // a következő napi futás
        // A munka a saját szálán fut; a folyamatot az értesítésfigyelő szolgáltatás életben tartja.
        Daily.run(ctx, attempt)
    }
}

/** Újraindítás és frissítés után újraütemez. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> Daily.schedule(ctx)
        }
    }
}
