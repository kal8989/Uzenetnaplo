package hu.atria.uzenetnaplo

import java.io.BufferedInputStream
import java.io.Closeable
import java.io.OutputStream
import java.net.Socket
import java.util.Locale
import javax.net.ssl.SSLSocketFactory

/** MIME-szövegek dekódolása (fejléc, törzs). Nincs Android-függősége. */
object Mime {
    private val encodedWord = Regex("=\\?([^?]+)\\?([bBqQ])\\?([^?]*)\\?=")

    fun charset(name: String?): java.nio.charset.Charset = try {
        java.nio.charset.Charset.forName(name?.trim()?.trim('"') ?: "UTF-8")
    } catch (e: Exception) {
        Charsets.UTF_8
    }

    /** =?UTF-8?B?...?= alakú fejlécrészek feloldása. */
    fun decodeHeader(raw: String): String {
        var s = raw.replace(Regex("\\?=\\s+=\\?"), "?==?")
        s = encodedWord.replace(s) { m ->
            val cs = charset(m.groupValues[1])
            val enc = m.groupValues[2].uppercase(Locale.US)
            val data = m.groupValues[3]
            try {
                val bytes = if (enc == "B") java.util.Base64.getMimeDecoder().decode(data)
                else decodeQp(data.replace('_', ' '))
                String(bytes, cs)
            } catch (e: Exception) {
                data
            }
        }
        return s.trim()
    }

    fun decodeQp(s: String): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            when {
                c == '=' && i + 1 < s.length && s[i + 1] == '\n' -> i += 2
                c == '=' && i + 2 < s.length && s[i + 1] == '\r' && s[i + 2] == '\n' -> i += 3
                c == '=' && i + 2 < s.length -> {
                    val hex = s.substring(i + 1, i + 3)
                    val v = hex.toIntOrNull(16)
                    if (v != null) { out.write(v); i += 3 } else { out.write(c.code); i++ }
                }
                else -> { out.write(c.code); i++ }
            }
        }
        return out.toByteArray()
    }

    /** Egyszerű fejlécfeldolgozás (folytatósorokkal). */
    fun headers(raw: String): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        var key: String? = null
        val sb = StringBuilder()
        fun flush() {
            key?.let { m[it.lowercase(Locale.US)] = sb.toString().trim() }
            sb.setLength(0)
        }
        for (line in raw.split("\r\n", "\n")) {
            if (line.isBlank()) break
            if (line[0] == ' ' || line[0] == '\t') { sb.append(' ').append(line.trim()); continue }
            flush()
            val i = line.indexOf(':')
            if (i <= 0) { key = null; continue }
            key = line.substring(0, i)
            sb.append(line.substring(i + 1).trim())
        }
        flush()
        return m
    }

    fun param(headerValue: String?, name: String): String? {
        if (headerValue == null) return null
        val re = Regex("$name\\s*=\\s*(\"([^\"]*)\"|([^;\\s]+))", RegexOption.IGNORE_CASE)
        val m = re.find(headerValue) ?: return null
        return (m.groupValues[2].ifEmpty { m.groupValues[3] }).trim()
    }

    fun stripHtml(html: String): String = html
        .replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), " ")
        .replace(Regex("(?i)<br\\s*/?>"), "\n")
        .replace(Regex("(?i)</p>|</div>|</tr>"), "\n")
        .replace(Regex("<[^>]+>"), " ")
        .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<")
        .replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'")
        .replace(Regex("[ \\t]+"), " ")
        .replace(Regex("\n{3,}"), "\n\n")
        .trim()

    private fun decodeBody(body: String, enc: String?, cs: java.nio.charset.Charset): String {
        val e = enc?.lowercase(Locale.US)?.trim()
        val bytes = when (e) {
            "base64" -> try {
                java.util.Base64.getMimeDecoder().decode(body)
            } catch (ex: Exception) {
                body.toByteArray(Charsets.ISO_8859_1)
            }
            "quoted-printable" -> decodeQp(body)
            else -> body.toByteArray(Charsets.ISO_8859_1)
        }
        return String(bytes, cs)
    }

    /**
     * A levél olvasható szövege a nyers fejlécből és törzsből.
     * A többrészes leveleknél az első text/plain részt keresi, ennek híján a HTML-t tisztítja.
     */
    fun bodyText(headerRaw: String, bodyRaw: String): String {
        val h = headers(headerRaw)
        return part(h["content-type"], h["content-transfer-encoding"], bodyRaw, 0)
    }

    private fun part(contentType: String?, encoding: String?, body: String, depth: Int): String {
        val ct = (contentType ?: "text/plain").lowercase(Locale.US)
        if (depth < 6 && ct.startsWith("multipart/")) {
            val boundary = param(contentType, "boundary") ?: return stripIfHtml(ct, decodeBody(body, encoding, Mime.charset(param(contentType, "charset"))))
            val parts = body.split("--$boundary")
            val decoded = ArrayList<Pair<String, String>>() // (mime, szöveg)
            for (p in parts) {
                val t = p.trimStart('\r', '\n')
                if (t.isBlank() || t.startsWith("--")) continue
                val sep = indexOfBlankLine(t)
                val ph = if (sep > 0) t.substring(0, sep) else ""
                val pb = if (sep > 0) t.substring(sep) else t
                val hh = headers(ph)
                val pct = (hh["content-type"] ?: "text/plain").lowercase(Locale.US)
                val disp = hh["content-disposition"].orEmpty().lowercase(Locale.US)
                if (disp.startsWith("attachment")) {
                    val fn = param(hh["content-disposition"], "filename") ?: param(hh["content-type"], "name")
                    if (fn != null) decoded.add("attach" to "[melléklet: ${Mime.decodeHeader(fn)}]")
                    continue
                }
                val text = part(hh["content-type"], hh["content-transfer-encoding"], pb, depth + 1)
                if (text.isNotBlank()) decoded.add(pct to text)
            }
            val plain = decoded.firstOrNull { it.first.startsWith("text/plain") }?.second
            val html = decoded.firstOrNull { it.first.startsWith("text/html") }?.second
            val attach = decoded.filter { it.first == "attach" }.joinToString("\n") { it.second }
            val nested = decoded.firstOrNull { it.first.startsWith("multipart/") }?.second
            val main = plain ?: html ?: nested ?: ""
            return listOf(main, attach).filter { it.isNotBlank() }.joinToString("\n\n")
        }
        if (!ct.startsWith("text/")) return ""
        val cs = Mime.charset(param(contentType, "charset"))
        return stripIfHtml(ct, decodeBody(body, encoding, cs))
    }

    private fun stripIfHtml(ct: String, text: String) =
        (if (ct.startsWith("text/html")) stripHtml(text) else text).trim()

    private fun indexOfBlankLine(s: String): Int {
        val a = s.indexOf("\r\n\r\n")
        if (a >= 0) return a + 4
        val b = s.indexOf("\n\n")
        return if (b >= 0) b + 2 else -1
    }

    /** Az idézett előzmény levágása (a válaszok alján). */
    fun trimQuoted(text: String): String {
        val lines = text.lines()
        val cut = lines.indexOfFirst { l ->
            val t = l.trim()
            t.startsWith(">") ||
                Regex("^-{2,}\\s*(Original Message|Eredeti üzenet|Továbbított levél|Forwarded message)", RegexOption.IGNORE_CASE).containsMatchIn(t) ||
                Regex("(írta|wrote|schrieb)\\s*:$", RegexOption.IGNORE_CASE).containsMatchIn(t) ||
                Regex("^On .+ wrote:$").containsMatchIn(t)
        }
        val body = if (cut > 0) lines.take(cut).joinToString("\n") else text
        return body.replace(Regex("\n{3,}"), "\n\n").trim()
    }
}

/** Minimális IMAP-kliens (Gmail: keresés, fejlécek, egy levél szövege). */
class ImapClient(
    private val host: String,
    private val port: Int,
    private val user: String,
    private val pass: String,
) : Closeable {

    private var sock: Socket? = null
    private var out: OutputStream? = null
    private var inp: BufferedInputStream? = null
    private var tagN = 0
    private var selected: String? = null
    var allMail: String? = null
        private set

    val isOpen get() = sock?.isConnected == true && sock?.isClosed == false

    fun connect() {
        val s = SSLSocketFactory.getDefault().createSocket(host, port)
        s.soTimeout = 45_000
        sock = s
        out = s.getOutputStream()
        inp = BufferedInputStream(s.getInputStream())
        readLine() // üdvözlő sor
        val r = cmd("LOGIN ${quote(user)} ${quote(pass)}")
        if (!r.ok) throw java.io.IOException("Bejelentkezés sikertelen: ${r.status}")
    }

    override fun close() {
        try { cmd("LOGOUT") } catch (_: Exception) {}
        try { sock?.close() } catch (_: Exception) {}
        sock = null
    }

    class Result(val lines: List<String>, val status: String) {
        val ok get() = status.startsWith("OK", true)
    }

    private fun quote(s: String) = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

    private fun send(s: String) {
        val o = out ?: throw java.io.IOException("nincs kapcsolat")
        o.write((s + "\r\n").toByteArray(Charsets.ISO_8859_1))
        o.flush()
    }

    /** Egy logikai válaszsor, a {n} literálokat beolvasva (bájtonként ISO-8859-1 leképezéssel). */
    private fun readLine(): String {
        val i = inp ?: throw java.io.IOException("nincs kapcsolat")
        val sb = StringBuilder()
        while (true) {
            val line = readRawLine(i)
            sb.append(line)
            val m = Regex("\\{(\\d+)\\}$").find(line) ?: return sb.toString()
            val n = m.groupValues[1].toInt()
            val buf = ByteArray(n)
            var read = 0
            while (read < n) {
                val k = i.read(buf, read, n - read)
                if (k < 0) throw java.io.IOException("a kapcsolat megszakadt")
                read += k
            }
            sb.append('\n').append(String(buf, Charsets.ISO_8859_1))
        }
    }

    private fun readRawLine(i: BufferedInputStream): String {
        val b = java.io.ByteArrayOutputStream()
        while (true) {
            val c = i.read()
            if (c < 0) throw java.io.IOException("a kapcsolat megszakadt")
            if (c == '\n'.code) break
            if (c != '\r'.code) b.write(c)
        }
        return String(b.toByteArray(), Charsets.ISO_8859_1)
    }

    fun cmd(command: String, literal: ByteArray? = null, suffix: String = ""): Result {
        val tag = "a${++tagN}"
        if (literal == null) send("$tag $command")
        else {
            send("$tag $command {${literal.size}}")
            val cont = readLine()
            if (!cont.startsWith("+")) throw java.io.IOException("a szerver elutasította: $cont")
            val o = out!!
            o.write(literal)
            o.write((suffix + "\r\n").toByteArray(Charsets.ISO_8859_1))
            o.flush()
        }
        val lines = ArrayList<String>()
        while (true) {
            val l = readLine()
            if (l.startsWith("$tag ")) return Result(lines, l.substring(tag.length + 1))
            lines.add(l)
        }
    }

    /** A Gmail „Összes levél” mappájának megkeresése (nyelvfüggetlenül, a \All jelzőből). */
    fun findAllMail(): String {
        allMail?.let { return it }
        val r = cmd("LIST \"\" \"*\"")
        for (l in r.lines) {
            if (!l.startsWith("* LIST")) continue
            if (!l.contains("\\All")) continue
            val q = l.lastIndexOf('"')
            val p = l.lastIndexOf('"', q - 1)
            if (p in 0 until q) {
                val name = l.substring(p + 1, q)
                allMail = name
                return name
            }
        }
        allMail = "[Gmail]/All Mail"
        return allMail!!
    }

    fun select(mailbox: String) {
        if (selected == mailbox) return
        val r = cmd("EXAMINE ${quote(mailbox)}")
        if (!r.ok) throw java.io.IOException("A mappa nem nyitható meg: $mailbox")
        selected = mailbox
    }

    /** Gmail-keresőnyelv (X-GM-RAW). Visszaad: UID-k növekvő sorrendben. */
    fun searchRaw(query: String): List<Long> {
        val r = cmd("UID SEARCH CHARSET UTF-8 X-GM-RAW", query.toByteArray(Charsets.UTF_8))
        if (!r.ok) throw java.io.IOException("A keresés nem sikerült: ${r.status}")
        val ids = ArrayList<Long>()
        for (l in r.lines) {
            if (!l.startsWith("* SEARCH")) continue
            l.removePrefix("* SEARCH").trim().split(' ').forEach { t ->
                t.toLongOrNull()?.let { ids.add(it) }
            }
        }
        return ids
    }

    class Header(val uid: Long, val ts: Long, val from: String, val to: String, val subject: String)

    fun fetchHeaders(uids: List<Long>): List<Header> {
        if (uids.isEmpty()) return emptyList()
        val set = uids.joinToString(",")
        val r = cmd("UID FETCH $set (UID INTERNALDATE BODY.PEEK[HEADER.FIELDS (FROM TO SUBJECT DATE)])")
        val out = ArrayList<Header>()
        for (l in r.lines) {
            if (!l.startsWith("* ")) continue
            val uid = Regex("UID (\\d+)").find(l)?.groupValues?.get(1)?.toLongOrNull() ?: continue
            val nl = l.indexOf('\n')
            val raw = if (nl >= 0) l.substring(nl + 1) else ""
            val h = Mime.headers(raw)
            val ts = parseDate(h["date"]) ?: parseInternalDate(l) ?: 0L
            out.add(
                Header(
                    uid, ts,
                    Mime.decodeHeader(h["from"].orEmpty()),
                    Mime.decodeHeader(h["to"].orEmpty()),
                    Mime.decodeHeader(h["subject"].orEmpty()).ifBlank { "(tárgy nélkül)" },
                )
            )
        }
        return out
    }

    /** Egy levél olvasható szövege (legfeljebb [maxBytes] bájt törzs). */
    fun fetchBody(uid: Long, maxBytes: Int = 120_000): String {
        val rh = cmd("UID FETCH $uid (BODY.PEEK[HEADER])")
        val header = rh.lines.firstOrNull { it.contains("\n") }?.substringAfter('\n').orEmpty()
        val rb = cmd("UID FETCH $uid (BODY.PEEK[TEXT]<0.$maxBytes>)")
        val body = rb.lines.firstOrNull { it.contains("\n") }?.substringAfter('\n').orEmpty()
        return Mime.trimQuoted(Mime.bodyText(header, body))
    }

    companion object {
        private val dateFmts = listOf(
            "EEE, d MMM yyyy HH:mm:ss Z", "d MMM yyyy HH:mm:ss Z",
            "EEE, d MMM yyyy HH:mm:ss z", "EEE, d MMM yyyy HH:mm Z",
        )

        fun parseDate(v: String?): Long? {
            if (v.isNullOrBlank()) return null
            val s = v.replace(Regex("\\s*\\(.*\\)$"), "").trim()
            for (f in dateFmts) {
                try {
                    return java.text.SimpleDateFormat(f, Locale.US).parse(s)?.time
                } catch (_: Exception) {
                }
            }
            return null
        }

        fun parseInternalDate(line: String): Long? {
            val m = Regex("INTERNALDATE \"([^\"]+)\"").find(line) ?: return null
            return try {
                java.text.SimpleDateFormat("d-MMM-yyyy HH:mm:ss Z", Locale.US).parse(m.groupValues[1])?.time
            } catch (e: Exception) {
                null
            }
        }
    }
}
