package hu.atria.uzenetnaplo

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Időjárás a felvett városokra; a városra koppintva megnyílik az AccuWeather. */
class WeatherActivity : Activity() {

    private lateinit var pal: Palette
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var refreshBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        pal = Ui.apply(this)
        super.onCreate(savedInstanceState)
        title = "Időjárás"
        val pad = dp(16)

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(pal.muted)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        refreshBtn = Button(this).apply {
            text = "Frissítés"
            isAllCaps = false
            setOnClickListener { refresh() }
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, dp(8), dp(8), 0)
            addView(status)
            addView(refreshBtn)
        }
        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(8), pad, dp(40))
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.background(this@WeatherActivity, pal)
            addView(top)
            addView(ScrollView(this@WeatherActivity).apply {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                addView(list)
            })
        })

        show()
        val stale = System.currentTimeMillis() - Prefs.weatherTs(this) > 3600_000L
        if (Weather.cached(this).isEmpty() || stale) refresh()
    }

    private fun show() {
        list.removeAllViews()
        val data = Weather.cached(this)
        if (Weather.cities(this).isEmpty()) {
            list.addView(text("Még nincs felvett város. ⚙ → Időjárás → Város hozzáadása.", 15f))
            return
        }
        if (data.isEmpty()) {
            list.addView(text("Még nincs letöltött adat. Nyomd meg a Frissítés gombot.", 15f))
            return
        }
        val cities = Weather.cities(this)
        for (w in data) {
            val city = cities.firstOrNull { it.name == w.city }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(12), dp(12), dp(12))
                setBackgroundColor(pal.dayBg)
                isClickable = true
                setOnClickListener {
                    val url = city?.openUrl() ?: return@setOnClickListener
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    } catch (_: Exception) {
                    }
                }
            }
            card.addView(text(w.city, 19f, bold = true))
            card.addView(text(
                "${Math.round(w.nowTemp)}°C · ${Weather.describe(w.nowCode)}" +
                    " · hőérzet ${Math.round(w.nowFeels)}°C", 16f
            ))
            card.addView(text(
                "szél ${Math.round(w.nowWind)} km/h · pára ${w.nowHum}% · " +
                    "napkelte ${w.sunrise} · napnyugta ${w.sunset}", 13f, muted = true
            ))
            val today = w.days.firstOrNull()
            if (today != null) {
                card.addView(text(
                    "Ma: ${Math.round(today.min)}–${Math.round(today.max)}°C, " +
                        "csapadék ${fmt(today.rain)} mm (${today.rainProb}%), " +
                        "szél ${Math.round(today.wind)} km/h", 14f
                ))
            }
            card.addView(View(this).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(8))
            })
            for (d in w.days.drop(1)) {
                card.addView(text(
                    "${Weather.dayLabel(d.date)}  ${Math.round(d.min)}–${Math.round(d.max)}°C  " +
                        "${Weather.describe(d.code)}" +
                        if (d.rainProb > 20) "  ☔ ${d.rainProb}%" else "", 14f
                ))
            }
            card.addView(text("koppints: AccuWeather 30 napos", 12f, muted = true))
            list.addView(card)
            list.addView(View(this).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(12))
            })
        }
        val ts = Prefs.weatherTs(this)
        status.text = if (ts == 0L) "" else
            "Frissítve: " + SimpleDateFormat("MM-dd HH:mm", Locale.US).format(Date(ts)) + " · óránként magától is"
    }

    private fun fmt(v: Double) = String.format(Locale.US, "%.1f", v)

    private fun refresh() {
        refreshBtn.isEnabled = false
        status.text = "Frissítés…"
        val app = applicationContext
        Thread {
            val errors = Weather.refresh(app) { p -> runOnUiThread { status.text = p } }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                refreshBtn.isEnabled = true
                show()
                if (errors.isNotEmpty()) status.text = errors.joinToString("; ")
            }
        }.start()
    }

    private fun text(t: String, size: Float, bold: Boolean = false, muted: Boolean = false) =
        TextView(this).apply {
            text = t
            textSize = size
            setTextColor(if (muted) pal.muted else pal.text)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(2), 0, dp(2))
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
