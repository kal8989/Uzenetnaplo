package hu.atria.uzenetnaplo

import android.app.Activity
import android.os.Bundle
import android.text.method.LinkMovementMethod
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** A reggelre elkészült hírösszeállítás. */
class NewsActivity : Activity() {

    private lateinit var pal: Palette
    private lateinit var body: TextView
    private lateinit var status: TextView
    private lateinit var refreshBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        pal = Ui.apply(this)
        super.onCreate(savedInstanceState)
        title = "Hírek"
        val pad = dp(16)

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(pal.muted)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        refreshBtn = Button(this).apply {
            text = "Frissítés"
            isAllCaps = false
            setOnClickListener { refresh() }
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, dp(8), dp(8), 0)
            addView(status)
            addView(refreshBtn)
        }

        body = TextView(this).apply {
            textSize = 15f
            setTextColor(pal.text)
            setLinkTextColor(pal.accent)
            setTextIsSelectable(true)
            movementMethod = LinkMovementMethod.getInstance()
            setPadding(pad, dp(8), pad, dp(40))
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.background(this@NewsActivity, pal)
            addView(top)
            addView(ScrollView(this@NewsActivity).apply {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                addView(body)
            })
        })

        show()
        if (News.digest(this).isBlank()) refresh()
    }

    private fun show() {
        val text = News.digest(this)
        body.text = if (text.isBlank()) Md.toSpanned("Még nincs letöltött hírösszeállítás. Nyomd meg a Frissítés gombot.")
        else Md.toSpanned(text)
        val ts = Prefs.newsTs(this)
        status.text = if (ts == 0L) "" else
            "Frissítve: " + SimpleDateFormat("MM-dd HH:mm", Locale.US).format(Date(ts)) +
                " · óránként magától is"
    }

    private fun refresh() {
        refreshBtn.isEnabled = false
        status.text = "Hírek letöltése…"
        val app = applicationContext
        Thread {
            val err = try {
                News.refresh(app) { p -> runOnUiThread { status.text = p } }
                null
            } catch (e: Exception) {
                e.message ?: "ismeretlen hiba"
            }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                refreshBtn.isEnabled = true
                show()
                if (err != null) status.text = "Nem sikerült: $err"
            }
        }.start()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
