package hu.atria.uzenetnaplo

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class City(val name: String, val lat: Double, val lon: Double, val url: String = "") {
    fun json(): JSONObject = JSONObject().put("n", name).put("la", lat).put("lo", lon).put("u", url)

    /** A koppintásra nyíló cím: saját link (AccuWeathernél a 30 napos oldalra igazítva), vagy keresés. */
    fun openUrl(): String {
        if (url.isBlank()) {
            return "https://www.accuweather.com/hu/search-locations?query=" +
                URLEncoder.encode(name, "UTF-8")
        }
        return url.replace("/weather-forecast/", "/monthly-weather-forecast/")
            .replace("/daily-weather-forecast/", "/monthly-weather-forecast/")
            .replace("/hourly-weather-forecast/", "/monthly-weather-forecast/")
    }
}

class DayForecast(
    val date: String, val code: Int, val max: Double, val min: Double,
    val rain: Double, val rainProb: Int, val wind: Double,
)

class CityWeather(
    val city: String,
    val nowTemp: Double, val nowFeels: Double, val nowCode: Int,
    val nowWind: Double, val nowHum: Int,
    val sunrise: String, val sunset: String,
    val days: List<DayForecast>,
)

/** Időjárás az Open-Meteo ingyenes, kulcs nélküli szolgáltatásából. */
object Weather {
    private const val KEY = "weather_cities"

    fun cities(ctx: Context): List<City> = try {
        val a = JSONArray(ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).getString(KEY, "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            City(o.getString("n"), o.getDouble("la"), o.getDouble("lo"), o.optString("u"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveCities(ctx: Context, list: List<City>) {
        val a = JSONArray()
        list.forEach { a.put(it.json()) }
        ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply()
    }

    private fun get(url: String): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15_000
            c.readTimeout = 25_000
            c.setRequestProperty("User-Agent", "Uzenetnaplo/1.0")
            if (c.responseCode != 200) throw java.io.IOException("HTTP ${c.responseCode}")
            return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        } finally {
            c.disconnect()
        }
    }

    /** Városkeresés név alapján. Blokkoló. */
    fun geocode(name: String): List<City> {
        val url = "https://geocoding-api.open-meteo.com/v1/search?count=8&language=hu&format=json&name=" +
            URLEncoder.encode(name, "UTF-8")
        val res = get(url).optJSONArray("results") ?: return emptyList()
        return (0 until res.length()).map { i ->
            val o = res.getJSONObject(i)
            val label = listOfNotNull(
                o.optString("name").takeIf { it.isNotBlank() },
                o.optString("admin1").takeIf { it.isNotBlank() },
                o.optString("country").takeIf { it.isNotBlank() },
            ).joinToString(", ")
            City(label, o.getDouble("latitude"), o.getDouble("longitude"))
        }
    }

    /** Egy város előrejelzése. Blokkoló. */
    fun forecast(city: City): CityWeather {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}" +
            "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,relative_humidity_2m" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum," +
            "precipitation_probability_max,wind_speed_10m_max,sunrise,sunset" +
            "&timezone=auto&forecast_days=6"
        val j = get(url)
        val cur = j.getJSONObject("current")
        val d = j.getJSONObject("daily")
        val times = d.getJSONArray("time")
        val days = ArrayList<DayForecast>()
        for (i in 0 until times.length()) {
            days.add(
                DayForecast(
                    times.getString(i),
                    d.getJSONArray("weather_code").optInt(i),
                    d.getJSONArray("temperature_2m_max").optDouble(i),
                    d.getJSONArray("temperature_2m_min").optDouble(i),
                    d.getJSONArray("precipitation_sum").optDouble(i),
                    d.getJSONArray("precipitation_probability_max").optInt(i),
                    d.getJSONArray("wind_speed_10m_max").optDouble(i),
                )
            )
        }
        return CityWeather(
            city.name,
            cur.optDouble("temperature_2m"), cur.optDouble("apparent_temperature"),
            cur.optInt("weather_code"), cur.optDouble("wind_speed_10m"),
            cur.optInt("relative_humidity_2m"),
            d.getJSONArray("sunrise").optString(0).substringAfter('T'),
            d.getJSONArray("sunset").optString(0).substringAfter('T'),
            days,
        )
    }

    /** Minden város lekérése és mentése. Blokkoló. Visszaad: hibák. */
    fun refresh(ctx: Context, progress: ((String) -> Unit)? = null): List<String> {
        val app = ctx.applicationContext
        val errors = ArrayList<String>()
        val arr = JSONArray()
        for (c in cities(app)) {
            progress?.invoke("${c.name}…")
            try {
                val w = forecast(c)
                arr.put(toJson(w))
            } catch (e: Exception) {
                errors.add("${c.name}: ${e.message}")
            }
        }
        try {
            File(app.filesDir, "weather.json").writeText(arr.toString())
            Prefs.setWeatherTs(app, System.currentTimeMillis())
        } catch (_: Exception) {
        }
        return errors
    }

    fun cached(ctx: Context): List<CityWeather> = try {
        val a = JSONArray(File(ctx.filesDir, "weather.json").readText())
        (0 until a.length()).map { fromJson(a.getJSONObject(it)) }
    } catch (e: Exception) {
        emptyList()
    }

    private fun toJson(w: CityWeather): JSONObject {
        val days = JSONArray()
        w.days.forEach {
            days.put(
                JSONObject().put("d", it.date).put("c", it.code).put("mx", it.max).put("mn", it.min)
                    .put("r", it.rain).put("rp", it.rainProb).put("w", it.wind)
            )
        }
        return JSONObject().put("city", w.city).put("t", w.nowTemp).put("f", w.nowFeels)
            .put("c", w.nowCode).put("w", w.nowWind).put("h", w.nowHum)
            .put("sr", w.sunrise).put("ss", w.sunset).put("days", days)
    }

    private fun fromJson(o: JSONObject): CityWeather {
        val a = o.getJSONArray("days")
        val days = (0 until a.length()).map { i ->
            val d = a.getJSONObject(i)
            DayForecast(
                d.getString("d"), d.optInt("c"), d.optDouble("mx"), d.optDouble("mn"),
                d.optDouble("r"), d.optInt("rp"), d.optDouble("w")
            )
        }
        return CityWeather(
            o.getString("city"), o.optDouble("t"), o.optDouble("f"), o.optInt("c"),
            o.optDouble("w"), o.optInt("h"), o.optString("sr"), o.optString("ss"), days
        )
    }

    /** WMO-kód magyarul, hangulatjellel. */
    fun describe(code: Int): String = when (code) {
        0 -> "☀️ derült"
        1 -> "🌤️ túlnyomóan derült"
        2 -> "⛅ részben felhős"
        3 -> "☁️ borult"
        45, 48 -> "🌫️ ködös"
        51, 53, 55 -> "🌦️ szitálás"
        56, 57 -> "🌧️ ónos szitálás"
        61 -> "🌦️ gyenge eső"
        63 -> "🌧️ eső"
        65 -> "🌧️ erős eső"
        66, 67 -> "🌧️ ónos eső"
        71 -> "🌨️ gyenge havazás"
        73 -> "🌨️ havazás"
        75 -> "❄️ erős havazás"
        77 -> "🌨️ hószállingózás"
        80, 81 -> "🌦️ záporok"
        82 -> "⛈️ heves zápor"
        85, 86 -> "🌨️ hózápor"
        95 -> "⛈️ zivatar"
        96, 99 -> "⛈️ jégesős zivatar"
        else -> "időjárás"
    }

    private val huDays = arrayOf("vasárnap", "hétfő", "kedd", "szerda", "csütörtök", "péntek", "szombat")

    fun dayLabel(date: String): String = try {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(date)!!
        val c = java.util.Calendar.getInstance().apply { time = d }
        val today = java.util.Calendar.getInstance()
        val diff = ((c.timeInMillis - today.timeInMillis) / 86_400_000L)
        when {
            isSameDay(c, today) -> "ma"
            diff in 0..1 -> "holnap"
            else -> huDays[c.get(java.util.Calendar.DAY_OF_WEEK) - 1]
        } + " " + SimpleDateFormat("MM.dd.", Locale.US).format(d)
    } catch (e: Exception) {
        date
    }

    private fun isSameDay(a: java.util.Calendar, b: java.util.Calendar) =
        a.get(java.util.Calendar.YEAR) == b.get(java.util.Calendar.YEAR) &&
            a.get(java.util.Calendar.DAY_OF_YEAR) == b.get(java.util.Calendar.DAY_OF_YEAR)
}
