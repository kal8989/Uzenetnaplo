package hu.atria.uzenetnaplo

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Tokenhasználat és költség nyilvántartása. */
object Cost {
    private fun month() = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())

    /** Elkönyveli a felhasználást; visszaadja a kérés árát USD-ben (null, ha az ár ismeretlen). */
    fun record(ctx: Context, model: String, inTok: Long, outTok: Long): Double? {
        val usd = Models.cost(model, inTok, outTok)
        Prefs.addSpend(ctx, month(), inTok, outTok, usd ?: 0.0)
        return usd
    }

    fun format(ctx: Context, usd: Double): String {
        val huf = Prefs.huf(ctx)
        val d = String.format(Locale.US, "%.3f USD", usd)
        return if (huf > 0) "$d (~${Math.round(usd * huf)} Ft)" else d
    }

    /** Becsült ár a prompt hossza alapján (a válasz nélkül). */
    fun estimate(model: String, chars: Int): Double? =
        Models.cost(model, (chars / 3).toLong(), 1500)

    fun monthSummary(ctx: Context): String {
        val (n, tok, usd) = Prefs.spend(ctx, month())
        if (n == 0) return "Ebben a hónapban még nem volt AI-kérés."
        return "Ebben a hónapban: $n kérés, ${tok / 1000} ezer token, ${format(ctx, usd)}"
    }
}
