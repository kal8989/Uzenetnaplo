package hu.atria.uzenetnaplo

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.Build
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Frissítés a GitHub Releases oldalról. */
object Updater {
    private const val REPO = "kal8989/Uzenetnaplo"
    const val AUTHORITY = "hu.atria.uzenetnaplo.update"
    const val APK_MIME = "application/vnd.android.package-archive"

    class Release(val build: Long, val url: String)

    fun installedBuild(ctx: Context): Long {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        return if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode
        else @Suppress("DEPRECATION") pi.versionCode.toLong()
    }

    /** Blokkoló. A legfrissebb kiadás, vagy kivétel. */
    fun latest(): Release {
        val c = URL("https://api.github.com/repos/$REPO/releases/latest").openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15_000
            c.readTimeout = 20_000
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.setRequestProperty("User-Agent", "Uzenetnaplo-app")
            val code = c.responseCode
            if (code != 200) throw IOException("A GitHub nem válaszolt ($code).")
            val json = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val build = json.optString("tag_name").substringAfter("build-").toLongOrNull()
                ?: throw IOException("Ismeretlen kiadásjelölés.")
            val assets = json.getJSONArray("assets")
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk")) return Release(build, a.getString("browser_download_url"))
            }
            throw IOException("A kiadásban nincs APK.")
        } finally {
            c.disconnect()
        }
    }

    fun apkFile(ctx: Context) = File(File(ctx.cacheDir, "update").apply { mkdirs() }, "uzenetnaplo.apk")

    /** Blokkoló letöltés; [progress] 0–100 vagy -1, ha ismeretlen. */
    fun download(ctx: Context, url: String, progress: (Int) -> Unit): File {
        val dest = apkFile(ctx)
        val tmp = File(dest.parentFile, "part.tmp")
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.instanceFollowRedirects = true
            c.connectTimeout = 15_000
            c.readTimeout = 60_000
            c.setRequestProperty("User-Agent", "Uzenetnaplo-app")
            if (c.responseCode != 200) throw IOException("Letöltési hiba (${c.responseCode}).")
            val total = c.contentLengthLong
            var got = 0L
            var last = -2
            c.inputStream.use { inp ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64_000)
                    while (true) {
                        val n = inp.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        got += n
                        val p = if (total > 0) (got * 100 / total).toInt() else -1
                        if (p != last) { last = p; progress(p) }
                    }
                }
            }
            if (total > 0 && got != total) throw IOException("A letöltés megszakadt.")
            if (!tmp.renameTo(dest)) { tmp.copyTo(dest, overwrite = true); tmp.delete() }
            return dest
        } finally {
            c.disconnect()
        }
    }

    fun contentUri(): Uri = Uri.parse("content://$AUTHORITY/uzenetnaplo.apk")
}

/** A letöltött APK átadása a telepítőnek (csak olvasás, ideiglenes engedéllyel). */
class UpdateProvider : ContentProvider() {
    private fun file() = Updater.apkFile(context!!)

    override fun onCreate() = true
    override fun getType(uri: Uri) = Updater.APK_MIME

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        val f = file()
        if (!f.exists()) throw java.io.FileNotFoundException("nincs letöltött frissítés")
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun query(uri: Uri, projection: Array<out String>?, s: String?, a: Array<out String>?, o: String?): Cursor {
        val cols = arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        return MatrixCursor(cols).apply { addRow(arrayOf<Any>("uzenetnaplo.apk", file().length())) }
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, s: String?, a: Array<out String>?) = 0
    override fun update(uri: Uri, v: ContentValues?, s: String?, a: Array<out String>?) = 0
}
