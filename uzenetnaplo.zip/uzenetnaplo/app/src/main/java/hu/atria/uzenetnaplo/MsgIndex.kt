package hu.atria.uzenetnaplo

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.provider.DocumentsContract
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class Msg(val id: Long, val ts: Long, val app: String, val pkg: String, val who: String, val text: String)

class Filter(
    val from: Long?,
    val to: Long?,
    val apps: Set<String>?,
    val hideSys: Boolean,
    val terms: List<String>,
    /** Ha az élő e-mail-keresés be van kapcsolva, a Gmail-értesítések rejtve maradnak. */
    val hideMailApps: Boolean = false,
) {
    fun withoutApp() = Filter(from, to, null, hideSys, terms, hideMailApps)
}

/**
 * Kereső-index (SQLite + FTS4) a naplófájlok fölött.
 * A szövegfájlok maradnak az elsődleges archívum; az index bármikor újraépíthető belőlük.
 */
object MsgIndex {
    /** Minden index- és importművelet ezen az egy szálon fut. */
    val exec = Executors.newSingleThreadExecutor()

    private val nameRe = Regex("""(uzenetek|sms)_(\d{4}-\d{2})\.txt""")
    private val tsRe = Regex("""(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})""")
    private val marks = Regex("\\p{Mn}+")
    private val MAIL_APPS = listOf(
        "com.google.android.gm", "com.samsung.android.email.provider", "com.microsoft.office.outlook",
    )
    private val SMS_APPS = listOf(
        "com.textra", "com.samsung.android.messaging",
        "com.google.android.apps.messaging", "com.android.mms",
    )

    @Volatile private var helper: Helper? = null

    fun norm(s: String): String =
        marks.replace(Normalizer.normalize(s, Normalizer.Form.NFD), "").lowercase(Locale.ROOT)

    /** Indexeléshez és kereséshez: ékezet nélkül, kisbetűvel, írásjelek helyett szóköz. */
    fun normIndex(s: String): String {
        val n = norm(s)
        val sb = StringBuilder(n.length)
        for (ch in n) sb.append(if (ch.isLetterOrDigit()) ch else ' ')
        return sb.toString()
    }

    /** A keresőmező szövegéből képzett keresőszavak. */
    fun terms(query: String): List<String> =
        normIndex(query).split(' ').filter { it.isNotEmpty() }

    private class Helper(ctx: Context) : SQLiteOpenHelper(ctx, "index.db", null, 1) {
        override fun onConfigure(db: SQLiteDatabase) {
            db.enableWriteAheadLogging()
        }

        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL(
                """CREATE TABLE msg(
                    id INTEGER PRIMARY KEY,
                    ts INTEGER NOT NULL,
                    day TEXT NOT NULL,
                    app TEXT NOT NULL,
                    pkg TEXT NOT NULL,
                    who TEXT NOT NULL,
                    body TEXT NOT NULL,
                    src TEXT NOT NULL,
                    sys INTEGER NOT NULL,
                    dup INTEGER NOT NULL DEFAULT 0)"""
            )
            db.execSQL("CREATE INDEX msg_ts ON msg(ts)")
            db.execSQL("CREATE INDEX msg_src ON msg(src)")
            db.execSQL("CREATE INDEX msg_pkg_ts ON msg(pkg, ts)")
            db.execSQL("CREATE VIRTUAL TABLE msg_fts USING fts4(norm)")
            db.execSQL(
                "CREATE TABLE files(name TEXT PRIMARY KEY, size INTEGER, modified INTEGER, offset INTEGER)"
            )
        }

        override fun onUpgrade(db: SQLiteDatabase, oldV: Int, newV: Int) {
            db.execSQL("DROP TABLE IF EXISTS msg")
            db.execSQL("DROP TABLE IF EXISTS msg_fts")
            db.execSQL("DROP TABLE IF EXISTS files")
            onCreate(db)
        }
    }

    private fun db(ctx: Context): SQLiteDatabase {
        val h = helper ?: synchronized(this) {
            helper ?: Helper(ctx.applicationContext).also { helper = it }
        }
        return h.writableDatabase
    }

    /** Az index teljes ürítése (pl. mappaváltáskor). Blokkoló. */
    fun resetNow(ctx: Context) {
        val db = db(ctx)
        db.beginTransaction()
        try {
            db.execSQL("DELETE FROM msg")
            db.execSQL("DELETE FROM msg_fts")
            db.execSQL("DELETE FROM files")
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun reset(ctx: Context) {
        val app = ctx.applicationContext
        exec.execute { resetNow(app) }
    }

    fun totalCount(ctx: Context): Long =
        db(ctx).rawQuery("SELECT count(*) FROM msg", null).use { c -> if (c.moveToFirst()) c.getLong(0) else 0 }

    // ---------------------------------------------------------------- szinkron

    private class FileInfo(val name: String, val uri: Uri, val modified: Long, val size: Long)
    private class Stored(val size: Long, val modified: Long, val offset: Long)

    private fun listFiles(ctx: Context, tree: Uri): List<FileInfo> {
        val parentId = DocumentsContract.getTreeDocumentId(tree)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            DocumentsContract.Document.COLUMN_SIZE,
        )
        val res = ArrayList<FileInfo>()
        ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(1) ?: continue
                if (!nameRe.matches(name)) continue
                res.add(
                    FileInfo(
                        name,
                        DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0)),
                        if (c.isNull(2)) 0 else c.getLong(2),
                        if (c.isNull(3)) 0 else c.getLong(3),
                    )
                )
            }
        }
        return res.sortedBy { it.name }
    }

    /**
     * A naplómappa változásainak beolvasása az indexbe. Blokkoló – az [exec] szálon hívandó.
     * Visszaad: hibaszöveg vagy null.
     */
    fun sync(ctx: Context, progress: ((String) -> Unit)? = null): String? {
        val app = ctx.applicationContext
        val tree = LogWriter.treeUri(app) ?: return "Nincs kiválasztva naplómappa."
        return try {
            val db = db(app)
            val files = listFiles(app, tree)
            val stored = HashMap<String, Stored>()
            db.rawQuery("SELECT name, size, modified, offset FROM files", null).use { c ->
                while (c.moveToNext()) stored[c.getString(0)] = Stored(c.getLong(1), c.getLong(2), c.getLong(3))
            }
            val present = files.map { it.name }.toSet()
            for (gone in stored.keys - present) {
                db.beginTransaction()
                try {
                    deleteSrc(db, gone)
                    db.delete("files", "name=?", arrayOf(gone))
                    db.setTransactionSuccessful()
                } finally {
                    db.endTransaction()
                }
            }
            var changed = false
            for ((i, f) in files.withIndex()) {
                val s = stored[f.name]
                if (s != null && s.size == f.size && s.modified == f.modified) continue
                changed = true
                progress?.invoke("Indexelés: ${f.name} (${i + 1}/${files.size})")
                val append = f.name.startsWith("uzenetek_") && s != null && s.offset in 1 until f.size
                db.beginTransaction()
                try {
                    val offset = if (append) {
                        s!!.offset + readAndInsert(app, db, f, s.offset)
                    } else {
                        deleteSrc(db, f.name)
                        readAndInsert(app, db, f, 0)
                    }
                    val cv = ContentValues().apply {
                        put("name", f.name); put("size", f.size)
                        put("modified", f.modified); put("offset", offset)
                    }
                    db.insertWithOnConflict("files", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
                    db.setTransactionSuccessful()
                } finally {
                    db.endTransaction()
                }
            }
            if (changed) markDuplicates(db)
            null
        } catch (e: Exception) {
            "Indexelési hiba: ${e.message}"
        }
    }

    private fun deleteSrc(db: SQLiteDatabase, src: String) {
        db.execSQL("DELETE FROM msg_fts WHERE docid IN (SELECT id FROM msg WHERE src=?)", arrayOf(src))
        db.execSQL("DELETE FROM msg WHERE src=?", arrayOf(src))
    }

    /** A fájl [start] bájttól való beolvasása. Visszaad: feldolgozott (teljes sorokra eső) bájtok. */
    private fun readAndInsert(ctx: Context, db: SQLiteDatabase, f: FileInfo, start: Long): Long {
        val bytes = ctx.contentResolver.openInputStream(f.uri)?.use { inp ->
            var skip = start
            while (skip > 0) {
                val k = inp.skip(skip)
                if (k > 0) skip -= k
                else if (inp.read() >= 0) skip -= 1
                else break
            }
            inp.readBytes()
        } ?: return 0
        var last = bytes.size - 1
        while (last >= 0 && bytes[last] != '\n'.code.toByte()) last--
        if (last < 0) return 0
        val text = String(bytes, 0, last + 1, Charsets.UTF_8)

        val ins = db.compileStatement(
            "INSERT INTO msg(ts, day, app, pkg, who, body, src, sys) VALUES(?,?,?,?,?,?,?,?)"
        )
        val fts = db.compileStatement("INSERT INTO msg_fts(docid, norm) VALUES(?,?)")
        val cal = Calendar.getInstance()
        try {
            for (line in text.lineSequence()) {
                val p = parse(line, cal) ?: continue
                ins.clearBindings()
                ins.bindLong(1, p.ts)
                ins.bindString(2, p.day)
                ins.bindString(3, p.app)
                ins.bindString(4, p.pkg)
                ins.bindString(5, p.who)
                ins.bindString(6, p.text)
                ins.bindString(7, f.name)
                ins.bindLong(8, if (p.pkg in Prompts.SYS_PKGS) 1 else 0)
                val id = ins.executeInsert()
                fts.clearBindings()
                fts.bindLong(1, id)
                fts.bindString(2, normIndex("${p.app} ${p.who} ${p.text}"))
                fts.executeInsert()
            }
        } finally {
            ins.close(); fts.close()
        }
        return (last + 1).toLong()
    }

    private class Parsed(val ts: Long, val day: String, val app: String, val pkg: String, val who: String, val text: String)

    private fun parse(line: String, cal: Calendar): Parsed? {
        val f = line.split('\t')
        if (f.size < 5) return null
        val m = tsRe.matchEntire(f[0].trim()) ?: return null
        val g = m.groupValues
        cal.clear()
        cal.set(g[1].toInt(), g[2].toInt() - 1, g[3].toInt(), g[4].toInt(), g[5].toInt(), g[6].toInt())
        val text = f.subList(4, f.size).joinToString(" ").replace(" ⏎ ", "\n")
        return Parsed(cal.timeInMillis, "${g[1]}-${g[2]}-${g[3]}", f[1], f[2], f[3], text)
    }

    /** Az SMS-appok értesítéseit elrejti, ha ugyanaz az üzenet az SMS-archívumban is megvan. */
    private fun markDuplicates(db: SQLiteDatabase) {
        val pk = SMS_APPS.joinToString(",") { "'$it'" }
        db.execSQL(
            """UPDATE msg SET dup=1 WHERE dup=0 AND pkg IN ($pk) AND EXISTS (
                 SELECT 1 FROM msg s WHERE s.pkg='sms'
                   AND s.ts BETWEEN msg.ts-300000 AND msg.ts+300000
                   AND (s.body = msg.body OR (length(s.body) > 8 AND instr(msg.body, s.body) > 0)))"""
        )
    }

    // ---------------------------------------------------------------- lekérdezés

    private fun where(f: Filter): Pair<String, Array<String>> {
        val sb = StringBuilder("dup=0")
        val args = ArrayList<String>()
        f.from?.let { sb.append(" AND ts>=?"); args.add(it.toString()) }
        f.to?.let { sb.append(" AND ts<=?"); args.add(it.toString()) }
        f.apps?.let { set ->
            if (set.isEmpty()) sb.append(" AND 0")   // „egyik se”
            else {
                sb.append(" AND app IN (").append(set.joinToString(",") { "?" }).append(")")
                args.addAll(set)
            }
        }
        if (f.hideSys) sb.append(" AND sys=0")
        if (f.hideMailApps) sb.append(" AND pkg NOT IN (${MAIL_APPS.joinToString(",") { "'" + it + "'" }})")
        if (f.terms.isNotEmpty()) {
            sb.append(" AND id IN (SELECT docid FROM msg_fts WHERE msg_fts MATCH ?)")
            args.add(f.terms.joinToString(" ") { "$it*" })
        }
        return sb.toString() to args.toTypedArray()
    }

    /** A szűrt üzenetek azonosítói és időbélyegei, legújabb elöl. */
    fun idsAndTs(ctx: Context, f: Filter): Pair<LongArray, LongArray> {
        val (w, a) = where(f)
        db(ctx).rawQuery("SELECT id, ts FROM msg WHERE $w ORDER BY ts DESC, id DESC", a).use { c ->
            val ids = LongArray(c.count)
            val ts = LongArray(c.count)
            var i = 0
            while (c.moveToNext()) { ids[i] = c.getLong(0); ts[i] = c.getLong(1); i++ }
            return if (i == ids.size) ids to ts else ids.copyOf(i) to ts.copyOf(i)
        }
    }

    fun ids(ctx: Context, f: Filter): LongArray = idsAndTs(ctx, f).first

    /** A levelező appok értesítései az időszakban (id, idő, szöveg) – a párosításhoz. */
    fun mailNotifications(ctx: Context, from: Long?, to: Long?): List<Triple<Long, Long, String>> {
        val sb = StringBuilder("pkg IN (${MAIL_APPS.joinToString(",") { "'" + it + "'" }})")
        val args = ArrayList<String>()
        from?.let { sb.append(" AND ts>=?"); args.add(it.toString()) }
        to?.let { sb.append(" AND ts<=?"); args.add(it.toString()) }
        val out = ArrayList<Triple<Long, Long, String>>()
        db(ctx).rawQuery(
            "SELECT id, ts, who || ' ' || body FROM msg WHERE $sb", args.toTypedArray()
        ).use { c ->
            while (c.moveToNext()) out.add(Triple(c.getLong(0), c.getLong(1), c.getString(2)))
        }
        return out
    }

    fun dayCounts(ctx: Context, f: Filter): Map<String, Int> {
        val (w, a) = where(f)
        val m = HashMap<String, Int>()
        db(ctx).rawQuery("SELECT day, count(*) FROM msg WHERE $w GROUP BY day", a).use { c ->
            while (c.moveToNext()) m[c.getString(0)] = c.getInt(1)
        }
        return m
    }

    fun appCounts(ctx: Context, f: Filter): List<Pair<String, Int>> {
        val (w, a) = where(f.withoutApp())
        val out = ArrayList<Pair<String, Int>>()
        db(ctx).rawQuery("SELECT app, count(*) c FROM msg WHERE $w GROUP BY app ORDER BY c DESC", a).use { c ->
            while (c.moveToNext()) out.add(c.getString(0) to c.getInt(1))
        }
        return out
    }

    /** Az [ids] [from]..[to] szelete, az azonosítók sorrendjében (hiányzó sor helyén null). */
    fun fetch(ctx: Context, ids: LongArray, from: Int, to: Int): Array<Msg?> {
        val n = (to - from).coerceAtLeast(0)
        val out = arrayOfNulls<Msg>(n)
        if (n == 0) return out
        val pos = HashMap<Long, Int>(n * 2)
        val sb = StringBuilder()
        for (i in 0 until n) {
            pos[ids[from + i]] = i
            if (i > 0) sb.append(',')
            sb.append(ids[from + i])
        }
        db(ctx).rawQuery("SELECT id, ts, app, pkg, who, body FROM msg WHERE id IN ($sb)", null).use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val i = pos[id] ?: continue
                out[i] = Msg(id, c.getLong(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5))
            }
        }
        return out
    }

    /** Lusta bejárás lapokban (AI-prompthoz). */
    fun sequence(ctx: Context, ids: LongArray, page: Int = 500): Sequence<Msg> = sequence {
        var i = 0
        while (i < ids.size) {
            val end = minOf(ids.size, i + page)
            for (m in fetch(ctx, ids, i, end)) if (m != null) yield(m)
            i = end
        }
    }

    fun monthOf(ts: Long): String = SimpleDateFormat("yyyy-MM", Locale.US).format(Date(ts))
}
