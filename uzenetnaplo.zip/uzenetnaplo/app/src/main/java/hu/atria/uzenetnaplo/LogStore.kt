package hu.atria.uzenetnaplo

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.text.Normalizer
import java.util.Calendar
import java.util.concurrent.Executors

class Msg(
    val ts: Long,
    val app: String,
    val pkg: String,
    val who: String,
    val text: String,
) {
    val norm: String = LogStore.norm("$app $who $text")
}

/** A havi naplófájlok beolvasása (gyorsítótárral) a nézegetőhöz. */
object LogStore {
    private val exec = Executors.newSingleThreadExecutor()
    private class Cached(val modified: Long, val size: Long, val msgs: List<Msg>)
    private val cache = HashMap<String, Cached>()
    private val nameRe = Regex("""uzenetek_(\d{4}-\d{2})\.txt""")
    private val tsRe = Regex("""(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2}):(\d{2})""")
    private val marks = Regex("\\p{Mn}+")

    fun norm(s: String): String =
        marks.replace(Normalizer.normalize(s, Normalizer.Form.NFD), "").lowercase()

    fun clearCache() = exec.execute { cache.clear() }

    /**
     * A [fromMonth]..[toMonth] (ÉÉÉÉ-HH, null = nyitott) hónapok üzenetei, legújabb elöl.
     * Hiba esetén üres lista + hibaszöveg.
     */
    fun load(ctx: Context, fromMonth: String?, toMonth: String?, done: (List<Msg>, String?) -> Unit) {
        val app = ctx.applicationContext
        exec.execute {
            val tree = LogWriter.treeUri(app)
            if (tree == null) {
                done(emptyList(), "Nincs kiválasztva naplómappa.")
                return@execute
            }
            try {
                val out = ArrayList<Msg>()
                for (f in listFiles(app, tree)) {
                    if (fromMonth != null && f.month < fromMonth) continue
                    if (toMonth != null && f.month > toMonth) continue
                    val c = cache[f.name]
                    val msgs = if (c != null && c.modified == f.modified && c.size == f.size) c.msgs
                    else readFile(app, f.uri).also { cache[f.name] = Cached(f.modified, f.size, it) }
                    out.addAll(msgs)
                }
                out.sortByDescending { it.ts }
                done(out, null)
            } catch (e: Exception) {
                done(emptyList(), "A napló nem olvasható: ${e.message}")
            }
        }
    }

    private class FileInfo(val name: String, val month: String, val uri: Uri, val modified: Long, val size: Long)

    private fun listFiles(ctx: Context, tree: Uri): List<FileInfo> {
        val parentId = DocumentsContract.getTreeDocumentId(tree)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
            DocumentsContract.Document.COLUMN_SIZE,
        )
        val res = ArrayList<FileInfo>()
        ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(1) ?: continue
                val m = nameRe.matchEntire(name) ?: continue
                res.add(
                    FileInfo(
                        name, m.groupValues[1],
                        DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0)),
                        if (c.isNull(2)) 0 else c.getLong(2),
                        if (c.isNull(3)) 0 else c.getLong(3),
                    )
                )
            }
        }
        return res
    }

    private fun readFile(ctx: Context, uri: Uri): List<Msg> {
        val list = ArrayList<Msg>()
        val cal = Calendar.getInstance()
        ctx.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { r ->
            r.lineSequence().forEach { line -> parse(line, cal)?.let(list::add) }
        }
        return list
    }

    private fun parse(line: String, cal: Calendar): Msg? {
        val f = line.split('\t')
        if (f.size < 5) return null
        val m = tsRe.matchEntire(f[0].trim()) ?: return null
        val g = m.groupValues
        cal.clear()
        cal.set(g[1].toInt(), g[2].toInt() - 1, g[3].toInt(), g[4].toInt(), g[5].toInt(), g[6].toInt())
        val text = f.subList(4, f.size).joinToString(" ").replace(" ⏎ ", "\n")
        return Msg(cal.timeInMillis, f[1], f[2], f[3], text)
    }
}
