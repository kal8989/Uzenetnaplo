package hu.atria.uzenetnaplo

import android.app.Notification
import android.app.Person
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Parcelable
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Minden megjelenő értesítést kiír a naplóba.
 * Sorformátum (tabulátorral tagolva):
 *   dátum idő | app neve | csomagnév | beszélgetés / feladó | szöveg
 */
class NotificationLogService : NotificationListenerService() {

    private val seen = object : LinkedHashMap<String, Boolean>(512, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Boolean>?) =
            size > MAX_SEEN
    }
    private val labels = HashMap<String, String>()
    private val seenFile by lazy { File(filesDir, "seen.txt") }

    override fun onCreate() {
        super.onCreate()
        try {
            if (seenFile.exists()) seenFile.readLines().forEach { if (it.isNotBlank()) seen[it] = true }
        } catch (_: Exception) {
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        // Újraindulás után a még fent lévő értesítéseket is feldolgozzuk (duplikátumszűréssel)
        try {
            activeNotifications?.forEach { handle(it) }
        } catch (_: Exception) {
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            handle(sbn)
        } catch (_: Exception) {
        }
    }

    private fun handle(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        val flags = n.flags
        if (flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (flags and Notification.FLAG_ONGOING_EVENT != 0) return
        if (flags and Notification.FLAG_FOREGROUND_SERVICE != 0) return

        val ex = n.extras ?: return
        val pkg = sbn.packageName
        val app = label(pkg)
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val conv = ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString().orEmpty()

        val out = ArrayList<Entry>()

        // 1) Csevegőappok (WhatsApp, Messenger, Viber, SMS…): üzenetenként
        val msgs = messages(ex)
        if (msgs.isNotEmpty()) {
            for (m in msgs) {
                val who = listOf(conv, m.sender.ifEmpty { if (conv.isEmpty()) title else "" })
                    .filter { it.isNotEmpty() }.joinToString(" / ")
                add(out, m.time, app, pkg, who, m.text)
            }
        } else {
            // 2) Minden más: cím + (hosszú) szöveg
            val big = ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            val lines = ex.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
                ?.joinToString(" / ") { it.toString() }
            val text = big?.takeIf { it.isNotBlank() }
                ?: ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.takeIf { it.isNotBlank() }
                ?: lines.orEmpty()
            val sub = ex.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString().orEmpty()
            val who = listOf(title, sub).filter { it.isNotEmpty() }.joinToString(" / ")
            val time = if (n.`when` > 0) n.`when` else sbn.postTime
            add(out, time, app, pkg, who, text)
        }

        if (out.isNotEmpty()) {
            LogWriter.append(this, out)
            val snapshot = seen.keys.toList()
            LogWriter.run {
                try {
                    seenFile.writeText(snapshot.joinToString("\n"))
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun add(out: MutableList<Entry>, time: Long, app: String, pkg: String, who: String, text: String) {
        if (text.isBlank() && who.isBlank()) return
        val key = hash("$pkg\u0001$who\u0001$text\u0001$time")
        if (seen.containsKey(key)) return
        seen[key] = true
        val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(time))
        val line = listOf(ts, app, pkg, who, text).joinToString("\t") { clean(it) }
        out.add(Entry(time, line))
    }

    private data class Msg(val time: Long, val sender: String, val text: String)

    /** Notification.MessagingStyle üzenetei a nyers Bundle-ökből. */
    @Suppress("DEPRECATION")
    private fun messages(ex: Bundle): List<Msg> {
        val arr: Array<Parcelable> = ex.getParcelableArray(Notification.EXTRA_MESSAGES) ?: return emptyList()
        val result = ArrayList<Msg>()
        for (p in arr) {
            val b = p as? Bundle ?: continue
            val text = b.getCharSequence("text")?.toString() ?: continue
            val time = b.getLong("time")
            var sender = b.getCharSequence("sender")?.toString().orEmpty()
            if (sender.isEmpty() && Build.VERSION.SDK_INT >= 28) {
                val person = b.getParcelable<Parcelable>("sender_person") as? Person
                sender = person?.name?.toString().orEmpty()
            }
            if (sender.isEmpty()) sender = "Én"   // saját elküldött üzenet
            result.add(Msg(if (time > 0) time else System.currentTimeMillis(), sender, text))
        }
        return result
    }

    private fun label(pkg: String): String = labels.getOrPut(pkg) {
        try {
            val info = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(info).toString()
        } catch (e: PackageManager.NameNotFoundException) {
            pkg
        }
    }

    companion object {
        private const val MAX_SEEN = 3000

        fun clean(s: String): String =
            s.replace("\r\n", "\n").replace('\r', '\n').trim()
                .replace("\n", " ⏎ ").replace('\t', ' ')

        fun hash(s: String): String {
            val d = MessageDigest.getInstance("SHA-1").digest(s.toByteArray(Charsets.UTF_8))
            return d.take(8).joinToString("") { "%02x".format(it) }
        }
    }
}
