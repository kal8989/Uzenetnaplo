package hu.atria.uzenetnaplo

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Lépésszám a telefon beépített számlálójából (könyvtár nélkül). */
object Health {
    private const val PREFS = "health"
    private fun sp(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun enabled(ctx: Context) = sp(ctx).getBoolean("on", false)
    fun setEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("on", v).apply()

    /** Lépéshossz méterben. */
    fun stride(ctx: Context) = sp(ctx).getFloat("stride", 0.75f)
    fun setStride(ctx: Context, v: Float) = sp(ctx).edit().putFloat("stride", v).apply()

    fun hasPermission(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 29 ||
            ctx.checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED

    private fun key(offset: Int): String = dayFmt.format(
        Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, offset) }.time
    )

    fun steps(ctx: Context, dayOffset: Int = 0): Int = sp(ctx).getInt("d_${key(dayOffset)}", 0)

    fun km(ctx: Context, steps: Int): Double = steps * stride(ctx) / 1000.0

    fun lastSample(ctx: Context) = sp(ctx).getLong("ts", 0)

    /**
     * Egyetlen mintavétel a lépésszámlálóból; a különbséget a mai naphoz adja.
     * Nem blokkol, a [done] a mintavétel után fut (vagy azonnal, ha nincs szenzor).
     */
    fun sample(ctx: Context, done: (() -> Unit)? = null) {
        val app = ctx.applicationContext
        if (!enabled(app) || !hasPermission(app)) { done?.invoke(); return }
        val sm = app.getSystemService(SensorManager::class.java)
        val sensor = sm?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        if (sensor == null) { done?.invoke(); return }
        var handled = false
        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                if (handled) return
                handled = true
                store(app, e.values.firstOrNull() ?: 0f)
                try { sm.unregisterListener(this) } catch (_: Exception) {}
                done?.invoke()
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        // ha 5 mp alatt nem jön adat, feladjuk
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (!handled) {
                handled = true
                try { sm.unregisterListener(listener) } catch (_: Exception) {}
                done?.invoke()
            }
        }, 5000)
    }

    private fun store(ctx: Context, raw: Float) {
        val p = sp(ctx)
        val last = p.getFloat("raw", -1f)
        val today = "d_${key(0)}"
        val e = p.edit()
        if (last >= 0 && raw >= last) {
            val delta = (raw - last).toInt()
            if (delta in 0..50_000) e.putInt(today, p.getInt(today, 0) + delta)
        }
        e.putFloat("raw", raw).putLong("ts", System.currentTimeMillis())
        // a 10 napnál régebbi napokat töröljük
        val keep = (0..9).map { "d_${key(-it)}" }.toSet()
        p.all.keys.filter { it.startsWith("d_") && it !in keep }.forEach { e.remove(it) }
        e.apply()
    }

    /** Rövid összefoglaló a főképernyőre. */
    fun summary(ctx: Context): String {
        if (!enabled(ctx) || !hasPermission(ctx)) return ""
        val t = steps(ctx, 0)
        val y = steps(ctx, -1)
        val km = String.format(Locale.US, "%.1f", km(ctx, t))
        return "👟 " + "%,d".format(t).replace(',', ' ') + " lépés · $km km" +
            if (y > 0) " · tegnap " + "%,d".format(y).replace(',', ' ') else ""
    }
}
