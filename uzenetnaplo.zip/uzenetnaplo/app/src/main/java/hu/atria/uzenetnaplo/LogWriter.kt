package hu.atria.uzenetnaplo

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/** Egy naplósor: időbélyeg (ms) + kész, tabulátorral tagolt szöveg. */
data class Entry(val time: Long, val line: String)

/**
 * A naplófájlok írása. Havi fájlok: uzenetek_ÉÉÉÉ-HH.txt a kiválasztott mappában.
 * Amíg nincs mappa kiválasztva (vagy az írás hibázik), az app belső
 * "pending" mappájába gyűjt, és később átmásolja.
 */
object LogWriter {
    private val exec = Executors.newSingleThreadExecutor()
    private val uriCache = HashMap<String, Uri>()

    private const val PREFS = "cfg"
    private const val KEY_TREE = "tree"

    fun treeUri(ctx: Context): Uri? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_TREE, null)?.let(Uri::parse)

    fun setTreeUri(ctx: Context, uri: Uri) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_TREE, uri.toString()).apply()
        exec.execute {
            uriCache.clear()
            flushPending(ctx.applicationContext)
        }
    }

    fun fileName(time: Long): String =
        "uzenetek_" + SimpleDateFormat("yyyy-MM", Locale.US).format(Date(time)) + ".txt"

    fun append(ctx: Context, entries: List<Entry>) {
        if (entries.isEmpty()) return
        val app = ctx.applicationContext
        exec.execute { writeNow(app, entries) }
    }

    /** Háttérszálon futtat tetszőleges feladatot (a sorrend megmarad). */
    fun run(task: () -> Unit) = exec.execute(task)

    private fun pendingDir(ctx: Context) = File(ctx.filesDir, "pending").apply { mkdirs() }

    private fun writeNow(ctx: Context, entries: List<Entry>) {
        val tree = treeUri(ctx)
        if (tree != null) flushPending(ctx)
        for ((name, list) in entries.groupBy { fileName(it.time) }) {
            val text = list.joinToString(separator = "") { it.line + "\n" }
            val ok = tree != null && appendToTree(ctx, tree, name, text)
            if (!ok) File(pendingDir(ctx), name).appendText(text, Charsets.UTF_8)
        }
    }

    private fun flushPending(ctx: Context) {
        val tree = treeUri(ctx) ?: return
        val files = pendingDir(ctx).listFiles() ?: return
        for (f in files.sortedBy { it.name }) {
            val text = f.readText(Charsets.UTF_8)
            if (text.isEmpty() || appendToTree(ctx, tree, f.name, text)) f.delete()
        }
    }

    fun pendingCount(ctx: Context): Int =
        pendingDir(ctx).listFiles()?.sumOf { f -> f.useLines { it.count() } } ?: 0

    private fun appendToTree(ctx: Context, tree: Uri, name: String, text: String): Boolean {
        for (attempt in 0..1) {
            try {
                val uri = findOrCreate(ctx, tree, name)
                val out = ctx.contentResolver.openOutputStream(uri, "wa")
                    ?: throw IllegalStateException("nem nyitható: $uri")
                out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                return true
            } catch (e: Exception) {
                // pl. a fájlt közben törölték: gyorsítótár ürítése, újrapróbálás
                uriCache.remove(name)
            }
        }
        return false
    }

    private fun findOrCreate(ctx: Context, tree: Uri, name: String): Uri {
        uriCache[name]?.let { return it }
        val found = findChild(ctx, tree, name)
        if (found != null) {
            uriCache[name] = found
            return found
        }
        val parent = DocumentsContract.buildDocumentUriUsingTree(
            tree, DocumentsContract.getTreeDocumentId(tree)
        )
        val created = DocumentsContract.createDocument(ctx.contentResolver, parent, "text/plain", name)
            ?: throw IllegalStateException("nem hozható létre: $name")
        uriCache[name] = created
        return created
    }

    fun findChild(ctx: Context, tree: Uri, name: String): Uri? {
        val parentId = DocumentsContract.getTreeDocumentId(tree)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME
        )
        ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                if (c.getString(1) == name) {
                    return DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0))
                }
            }
        }
        return null
    }

    /** Az aktuális havi fájl utolsó n sora (az előnézethez). */
    fun tail(ctx: Context, n: Int): List<String> {
        val tree = treeUri(ctx) ?: return emptyList()
        val uri = try {
            findChild(ctx, tree, fileName(System.currentTimeMillis()))
        } catch (e: Exception) {
            null
        } ?: return emptyList()
        val buf = ArrayDeque<String>()
        try {
            ctx.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { r ->
                r.lineSequence().forEach {
                    buf.addLast(it)
                    if (buf.size > n) buf.removeFirst()
                }
            }
        } catch (e: Exception) {
            return listOf("(olvasási hiba: ${e.message})")
        }
        return buf.toList()
    }
}
