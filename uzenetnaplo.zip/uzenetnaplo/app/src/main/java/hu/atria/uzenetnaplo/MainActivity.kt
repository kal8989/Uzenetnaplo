package hu.atria.uzenetnaplo

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var preview: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = dp(16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        status = TextView(this).apply { textSize = 16f }
        root.addView(status)

        root.addView(button("1. Értesítés-hozzáférés megadása") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(button("2. Célmappa kiválasztása") {
            @Suppress("DEPRECATION")
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_TREE)
        })
        root.addView(button("3. Akkumulátor-optimalizálás kikapcsolása") {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })
        root.addView(button("Tesztbejegyzés írása") {
            val now = System.currentTimeMillis()
            val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(now))
            LogWriter.append(this, listOf(Entry(now, "$ts\tÜzenetnapló\t$packageName\tTeszt\tMűködik ✓")))
            Toast.makeText(this, "Tesztsor elküldve", Toast.LENGTH_SHORT).show()
            status.postDelayed({ refresh() }, 800)
        })
        root.addView(button("Frissítés") { refresh() })

        root.addView(TextView(this).apply {
            text = "\nUtolsó bejegyzések (aktuális hónap):"
            setTypeface(typeface, Typeface.BOLD)
        })
        preview = TextView(this).apply {
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
        }
        root.addView(preview)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        if (listenerEnabled()) {
            // ha a rendszer leállította a figyelőt, újrakötjük
            NotificationListenerService.requestRebind(
                ComponentName(this, NotificationLogService::class.java)
            )
        }
        refresh()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_TREE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            LogWriter.setTreeUri(this, uri)
            status.postDelayed({ refresh() }, 500)
        }
    }

    private fun refresh() {
        val listener = listenerEnabled()
        val tree = LogWriter.treeUri(this)
        val pm = getSystemService(PowerManager::class.java)
        val battery = pm?.isIgnoringBatteryOptimizations(packageName) == true
        val ctx = applicationContext

        LogWriter.run {
            val pending = LogWriter.pendingCount(ctx)
            val lines = LogWriter.tail(ctx, 30)
            runOnUiThread {
                status.text = buildString {
                    append(mark(listener)).append(" Értesítés-hozzáférés\n")
                    append(mark(tree != null)).append(" Célmappa: ")
                        .append(tree?.lastPathSegment?.substringAfter(':') ?: "nincs kiválasztva").append('\n')
                    append(mark(battery)).append(" Akkumulátor-optimalizálás kikapcsolva\n")
                    append("Fájl: ").append(LogWriter.fileName(System.currentTimeMillis())).append('\n')
                    if (pending > 0) append("Átmásolásra vár: ").append(pending).append(" sor\n")
                }
                preview.text = if (lines.isEmpty()) "(még nincs bejegyzés)"
                else lines.reversed().joinToString("\n\n") { it.replace('\t', '│') }
            }
        }
    }

    private fun listenerEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return flat.split(':').any {
            ComponentName.unflattenFromString(it)?.packageName == packageName
        }
    }

    private fun mark(ok: Boolean) = if (ok) "✅" else "❌"

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener(View.OnClickListener { action() })
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQ_TREE = 42
    }
}
