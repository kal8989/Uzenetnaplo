package hu.atria.uzenetnaplo

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Nézegető: kereshető lista (SQLite-indexből, lapozva) + AI-elemzés. */
class MainActivity : Activity() {

    private val hu = Locale("hu", "HU")
    private val keyFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val dayFmt = SimpleDateFormat("yyyy. MMMM d., EEEE", hu)
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.US)
    private val shortFmt = SimpleDateFormat("yyyy.MM.dd.", Locale.US)
    private val main = Handler(Looper.getMainLooper())

    private lateinit var pal: Palette
    private var themeDark = false
    private var gradState = 0

    // állapot
    private var from: Long? = null
    private var to: Long? = null
    private var rangeId = "7"
    private var ids: LongArray = LongArray(0)
    private var idTs: LongArray = LongArray(0)
    private var mails: List<MailItem> = emptyList()
    private var order: IntArray = IntArray(0)
    private var mailGen = 0
    private var hiddenIds: Set<Long> = emptySet()
    private var dayCounts: Map<String, Int> = emptyMap()
    private var appNames: List<String> = emptyList()
    private var appCounts: List<Pair<String, Int>> = emptyList()
    private var selectedApps: MutableSet<String>? = null   // null = mind
    private var terms: List<String> = emptyList()
    private var loadGen = 0
    private val pages = object : LinkedHashMap<Int, Array<Msg?>>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Int, Array<Msg?>>?) = size > 30
    }

    // nézetek
    private lateinit var search: EditText
    private lateinit var banner: TextView
    private lateinit var updBanner: TextView
    private lateinit var rangeRow: LinearLayout
    private lateinit var appBtn: Button
    private lateinit var infoView: TextView
    private lateinit var hideSys: CheckBox
    private lateinit var showMail: CheckBox
    private lateinit var mailStatus: TextView
    private lateinit var countView: TextView
    private lateinit var aiStatus: TextView
    private lateinit var aiAnswer: TextView
    private lateinit var stopBtn: Button
    private lateinit var aiButtons: List<Button>
    private lateinit var aiToggle: Button
    private lateinit var aiPanel: LinearLayout
    private var aiTitle = ""
    private var aiHasContent = false
    private val adapter = MsgAdapter()

    private var ai: AiClient? = null
    private var aiGen = 0
    private var suppressSpinner = false

    override fun onCreate(savedInstanceState: Bundle?) {
        pal = Ui.apply(this)
        themeDark = pal.dark
        gradState = gradSignature()
        super.onCreate(savedInstanceState)
        val pad = dp(12)

        // felső sáv: kereső + beállítások
        search = EditText(this).apply {
            hint = "Keresés (ékezet nélkül is)"
            setSingleLine()
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val settingsBtn = Button(this).apply {
            text = "⚙"
            textSize = 20f
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, dp(4), dp(4), 0)
            addView(search)
            addView(settingsBtn)
        }

        // lista fejléce: szűrők + AI
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, 0, pad, dp(8))
        }
        banner = TextView(this).apply {
            setBackgroundColor(pal.bannerBg)
            setTextColor(pal.bannerText)
            setPadding(pad, pad, pad, pad)
            text = "A naplózás nincs teljesen beállítva – koppints ide."
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
            visibility = View.GONE
        }
        header.addView(banner)
        updBanner = TextView(this).apply {
            setBackgroundColor(pal.infoBg)
            setTextColor(pal.text)
            setPadding(pad, pad, pad, pad)
            visibility = View.GONE
            setOnClickListener {
                startActivity(
                    Intent(this@MainActivity, SettingsActivity::class.java)
                        .putExtra(SettingsActivity.EXTRA_UPDATE, true)
                )
            }
        }
        header.addView(updBanner)

        rangeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            "today" to "Ma", "yesterday" to "Tegnap", "7" to "7 nap", "30" to "30 nap",
            "365" to "1 év", "all" to "Mind", "custom" to "Egyéni…",
        ).forEach { (id, label) ->
            rangeRow.addView(smallButton(label).apply {
                tag = id
                setOnClickListener { if (id == "custom") pickCustom() else setRange(id) }
            })
        }
        header.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(rangeRow)
        })

        appBtn = smallButton("Alkalmazások").apply {
            setOnClickListener { pickApps() }
        }
        infoView = TextView(this).apply {
            textSize = 13f
            setTextColor(pal.muted)
            setPadding(dp(8), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { startActivity(Intent(this@MainActivity, WeatherActivity::class.java)) }
        }
        header.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(appBtn)
            addView(infoView)
        })

        hideSys = CheckBox(this).apply {
            text = "Rendszerértesítések elrejtése"
            setTextColor(pal.text)
            isChecked = true
            setOnCheckedChangeListener { _, _ -> reload(sync = false) }
        }
        header.addView(hideSys)
        showMail = CheckBox(this).apply {
            text = "E-mailek keresése a Gmail-fiókokban"
            setTextColor(pal.text)
            isChecked = false
            setOnCheckedChangeListener { _, on ->
                if (on && MailStore.enabledAccounts(this@MainActivity).isEmpty()) {
                    Toast.makeText(this@MainActivity, "Előbb vedd fel a fiókokat: ⚙ → E-mail-fiókok", Toast.LENGTH_LONG).show()
                    isChecked = false
                    startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
                } else reload(sync = false)
            }
        }
        header.addView(showMail)
        mailStatus = TextView(this).apply { setTextColor(pal.muted); textSize = 13f }
        header.addView(mailStatus)

        countView = TextView(this).apply {
            textSize = 15f
            setTextColor(pal.text)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }
        header.addView(countView)

        header.addView(TextView(this).apply {
            text = "AI-elemzés a szűrt üzenetekről"
            textSize = 16f
            setTextColor(pal.accent)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(10), 0, 0)
        })
        val aiRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btns = ArrayList<Button>()
        listOf(
            "Összefoglaló" to Prompts.TASK_SUM, "Teendők" to Prompts.TASK_TODO,
            "Fontosak" to Prompts.TASK_IMP, "Ki miről" to Prompts.TASK_WHO,
        ).forEach { (label, task) ->
            btns.add(smallButton(label).apply { setOnClickListener { ask(label, task) } })
        }
        btns.add(smallButton("Saját kérdés…").apply { setOnClickListener { askCustom() } })
        btns.add(smallButton("Reggeli összefoglaló").apply { setOnClickListener { showSummary() } })
        btns.add(smallButton("Hírek").apply {
            setOnClickListener { startActivity(Intent(this@MainActivity, NewsActivity::class.java)) }
        })
        btns.add(smallButton("Időjárás").apply {
            setOnClickListener { startActivity(Intent(this@MainActivity, WeatherActivity::class.java)) }
        })
        btns.forEach { aiRow.addView(it) }
        aiButtons = btns
        header.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(aiRow)
        })
        aiToggle = smallButton("").apply {
            visibility = View.GONE
            setTextColor(pal.accent)
            setOnClickListener { if (aiPanel.visibility == View.VISIBLE) collapseAi() else expandAi() }
        }
        header.addView(aiToggle)
        aiPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        aiStatus = TextView(this).apply { setTextColor(pal.muted); textSize = 13f }
        aiPanel.addView(aiStatus)
        stopBtn = smallButton("Leállítás").apply {
            visibility = View.GONE
            setOnClickListener { stopAi("Leállítva.") }
        }
        aiPanel.addView(stopBtn)
        aiAnswer = TextView(this).apply {
            setTextIsSelectable(true)
            textSize = 15f
            setTextColor(pal.text)
            setLinkTextColor(pal.accent)
            setPadding(0, dp(4), 0, dp(8))
        }
        aiPanel.addView(aiAnswer)
        header.addView(aiPanel)

        val list = object : ListView(this) {
            private var startY = 0f
            private var pulling = false

            override fun onTouchEvent(ev: android.view.MotionEvent): Boolean {
                when (ev.actionMasked) {
                    android.view.MotionEvent.ACTION_DOWN -> {
                        startY = ev.y
                        pulling = firstVisiblePosition == 0 &&
                            (getChildAt(0)?.top ?: 0) >= 0
                    }
                    android.view.MotionEvent.ACTION_MOVE -> {
                        if (pulling && ev.y - startY > dp(110)) {
                            pulling = false
                            pullRefresh()
                        }
                    }
                    android.view.MotionEvent.ACTION_UP,
                    android.view.MotionEvent.ACTION_CANCEL -> pulling = false
                }
                return super.onTouchEvent(ev)
            }
        }.apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            addHeaderView(header, null, false)
            adapter = this@MainActivity.adapter
            divider = null
            isFastScrollEnabled = true
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
            cacheColorHint = android.graphics.Color.TRANSPARENT
            setOnItemClickListener { _, _, pos, _ ->
                val p = pos - headerViewsCount
                mailAt(p)?.let { openMail(it) }
            }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.background(this@MainActivity, pal)
            addView(top)
            addView(list)
        })

        val debounce = Runnable { reload(sync = false) }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                main.removeCallbacks(debounce)
                main.postDelayed(debounce, 350)
            }
        })

        setRange("7", load = false)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        if (Ui.isDark(this) != themeDark || gradSignature() != gradState) { recreate(); return }
        val ok = Prefs.listenerEnabled(this) && LogWriter.treeUri(this) != null
        banner.visibility = if (ok) View.GONE else View.VISIBLE
        refreshInfo()
        checkUpdateQuietly()
        reload(sync = true)
    }

    override fun onDestroy() {
        stopAi(null)
        super.onDestroy()
    }

    private fun gradSignature(): Int =
        (if (Prefs.gradient(this)) 1 else 0) * 31 + Prefs.gradTop(this) * 7 + Prefs.gradBottom(this)

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra(Daily.EXTRA_SHOW_SUMMARY, false) == true) {
            i.removeExtra(Daily.EXTRA_SHOW_SUMMARY)
            showSummary()
        }
    }

    // ---------- időszak ----------
    private fun startOfDay(offset: Int): Long = Calendar.getInstance().run {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        add(Calendar.DAY_OF_MONTH, offset)
        timeInMillis
    }

    private fun setRange(id: String, load: Boolean = true) {
        rangeId = id
        when (id) {
            "today" -> { from = startOfDay(0); to = startOfDay(1) - 1 }
            "yesterday" -> { from = startOfDay(-1); to = startOfDay(0) - 1 }
            "7" -> { from = startOfDay(-6); to = startOfDay(1) - 1 }
            "30" -> { from = startOfDay(-29); to = startOfDay(1) - 1 }
            "365" -> { from = startOfDay(-364); to = startOfDay(1) - 1 }
            "all" -> { from = null; to = null }
        }
        markRange()
        if (load) reload(sync = false)
    }

    private fun markRange() {
        for (i in 0 until rangeRow.childCount) {
            val b = rangeRow.getChildAt(i) as Button
            val on = b.tag == rangeId
            b.setTextColor(if (on) pal.accent else pal.text)
            b.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
            if (b.tag == "custom") {
                b.text = if (on && from != null && to != null)
                    "${shortFmt.format(Date(from!!))}–${shortFmt.format(Date(to!!))}" else "Egyéni…"
            }
        }
    }

    private fun pickCustom() {
        val cal = { y: Int, m: Int, d: Int -> Calendar.getInstance().apply { clear(); set(y, m, d) } }
        val now = Calendar.getInstance()
        val y = now.get(Calendar.YEAR)
        val mo = now.get(Calendar.MONTH)
        val presets = ArrayList<Pair<String, Pair<Long, Long>>>()
        fun monthRange(c: Calendar): Pair<Long, Long> {
            val a = c.timeInMillis
            c.add(Calendar.MONTH, 1)
            return a to c.timeInMillis - 1
        }
        presets.add("Ez a hónap" to monthRange(cal(y, mo, 1)))
        presets.add("Előző hónap" to monthRange(cal(y, mo, 1).apply { add(Calendar.MONTH, -1) }))
        presets.add("Idén" to (cal(y, 0, 1).timeInMillis to cal(y + 1, 0, 1).timeInMillis - 1))
        presets.add("Tavaly" to (cal(y - 1, 0, 1).timeInMillis to cal(y, 0, 1).timeInMillis - 1))

        val recent = Prefs.history(this, HIST_RANGES).mapNotNull { r ->
            val parts = r.split('|')
            if (parts.size != 2) return@mapNotNull null
            val a = runCatching { keyFmt.parse(parts[0])?.time }.getOrNull() ?: return@mapNotNull null
            val b = runCatching { keyFmt.parse(parts[1])?.time }.getOrNull() ?: return@mapNotNull null
            val end = Calendar.getInstance().apply { timeInMillis = b; add(Calendar.DAY_OF_MONTH, 1) }.timeInMillis - 1
            "${shortFmt.format(Date(a))} – ${shortFmt.format(Date(b))}" to (a to end)
        }

        val labels = ArrayList<String>()
        val ranges = ArrayList<Pair<Long, Long>?>()
        labels.add("📅  Új időszak választása…"); ranges.add(null)
        presets.forEach { labels.add(it.first); ranges.add(it.second) }
        recent.forEach { labels.add("🕘  ${it.first}"); ranges.add(it.second) }

        val b = AlertDialog.Builder(this)
            .setTitle("Időszak")
            .setItems(labels.toTypedArray()) { _, which ->
                val r = ranges[which]
                if (r == null) pickNewRange() else applyCustom(r.first, r.second, remember = false)
            }
            .setNegativeButton("Mégse", null)
        if (recent.isNotEmpty()) b.setNeutralButton("Előzmények törlése") { _, _ ->
            Prefs.clearHistory(this, HIST_RANGES)
        }
        b.show()
    }

    private fun pickNewRange() {
        val c = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            val start = Calendar.getInstance().apply { clear(); set(y, m, d) }.timeInMillis
            DatePickerDialog(this, { _, y2, m2, d2 ->
                val endCal = Calendar.getInstance().apply {
                    clear(); set(y2, m2, d2); add(Calendar.DAY_OF_MONTH, 1)
                }
                val end = endCal.timeInMillis - 1
                applyCustom(minOf(start, end), maxOf(start, end), remember = true)
            }, y, m, d).apply { setTitle("Vége") }.show()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH))
            .apply { setTitle("Kezdete") }.show()
    }

    private fun applyCustom(a: Long, b: Long, remember: Boolean) {
        from = a; to = b
        rangeId = "custom"
        if (remember) Prefs.pushHistory(this, HIST_RANGES, "${keyFmt.format(Date(a))}|${keyFmt.format(Date(b))}", 10)
        markRange()
        reload(sync = false)
    }

    // ---------- adatok ----------
    private fun currentFilter(): Filter {
        terms = MsgIndex.terms(search.text.toString())
        return Filter(from, to, selectedApps, hideSys.isChecked, terms)
    }

    /** Lefelé húzás: keresőmező ürítése és teljes frissítés. */
    private fun pullRefresh() {
        if (search.text.isNotEmpty()) search.setText("")
        countView.text = "Frissítés…"
        reload(sync = true)
    }

    private fun reload(sync: Boolean) {
        if (!sync) collapseAi() // a szűrés megváltozott – az előző elemzés már nem erre vonatkozik
        val gen = ++loadGen
        val f = currentFilter()
        val app = applicationContext
        if (ids.isEmpty()) countView.text = "Betöltés…"
        MsgIndex.exec.execute {
            var err: String? = null
            if (sync) {
                SmsImport.quickSyncIfDue(app)
                err = MsgIndex.sync(app) { p ->
                    runOnUiThread { if (gen == loadGen) countView.text = p }
                }
            }
            val apps = MsgIndex.appCounts(app, f)
            val (newIds, newTs) = MsgIndex.idsAndTs(app, f)
            val days = MsgIndex.dayCounts(app, f)
            runOnUiThread {
                if (gen != loadGen || isFinishing) return@runOnUiThread
                fillApps(apps)
                ids = newIds
                idTs = newTs
                dayCounts = days
                pages.clear()
                rebuildOrder()
                countView.text = err ?: "${newIds.size} üzenet"
                searchMail()
            }
        }
    }

    // ---------- e-mail ----------
    private fun mailAllowed(): Boolean {
        val sel = selectedApps ?: return true
        return sel.any { it.equals("Gmail", true) }
    }

    private fun searchMail() {
        val gen = ++mailGen
        if (!showMail.isChecked || !mailAllowed()) {
            mails = emptyList()
            mailStatus.text = ""
            rebuildOrder()
            return
        }
        mailStatus.text = "E-mail: keresés…"
        val app = applicationContext
        // a Gmailnek az eredeti, ékezetes szavakat küldjük (ott nincs szótöves keresés)
        val t = search.text.toString().trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val f = from
        val to2 = to
        Thread {
            val res = try {
                MailStore.search(app, t, f, to2)
            } catch (e: Exception) {
                MailStore.SearchResult(emptyList(), listOf(e.message ?: "hiba"))
            }
            runOnUiThread {
                if (gen != mailGen || isFinishing) return@runOnUiThread
                mails = res.items
                mailStatus.text = buildString {
                    append("E-mail: ${res.items.size} találat")
                    if (res.items.size >= MailStore.PER_ACCOUNT) append(" (fiókonként a legfrissebb ${MailStore.PER_ACCOUNT})")
                    if (t.isNotEmpty() && res.items.isEmpty())
                        append(" – a Gmail csak teljes szavakra keres")
                    if (res.errors.isNotEmpty()) append(" – ").append(res.errors.joinToString("; "))
                }
                markMailDuplicates(app)
            }
        }.start()
    }

    /** Csak azt a levélértesítést rejtjük el, amelynek megvan a levélpárja. */
    private fun markMailDuplicates(app: android.content.Context) {
        val snapshot = mails
        if (snapshot.isEmpty()) {
            hiddenIds = emptySet()
            rebuildOrder()
            return
        }
        val f = from
        val t = to
        MsgIndex.exec.execute {
            val notifs = MsgIndex.mailNotifications(app, f, t)
            val hide = HashSet<Long>()
            for (m in snapshot) {
                val key = MsgIndex.norm(m.subject).take(25)
                if (key.length < 6) continue
                for ((id, ts, text) in notifs) {
                    if (kotlin.math.abs(ts - m.ts) < 30 * 60_000L && MsgIndex.norm(text).contains(key)) {
                        hide.add(id)
                    }
                }
            }
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                hiddenIds = hide
                rebuildOrder()
            }
        }
    }

    /** A napló és az e-mailek összefésülése idő szerint. */
    private fun rebuildOrder() {
        val n = ids.size + mails.size
        val o = IntArray(n)
        var i = 0
        var j = 0
        var k = 0
        while (i < ids.size || j < mails.size) {
            val useDb = when {
                j >= mails.size -> true
                i >= ids.size -> false
                else -> idTs[i] >= mails[j].ts
            }
            if (useDb) {
                if (ids[i] !in hiddenIds) o[k++] = i
                i++
            } else {
                o[k++] = -(j + 1); j++
            }
        }
        order = if (k == o.size) o else o.copyOf(k)
        val counts = HashMap<String, Int>(dayCounts)
        for (m in mails) {
            val key = keyFmt.format(Date(m.ts))
            counts[key] = (counts[key] ?: 0) + 1
        }
        if (mails.isNotEmpty()) dayCounts = counts
        adapter.notifyDataSetChanged()
    }

    private fun mailAt(pos: Int): MailItem? {
        val o = order.getOrNull(pos) ?: return null
        return if (o < 0) mails.getOrNull(-o - 1) else null
    }

    private fun openMail(item: MailItem) {
        val tv = TextView(this).apply {
            setTextIsSelectable(true)
            setPadding(dp(20), dp(12), dp(20), dp(12))
            setTextColor(pal.text)
            text = "Betöltés…"
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle(item.subject.take(60))
            .setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Bezár", null)
            .show()
        val app = applicationContext
        Thread {
            val body = try {
                MailStore.body(app, item)
            } catch (e: Exception) {
                "A levél nem tölthető le: ${e.message}"
            }
            runOnUiThread {
                if (!isFinishing && dlg.isShowing) {
                    val d = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(item.ts))
                    tv.text = "Feladó: ${item.from}\nCímzett: ${item.to}\nFiók: ${item.account}\nIdő: $d\n\n$body"
                }
            }
        }.start()
    }

    private fun fillApps(apps: List<Pair<String, Int>>) {
        appCounts = apps
        val sel = selectedApps
        appBtn.text = when {
            sel == null -> "Appok: mind"
            sel.isEmpty() -> "Appok: egyik se"
            sel.size == 1 -> sel.first().take(14)
            else -> "Appok: ${sel.size}"
        }
    }

    private fun pickApps() {
        if (appCounts.isEmpty()) return
        val names = appCounts.map { it.first }
        val labels = appCounts.map { "${it.first} (${it.second})" }.toTypedArray()
        val sel = selectedApps
        val checked = BooleanArray(names.size) { sel == null || names[it] in sel }
        AlertDialog.Builder(this)
            .setTitle("Mely alkalmazások látszanak?")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Kész") { _, _ ->
                val picked = names.filterIndexed { i, _ -> checked[i] }.toMutableSet()
                selectedApps = if (picked.size == names.size) null else picked
                fillApps(appCounts)
                reload(sync = false)
            }
            .setNeutralButton("Mind") { _, _ ->
                selectedApps = null
                fillApps(appCounts)
                reload(sync = false)
            }
            .setNegativeButton("Egyik se") { _, _ ->
                selectedApps = HashSet()
                fillApps(appCounts)
                reload(sync = false)
            }
            .show()
    }

    private fun msgAt(pos: Int): Msg? {
        if (pos < 0 || pos >= ids.size) return null
        val p = pos / PAGE
        val page = pages[p] ?: MsgIndex.fetch(this, ids, p * PAGE, minOf(ids.size, (p + 1) * PAGE))
            .also { pages[p] = it }
        return page.getOrNull(pos - p * PAGE)
    }

    /** Hőmérséklet és lépésszám a szűrősor mellett. */
    private fun refreshInfo() {
        val parts = ArrayList<String>()
        Weather.localTemp(this).takeIf { it.isNotEmpty() }?.let { parts.add("🌡️ $it") }
        Health.summary(this).takeIf { it.isNotEmpty() }?.let { parts.add(it) }
        infoView.text = parts.joinToString(" · ")
        val app = applicationContext
        Health.sample(app) { runOnUiThread { if (!isFinishing) infoView.text = infoText() } }
        if (Weather.localStale(app)) Thread {
            Weather.refreshLocal(app)
            runOnUiThread { if (!isFinishing) infoView.text = infoText() }
        }.start()
    }

    private fun infoText(): String {
        val parts = ArrayList<String>()
        Weather.localTemp(this).takeIf { it.isNotEmpty() }?.let { parts.add("🌡️ $it") }
        Health.summary(this).takeIf { it.isNotEmpty() }?.let { parts.add(it) }
        return parts.joinToString(" · ")
    }

    private fun checkUpdateQuietly() {
        val now = System.currentTimeMillis()
        if (now - Prefs.lastUpdateCheck(this) < 12 * 3600_000L) return
        Prefs.setLastUpdateCheck(this, now)
        val app = applicationContext
        Thread {
            try {
                val rel = Updater.latest()
                if (rel.build > Updater.installedBuild(app)) runOnUiThread {
                    updBanner.text = "Új verzió érhető el (${rel.build}) – koppints a frissítéshez."
                    updBanner.visibility = View.VISIBLE
                }
            } catch (_: Exception) {
            }
        }.start()
    }

    // ---------- AI ----------
    private fun showSummary() {
        val text = Prefs.lastSummary(this)
        if (text.isBlank()) {
            startAiView("Reggeli összefoglaló")
            aiStatus.text = "Még nem készült reggeli összefoglaló. Beállítás: ⚙ → Reggeli összefoglaló."
            return
        }
        val ts = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(Prefs.lastSummaryTime(this)))
        startAiView("Reggeli összefoglaló · $ts")
        aiStatus.text = "Reggeli összefoglaló – $ts"
        aiAnswer.text = Md.toSpanned(text)
    }

    private fun askCustom() {
        val hist = Prefs.history(this, HIST_QUESTIONS)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val input = EditText(this).apply { hint = "pl. Mikor beszéltünk a szerződésről?" }
        box.addView(input)
        var dialog: AlertDialog? = null
        val run = { q: String ->
            val t = q.trim()
            if (t.isNotEmpty()) {
                Prefs.pushHistory(this, HIST_QUESTIONS, t, 20)
                dialog?.dismiss()
                ask("Kérdés: ${t.take(30)}", "Válaszolj erre a kérdésre az üzenetek alapján: $t")
            }
        }
        if (hist.isNotEmpty()) {
            box.addView(TextView(this).apply {
                text = "Korábbi kérdések – koppintás: újra feltesz, hosszan nyomva: szerkesztés"
                textSize = 12f
                setTextColor(pal.muted)
                setPadding(0, dp(12), 0, dp(4))
            })
            val lv = ListView(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_list_item_1, hist)
                setOnItemClickListener { _, _, pos, _ -> run(hist[pos]) }
                setOnItemLongClickListener { _, _, pos, _ ->
                    input.setText(hist[pos]); input.setSelection(input.text.length); true
                }
            }
            box.addView(lv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(300)))
        }
        val b = AlertDialog.Builder(this)
            .setTitle("Saját kérdés")
            .setView(box)
            .setPositiveButton("Kérdezés", null)
            .setNegativeButton("Mégse", null)
        if (hist.isNotEmpty()) b.setNeutralButton("Előzmények törlése") { _, _ ->
            Prefs.clearHistory(this, HIST_QUESTIONS)
        }
        dialog = b.create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { run(input.text.toString()) }
        }
        dialog.show()
    }

    private fun startAiView(title: String) {
        aiTitle = title
        aiHasContent = true
        aiStatus.text = ""
        aiAnswer.text = ""
        expandAi()
    }

    private fun expandAi() {
        if (!aiHasContent) return
        aiPanel.visibility = View.VISIBLE
        aiToggle.visibility = View.VISIBLE
        aiToggle.text = "▾ $aiTitle – összecsukás"
    }

    private fun collapseAi() {
        if (!::aiPanel.isInitialized) return
        aiPanel.visibility = View.GONE
        aiToggle.visibility = if (aiHasContent) View.VISIBLE else View.GONE
        aiToggle.text = "▸ Utolsó elemzés: $aiTitle"
    }

    private fun ask(title: String, task: String) {
        val model = Prefs.model(this)
        val client = AiClient(this, model)
        if (!client.hasKey()) {
            Toast.makeText(this, "Add meg a ${client.providerName} API-kulcsot a beállításokban.", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }
        if (ids.isEmpty() && mails.isEmpty()) {
            Toast.makeText(this, "Nincs elemezhető üzenet a szűrőkkel.", Toast.LENGTH_SHORT).show()
            return
        }
        val label = Models.label(model)
        val budget = Prefs.charBudget(this)
        val est = Cost.estimate(model, budget)
        if (est != null && est > Prefs.confirmOver(this)) {
            AlertDialog.Builder(this)
                .setTitle("Elemzés indítása")
                .setMessage(
                    "Becsült költség legfeljebb ${Cost.format(this, est)} ($label).\n\n" +
                        "Keret: ${budget / 1000} ezer karakter, a ⚙-ben állítható."
                )
                .setPositiveButton("Indítás") { _, _ -> runAsk(title, task, model, client, label, budget) }
                .setNegativeButton("Mégse", null)
                .show()
            return
        }
        runAsk(title, task, model, client, label, budget)
    }

    private fun runAsk(title: String, task: String, model: String, client: AiClient, label: String, budget: Int) {
        val snap = ids
        val mailSnap = if (showMail.isChecked && mailAllowed()) mails.take(AI_MAILS) else emptyList()
        val period = if (from == null) "a teljes napló"
        else "${keyFmt.format(Date(from!!))} – ${keyFmt.format(Date(to!!))}"

        stopAi(null)
        ai = client
        val gen = ++aiGen
        startAiView("$title · ${SimpleDateFormat("HH:mm", Locale.US).format(Date())}")
        aiStatus.text = "Üzenetek összegyűjtése…"
        setBusy(true)
        val app = applicationContext
        Thread {
            val res = runCatching {
                if (mailSnap.isNotEmpty()) runOnUiThread {
                    if (gen == aiGen) aiStatus.text = "${mailSnap.size} levél letöltése…"
                }
                val mailMsgs = mailSnap.map { mi ->
                    val body = try {
                        MailStore.body(app, mi)
                    } catch (e: Exception) {
                        ""
                    }
                    Msg(-1, mi.ts, "Gmail", "gmail", "${mi.from} → ${mi.account}",
                        (mi.subject + "\n" + body).take(AI_MAIL_CHARS))
                }
                val merged = mergeByTime(MsgIndex.sequence(app, snap), mailMsgs.asSequence())
                val (prompt, n) = Prompts.build(merged, task, period, budget)
                runOnUiThread {
                    val total = snap.size + mailSnap.size
                    if (gen == aiGen) aiStatus.text = (if (n < total)
                        "A legfrissebb $n üzenet elemzése ($total-ból)."
                    else "$n üzenet elemzése.") + " $label gondolkodik…"
                }
                client.ask(prompt) to n
            }
            runOnUiThread {
                if (gen != aiGen || isFinishing) return@runOnUiThread
                setBusy(false)
                ai = null
                res.onSuccess { pair ->
                    val a = pair.first
                    val n = pair.second
                    aiAnswer.text = Md.toSpanned(a.text)
                    val usd = Cost.record(this, model, a.inTok, a.outTok)
                    aiStatus.text = "Kész – $n üzenet" +
                        (if (mailSnap.isNotEmpty()) " (ebből ${mailSnap.size} levél)" else "") +
                        ", $label, ${a.inTok + a.outTok} token" +
                        (if (usd != null) ", ${Cost.format(this, usd)}" else "") + "." +
                        (if (a.truncated) " A válasz a hosszkorlát miatt csonka." else "")
                }.onFailure { e ->
                    aiStatus.text = e.message ?: "Az elemzés nem sikerült."
                }
            }
        }.start()
    }

    /** Két időrendben csökkenő sorozat összefésülése. */
    private fun mergeByTime(a: Sequence<Msg>, b: Sequence<Msg>): Sequence<Msg> = sequence {
        val ia = a.iterator()
        val ib = b.iterator()
        var x: Msg? = if (ia.hasNext()) ia.next() else null
        var y: Msg? = if (ib.hasNext()) ib.next() else null
        while (x != null || y != null) {
            val useA = y == null || (x != null && x.ts >= y.ts)
            if (useA) {
                yield(x!!)
                x = if (ia.hasNext()) ia.next() else null
            } else {
                yield(y!!)
                y = if (ib.hasNext()) ib.next() else null
            }
        }
    }

    private fun stopAi(msg: String?) {
        aiGen++
        ai?.let { c -> Thread { c.cancel() }.start() }
        ai = null
        if (::stopBtn.isInitialized) setBusy(false)
        if (msg != null) aiStatus.text = msg
    }

    private fun setBusy(b: Boolean) {
        stopBtn.visibility = if (b) View.VISIBLE else View.GONE
        aiButtons.forEach { it.isEnabled = !b }
    }

    // ---------- lista ----------
    private inner class MsgAdapter : BaseAdapter() {
        override fun getCount() = order.size
        override fun getItem(p: Int): Any? = mailAt(p) ?: msgAt(order.getOrElse(p) { -1 })
        override fun getItemId(p: Int) = p.toLong()
        override fun isEnabled(p: Int) = mailAt(p) != null
        override fun areAllItemsEnabled() = false

        override fun getView(p: Int, convert: View?, parent: ViewGroup?): View {
            val box = (convert as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(TextView(context).apply {
                    setPadding(dp(12), dp(14), dp(12), dp(6))
                    textSize = 16f
                    setTypeface(typeface, Typeface.BOLD)
                    setBackgroundColor(pal.dayBg)
                    setTextColor(pal.text)
                })
                addView(TextView(context).apply {
                    textSize = 13f; setTextColor(pal.text)
                    setPadding(dp(12), dp(8), dp(12), 0)
                })
                addView(TextView(context).apply {
                    textSize = 15f; setTextColor(pal.text)
                    setPadding(dp(12), dp(2), dp(12), 0)
                })
                // üres sor az elemek között
                addView(View(context), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(22)))
            }
            val dayView = box.getChildAt(0) as TextView
            val head = box.getChildAt(1) as TextView
            val body = box.getChildAt(2) as TextView

            val mail = mailAt(p)
            val m = if (mail != null) Msg(-1, mail.ts, "Gmail", "gmail",
                "${mail.from} → ${mail.account}", mail.subject)
            else msgAt(order.getOrElse(p) { -1 })
            if (m == null) {
                dayView.visibility = View.GONE
                head.text = "…"
                body.visibility = View.GONE
                return box
            }
            val key = keyFmt.format(Date(m.ts))
            val prevTs = if (p > 0) itemTs(p - 1) else null
            if (prevTs == null || keyFmt.format(Date(prevTs)) != key) {
                dayView.visibility = View.VISIBLE
                dayView.text = "${dayFmt.format(Date(m.ts))}  ·  ${dayCounts[key] ?: 0} db"
            } else {
                dayView.visibility = View.GONE
            }

            val h = SpannableStringBuilder()
            h.append(timeFmt.format(Date(m.ts)), ForegroundColorSpan(pal.muted), 0)
            h.append("  ")
            val s = h.length
            h.append(m.app)
            h.setSpan(ForegroundColorSpan(pal.appColor(m.pkg)), s, h.length, 0)
            h.setSpan(StyleSpan(Typeface.BOLD), s, h.length, 0)
            if (m.who.isNotEmpty()) {
                h.append("  ")
                val w = h.length
                h.append(highlight(m.who))
                h.setSpan(StyleSpan(Typeface.BOLD), w, h.length, 0)
            }
            head.text = h
            body.text = highlight(m.text)
            body.visibility = if (m.text.isEmpty()) View.GONE else View.VISIBLE
            return box
        }
    }

    private fun itemTs(p: Int): Long? {
        val o = order.getOrNull(p) ?: return null
        return if (o < 0) mails.getOrNull(-o - 1)?.ts else idTs.getOrNull(o)
    }

    private fun highlight(text: String): CharSequence {
        if (terms.isEmpty()) return text
        val map = ArrayList<Int>(text.length)
        val nsb = StringBuilder()
        for (i in text.indices) {
            val n = MsgIndex.norm(text[i].toString())
            for (ch in n) { nsb.append(ch); map.add(i) }
        }
        val ns = nsb.toString()
        val sp = SpannableStringBuilder(text)
        for (w in terms) {
            var p = ns.indexOf(w)
            while (p >= 0) {
                val st = map[p]
                val en = map[p + w.length - 1] + 1
                sp.setSpan(BackgroundColorSpan(pal.highlight), st, en, 0)
                sp.setSpan(ForegroundColorSpan(pal.highlightText), st, en, 0)
                p = ns.indexOf(w, p + w.length)
            }
        }
        return sp
    }

    private fun smallButton(label: String) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val PAGE = 200
        private const val HIST_QUESTIONS = "hist_questions"
        private const val HIST_RANGES = "hist_ranges"
        private const val AI_MAILS = 40
        private const val AI_MAIL_CHARS = 3000
    }
}
