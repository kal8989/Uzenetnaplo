package hu.atria.uzenetnaplo

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Nézegető: kereshető lista (SQLite-indexből, lapozva) + AI-elemzés. */
class MainActivity : Activity() {

    private val hu = Locale("hu", "HU")
    private val keyFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val dayFmt = SimpleDateFormat("yyyy. MMMM d., EEEE", hu)
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.US)
    private val shortFmt = SimpleDateFormat("yyyy.MM.dd.", Locale.US)
    private val main = Handler(Looper.getMainLooper())

    private lateinit var pal: Palette
    private var themeDark = false

    // állapot
    private var from: Long? = null
    private var to: Long? = null
    private var rangeId = "7"
    private var ids: LongArray = LongArray(0)
    private var dayCounts: Map<String, Int> = emptyMap()
    private var appNames: List<String> = emptyList()
    private var selectedApp: String? = null
    private var terms: List<String> = emptyList()
    private var loadGen = 0
    private var modelIds: List<String> = emptyList()
    private val pages = object : LinkedHashMap<Int, Array<Msg?>>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Int, Array<Msg?>>?) = size > 30
    }

    // nézetek
    private lateinit var search: EditText
    private lateinit var banner: TextView
    private lateinit var updBanner: TextView
    private lateinit var rangeRow: LinearLayout
    private lateinit var appSpinner: Spinner
    private lateinit var hideSys: CheckBox
    private lateinit var countView: TextView
    private lateinit var modelSpinner: Spinner
    private lateinit var aiStatus: TextView
    private lateinit var aiAnswer: TextView
    private lateinit var stopBtn: Button
    private lateinit var aiButtons: List<Button>
    private lateinit var aiToggle: Button
    private lateinit var aiPanel: LinearLayout
    private var aiTitle = ""
    private var aiHasContent = false
    private val adapter = MsgAdapter()

    private var ai: AiClient? = null
    private var aiGen = 0
    private var suppressSpinner = false

    override fun onCreate(savedInstanceState: Bundle?) {
        pal = Ui.apply(this)
        themeDark = pal.dark
        super.onCreate(savedInstanceState)
        val pad = dp(12)

        // felső sáv: kereső + beállítások
        search = EditText(this).apply {
            hint = "Keresés (ékezet nélkül is)"
            setSingleLine()
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val settingsBtn = Button(this).apply {
            text = "⚙"
            textSize = 20f
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, dp(4), dp(4), 0)
            addView(search)
            addView(settingsBtn)
        }

        // lista fejléce: szűrők + AI
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, 0, pad, dp(8))
        }
        banner = TextView(this).apply {
            setBackgroundColor(pal.bannerBg)
            setTextColor(pal.bannerText)
            setPadding(pad, pad, pad, pad)
            text = "A naplózás nincs teljesen beállítva – koppints ide."
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
            visibility = View.GONE
        }
        header.addView(banner)
        updBanner = TextView(this).apply {
            setBackgroundColor(pal.infoBg)
            setTextColor(pal.text)
            setPadding(pad, pad, pad, pad)
            visibility = View.GONE
            setOnClickListener {
                startActivity(
                    Intent(this@MainActivity, SettingsActivity::class.java)
                        .putExtra(SettingsActivity.EXTRA_UPDATE, true)
                )
            }
        }
        header.addView(updBanner)

        rangeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            "today" to "Ma", "yesterday" to "Tegnap", "7" to "7 nap", "30" to "30 nap",
            "365" to "1 év", "all" to "Mind", "custom" to "Egyéni…",
        ).forEach { (id, label) ->
            rangeRow.addView(smallButton(label).apply {
                tag = id
                setOnClickListener { if (id == "custom") pickCustom() else setRange(id) }
            })
        }
        header.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(rangeRow)
        })

        appSpinner = Spinner(this)
        appSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (suppressSpinner) return
                val app = if (pos == 0) null else appNames.getOrNull(pos - 1)
                if (app != selectedApp) {
                    selectedApp = app
                    reload(sync = false)
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        header.addView(appSpinner)

        hideSys = CheckBox(this).apply {
            text = "Rendszerértesítések elrejtése"
            setTextColor(pal.text)
            isChecked = true
            setOnCheckedChangeListener { _, _ -> reload(sync = false) }
        }
        header.addView(hideSys)

        countView = TextView(this).apply {
            textSize = 15f
            setTextColor(pal.text)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }
        header.addView(countView)

        header.addView(TextView(this).apply {
            text = "AI-elemzés a szűrt üzenetekről"
            textSize = 16f
            setTextColor(pal.accent)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(10), 0, 0)
        })
        modelSpinner = Spinner(this)
        modelSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                modelIds.getOrNull(pos)?.let { Prefs.setModel(this@MainActivity, it) }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        header.addView(modelSpinner)

        val aiRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btns = ArrayList<Button>()
        listOf(
            "Összefoglaló" to Prompts.TASK_SUM, "Teendők" to Prompts.TASK_TODO,
            "Fontosak" to Prompts.TASK_IMP, "Ki miről" to Prompts.TASK_WHO,
        ).forEach { (label, task) ->
            btns.add(smallButton(label).apply { setOnClickListener { ask(label, task) } })
        }
        btns.add(smallButton("Saját kérdés…").apply { setOnClickListener { askCustom() } })
        btns.add(smallButton("Reggeli összefoglaló").apply { setOnClickListener { showSummary() } })
        btns.forEach { aiRow.addView(it) }
        aiButtons = btns
        header.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(aiRow)
        })
        aiToggle = smallButton("").apply {
            visibility = View.GONE
            setTextColor(pal.accent)
            setOnClickListener { if (aiPanel.visibility == View.VISIBLE) collapseAi() else expandAi() }
        }
        header.addView(aiToggle)
        aiPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        aiStatus = TextView(this).apply { setTextColor(pal.muted); textSize = 13f }
        aiPanel.addView(aiStatus)
        stopBtn = smallButton("Leállítás").apply {
            visibility = View.GONE
            setOnClickListener { stopAi("Leállítva.") }
        }
        aiPanel.addView(stopBtn)
        aiAnswer = TextView(this).apply {
            setTextIsSelectable(true)
            textSize = 15f
            setTextColor(pal.text)
            setLinkTextColor(pal.accent)
            setPadding(0, dp(4), 0, dp(8))
        }
        aiPanel.addView(aiAnswer)
        header.addView(aiPanel)

        val list = ListView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            addHeaderView(header, null, false)
            adapter = this@MainActivity.adapter
            divider = null
            isFastScrollEnabled = true
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pal.bg)
            addView(top)
            addView(list)
        })

        val debounce = Runnable { reload(sync = false) }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                main.removeCallbacks(debounce)
                main.postDelayed(debounce, 350)
            }
        })

        setRange("7", load = false)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        if (Ui.isDark(this) != themeDark) { recreate(); return }
        val ok = Prefs.listenerEnabled(this) && LogWriter.treeUri(this) != null
        banner.visibility = if (ok) View.GONE else View.VISIBLE
        fillModels()
        checkUpdateQuietly()
        reload(sync = true)
    }

    override fun onDestroy() {
        stopAi(null)
        super.onDestroy()
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra(Daily.EXTRA_SHOW_SUMMARY, false) == true) {
            i.removeExtra(Daily.EXTRA_SHOW_SUMMARY)
            showSummary()
        }
    }

    // ---------- időszak ----------
    private fun startOfDay(offset: Int): Long = Calendar.getInstance().run {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        add(Calendar.DAY_OF_MONTH, offset)
        timeInMillis
    }

    private fun setRange(id: String, load: Boolean = true) {
        rangeId = id
        when (id) {
            "today" -> { from = startOfDay(0); to = startOfDay(1) - 1 }
            "yesterday" -> { from = startOfDay(-1); to = startOfDay(0) - 1 }
            "7" -> { from = startOfDay(-6); to = startOfDay(1) - 1 }
            "30" -> { from = startOfDay(-29); to = startOfDay(1) - 1 }
            "365" -> { from = startOfDay(-364); to = startOfDay(1) - 1 }
            "all" -> { from = null; to = null }
        }
        markRange()
        if (load) reload(sync = false)
    }

    private fun markRange() {
        for (i in 0 until rangeRow.childCount) {
            val b = rangeRow.getChildAt(i) as Button
            val on = b.tag == rangeId
            b.setTextColor(if (on) pal.accent else pal.text)
            b.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
            if (b.tag == "custom") {
                b.text = if (on && from != null && to != null)
                    "${shortFmt.format(Date(from!!))}–${shortFmt.format(Date(to!!))}" else "Egyéni…"
            }
        }
    }

    private fun pickCustom() {
        val c = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            val start = Calendar.getInstance().apply { clear(); set(y, m, d) }.timeInMillis
            DatePickerDialog(this, { _, y2, m2, d2 ->
                val endCal = Calendar.getInstance().apply {
                    clear(); set(y2, m2, d2); add(Calendar.DAY_OF_MONTH, 1)
                }
                val end = endCal.timeInMillis - 1
                from = minOf(start, end); to = maxOf(start, end)
                rangeId = "custom"
                markRange()
                reload(sync = false)
            }, y, m, d).apply { setTitle("Vége") }.show()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH))
            .apply { setTitle("Kezdete") }.show()
    }

    // ---------- adatok ----------
    private fun currentFilter(): Filter {
        terms = MsgIndex.terms(search.text.toString())
        return Filter(from, to, selectedApp, hideSys.isChecked, terms)
    }

    private fun reload(sync: Boolean) {
        if (!sync) collapseAi() // a szűrés megváltozott – az előző elemzés már nem erre vonatkozik
        val gen = ++loadGen
        val f = currentFilter()
        val app = applicationContext
        if (ids.isEmpty()) countView.text = "Betöltés…"
        MsgIndex.exec.execute {
            var err: String? = null
            if (sync) {
                SmsImport.quickSyncIfDue(app)
                err = MsgIndex.sync(app) { p ->
                    runOnUiThread { if (gen == loadGen) countView.text = p }
                }
            }
            val apps = MsgIndex.appCounts(app, f)
            val newIds = MsgIndex.ids(app, f)
            val days = MsgIndex.dayCounts(app, f)
            runOnUiThread {
                if (gen != loadGen || isFinishing) return@runOnUiThread
                fillApps(apps)
                ids = newIds
                dayCounts = days
                pages.clear()
                adapter.notifyDataSetChanged()
                countView.text = err ?: "${newIds.size} üzenet"
            }
        }
    }

    private fun fillApps(apps: List<Pair<String, Int>>) {
        val list = apps.toMutableList()
        val sel = selectedApp
        if (sel != null && list.none { it.first == sel }) list.add(sel to 0)
        appNames = list.map { it.first }
        val labels = listOf("Minden alkalmazás") + list.map { "${it.first} (${it.second})" }
        suppressSpinner = true
        appSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        val idx = sel?.let { appNames.indexOf(it) } ?: -1
        appSpinner.setSelection(if (idx >= 0) idx + 1 else 0, false)
        main.post { suppressSpinner = false }
    }

    private fun msgAt(pos: Int): Msg? {
        if (pos < 0 || pos >= ids.size) return null
        val p = pos / PAGE
        val page = pages[p] ?: MsgIndex.fetch(this, ids, p * PAGE, minOf(ids.size, (p + 1) * PAGE))
            .also { pages[p] = it }
        return page.getOrNull(pos - p * PAGE)
    }

    private fun fillModels() {
        val choices = Models.choices(Prefs.customModel(this))
        modelIds = choices.map { it.id }
        modelSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            choices.map { "Modell: ${it.label}" }
        )
        val idx = modelIds.indexOf(Prefs.model(this))
        modelSpinner.setSelection(if (idx >= 0) idx else 0, false)
    }

    private fun checkUpdateQuietly() {
        val now = System.currentTimeMillis()
        if (now - Prefs.lastUpdateCheck(this) < 12 * 3600_000L) return
        Prefs.setLastUpdateCheck(this, now)
        val app = applicationContext
        Thread {
            try {
                val rel = Updater.latest()
                if (rel.build > Updater.installedBuild(app)) runOnUiThread {
                    updBanner.text = "Új verzió érhető el (${rel.build}) – koppints a frissítéshez."
                    updBanner.visibility = View.VISIBLE
                }
            } catch (_: Exception) {
            }
        }.start()
    }

    // ---------- AI ----------
    private fun showSummary() {
        val text = Prefs.lastSummary(this)
        if (text.isBlank()) {
            startAiView("Reggeli összefoglaló")
            aiStatus.text = "Még nem készült reggeli összefoglaló. Beállítás: ⚙ → Reggeli összefoglaló."
            return
        }
        val ts = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(Prefs.lastSummaryTime(this)))
        startAiView("Reggeli összefoglaló · $ts")
        aiStatus.text = "Reggeli összefoglaló – $ts"
        aiAnswer.text = Md.toSpanned(text)
    }

    private fun askCustom() {
        val input = EditText(this).apply { hint = "pl. Mikor beszéltünk a szerződésről?" }
        AlertDialog.Builder(this)
            .setTitle("Saját kérdés")
            .setView(input)
            .setPositiveButton("Kérdezés") { _, _ ->
                val q = input.text.toString().trim()
                if (q.isNotEmpty()) ask("Kérdés: ${q.take(30)}", "Válaszolj erre a kérdésre az üzenetek alapján: $q")
            }
            .setNegativeButton("Mégse", null)
            .show()
    }

    private fun startAiView(title: String) {
        aiTitle = title
        aiHasContent = true
        aiStatus.text = ""
        aiAnswer.text = ""
        expandAi()
    }

    private fun expandAi() {
        if (!aiHasContent) return
        aiPanel.visibility = View.VISIBLE
        aiToggle.visibility = View.VISIBLE
        aiToggle.text = "▾ $aiTitle – összecsukás"
    }

    private fun collapseAi() {
        if (!::aiPanel.isInitialized) return
        aiPanel.visibility = View.GONE
        aiToggle.visibility = if (aiHasContent) View.VISIBLE else View.GONE
        aiToggle.text = "▸ Utolsó elemzés: $aiTitle"
    }

    private fun ask(title: String, task: String) {
        val model = Prefs.model(this)
        val client = AiClient(this, model)
        if (!client.hasKey()) {
            Toast.makeText(this, "Add meg a ${client.providerName} API-kulcsot a beállításokban.", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }
        val snap = ids
        if (snap.isEmpty()) {
            Toast.makeText(this, "Nincs elemezhető üzenet a szűrőkkel.", Toast.LENGTH_SHORT).show()
            return
        }
        val period = if (from == null) "a teljes napló"
        else "${keyFmt.format(Date(from!!))} – ${keyFmt.format(Date(to!!))}"

        stopAi(null)
        ai = client
        val gen = ++aiGen
        val label = Models.label(model)
        startAiView("$title · ${SimpleDateFormat("HH:mm", Locale.US).format(Date())}")
        aiStatus.text = "Üzenetek összegyűjtése…"
        setBusy(true)
        val app = applicationContext
        Thread {
            val res = runCatching {
                val (prompt, n) = Prompts.build(MsgIndex.sequence(app, snap), task, period)
                runOnUiThread {
                    if (gen == aiGen) aiStatus.text = (if (n < snap.size)
                        "A legfrissebb $n üzenet elemzése (${snap.size}-ból)."
                    else "$n üzenet elemzése.") + " $label gondolkodik…"
                }
                val (text, cut) = client.ask(prompt)
                Triple(text, cut, n)
            }
            runOnUiThread {
                if (gen != aiGen || isFinishing) return@runOnUiThread
                setBusy(false)
                ai = null
                res.onSuccess { (text, cut, n) ->
                    aiAnswer.text = Md.toSpanned(text)
                    aiStatus.text = "Kész – $n üzenet alapján, $label." +
                        if (cut) " A válasz a hosszkorlát miatt csonka." else ""
                }.onFailure { e ->
                    aiStatus.text = e.message ?: "Az elemzés nem sikerült."
                }
            }
        }.start()
    }

    private fun stopAi(msg: String?) {
        aiGen++
        ai?.let { c -> Thread { c.cancel() }.start() }
        ai = null
        if (::stopBtn.isInitialized) setBusy(false)
        if (msg != null) aiStatus.text = msg
    }

    private fun setBusy(b: Boolean) {
        stopBtn.visibility = if (b) View.VISIBLE else View.GONE
        aiButtons.forEach { it.isEnabled = !b }
    }

    // ---------- lista ----------
    private inner class MsgAdapter : BaseAdapter() {
        override fun getCount() = ids.size
        override fun getItem(p: Int): Any? = msgAt(p)
        override fun getItemId(p: Int) = p.toLong()
        override fun isEnabled(p: Int) = false
        override fun areAllItemsEnabled() = false

        override fun getView(p: Int, convert: View?, parent: ViewGroup?): View {
            val box = (convert as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(TextView(context).apply {
                    setPadding(dp(12), dp(14), dp(12), dp(6))
                    textSize = 16f
                    setTypeface(typeface, Typeface.BOLD)
                    setBackgroundColor(pal.dayBg)
                    setTextColor(pal.text)
                })
                addView(TextView(context).apply {
                    textSize = 13f; setTextColor(pal.text)
                    setPadding(dp(12), dp(8), dp(12), 0)
                })
                addView(TextView(context).apply {
                    textSize = 15f; setTextColor(pal.text)
                    setPadding(dp(12), dp(2), dp(12), dp(8))
                })
            }
            val dayView = box.getChildAt(0) as TextView
            val head = box.getChildAt(1) as TextView
            val body = box.getChildAt(2) as TextView

            val m = msgAt(p)
            if (m == null) {
                dayView.visibility = View.GONE
                head.text = "…"
                body.visibility = View.GONE
                return box
            }
            val key = keyFmt.format(Date(m.ts))
            val prev = if (p > 0) msgAt(p - 1) else null
            if (prev == null || keyFmt.format(Date(prev.ts)) != key) {
                dayView.visibility = View.VISIBLE
                dayView.text = "${dayFmt.format(Date(m.ts))}  ·  ${dayCounts[key] ?: 0} db"
            } else {
                dayView.visibility = View.GONE
            }

            val h = SpannableStringBuilder()
            h.append(timeFmt.format(Date(m.ts)), ForegroundColorSpan(pal.muted), 0)
            h.append("  ")
            val s = h.length
            h.append(m.app)
            h.setSpan(ForegroundColorSpan(pal.appColor(m.pkg)), s, h.length, 0)
            h.setSpan(StyleSpan(Typeface.BOLD), s, h.length, 0)
            if (m.who.isNotEmpty()) {
                h.append("  ")
                val w = h.length
                h.append(highlight(m.who))
                h.setSpan(StyleSpan(Typeface.BOLD), w, h.length, 0)
            }
            head.text = h
            body.text = highlight(m.text)
            body.visibility = if (m.text.isEmpty()) View.GONE else View.VISIBLE
            return box
        }
    }

    private fun highlight(text: String): CharSequence {
        if (terms.isEmpty()) return text
        val map = ArrayList<Int>(text.length)
        val nsb = StringBuilder()
        for (i in text.indices) {
            val n = MsgIndex.norm(text[i].toString())
            for (ch in n) { nsb.append(ch); map.add(i) }
        }
        val ns = nsb.toString()
        val sp = SpannableStringBuilder(text)
        for (w in terms) {
            var p = ns.indexOf(w)
            while (p >= 0) {
                val st = map[p]
                val en = map[p + w.length - 1] + 1
                sp.setSpan(BackgroundColorSpan(pal.highlight), st, en, 0)
                sp.setSpan(ForegroundColorSpan(pal.highlightText), st, en, 0)
                p = ns.indexOf(w, p + w.length)
            }
        }
        return sp
    }

    private fun smallButton(label: String) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val PAGE = 200
    }
}
