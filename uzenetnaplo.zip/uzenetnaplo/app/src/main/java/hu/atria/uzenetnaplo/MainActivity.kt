package hu.atria.uzenetnaplo

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Nézegető: kereshető lista + AI-elemzés. */
class MainActivity : Activity() {

    private val hu = Locale("hu", "HU")
    private val keyFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private val monthFmt = SimpleDateFormat("yyyy-MM", Locale.US)
    private val dayFmt = SimpleDateFormat("yyyy. MMMM d., EEEE", hu)
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.US)
    private val shortFmt = SimpleDateFormat("yyyy.MM.dd.", Locale.US)
    private val main = Handler(Looper.getMainLooper())

    private lateinit var pal: Palette
    private var themeDark = false

    // állapot
    private var from: Long? = null
    private var to: Long? = null
    private var rangeId = "7"
    private var rangeMsgs: List<Msg> = emptyList()
    private var filtered: List<Msg> = emptyList()
    private var items: List<Any> = emptyList()
    private var dayCounts: Map<String, Int> = emptyMap()
    private var appNames: List<String> = emptyList()
    private var selectedApp: String? = null
    private var terms: List<String> = emptyList()
    private var loadGen = 0

    // nézetek
    private lateinit var search: EditText
    private lateinit var banner: TextView
    private lateinit var rangeRow: LinearLayout
    private lateinit var appSpinner: Spinner
    private lateinit var hideSys: CheckBox
    private lateinit var countView: TextView
    private lateinit var aiStatus: TextView
    private lateinit var aiAnswer: TextView
    private lateinit var stopBtn: Button
    private lateinit var aiButtons: List<Button>
    private lateinit var modelSpinner: Spinner
    private lateinit var updBanner: TextView
    private var modelIds: List<String> = emptyList()
    private val adapter = MsgAdapter()

    private var ai: AiClient? = null
    private var aiGen = 0
    private var suppressSpinner = false

    override fun onCreate(savedInstanceState: Bundle?) {
        pal = Ui.apply(this)
        themeDark = pal.dark
        super.onCreate(savedInstanceState)
        val pad = dp(12)

        // felső sáv: kereső + beállítások
        search = EditText(this).apply {
            hint = "Keresés (ékezet nélkül is)"
            setSingleLine()
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val settingsBtn = Button(this).apply {
            text = "⚙"
            textSize = 20f
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, dp(4), dp(4), 0)
            addView(search)
            addView(settingsBtn)
        }

        // lista fejléce: szűrők + AI
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, 0, pad, dp(8))
        }
        banner = TextView(this).apply {
            setBackgroundColor(pal.bannerBg)
            setTextColor(pal.bannerText)
            setPadding(pad, pad, pad, pad)
            text = "A naplózás nincs teljesen beállítva – koppints ide."
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
            visibility = View.GONE
        }
        header.addView(banner)
        updBanner = TextView(this).apply {
            setBackgroundColor(pal.infoBg)
            setTextColor(pal.text)
            setPadding(pad, pad, pad, pad)
            visibility = View.GONE
            setOnClickListener {
                startActivity(Intent(this@MainActivity, SettingsActivity::class.java)
                    .putExtra(SettingsActivity.EXTRA_UPDATE, true))
            }
        }
        header.addView(updBanner)

        rangeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("today" to "Ma", "yesterday" to "Tegnap", "7" to "7 nap", "30" to "30 nap",
            "all" to "Mind", "custom" to "Egyéni…").forEach { (id, label) ->
            rangeRow.addView(smallButton(label).apply {
                tag = id
                setOnClickListener { if (id == "custom") pickCustom() else setRange(id) }
            })
        }
        header.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(rangeRow)
        })

        appSpinner = Spinner(this)
        appSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (suppressSpinner) return
                selectedApp = if (pos == 0) null else appNames.getOrNull(pos - 1)
                refilter()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        header.addView(appSpinner)

        hideSys = CheckBox(this).apply {
            text = "Rendszerértesítések elrejtése"
            setTextColor(pal.text)
            isChecked = true
            setOnCheckedChangeListener { _, _ -> refilter() }
        }
        header.addView(hideSys)

        countView = TextView(this).apply {
            textSize = 15f
            setTextColor(pal.text)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }
        header.addView(countView)

        header.addView(TextView(this).apply {
            text = "AI-elemzés a szűrt üzenetekről"
            textSize = 16f
            setTextColor(pal.accent)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(10), 0, 0)
        })
        modelSpinner = Spinner(this)
        modelSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                modelIds.getOrNull(pos)?.let { Prefs.setModel(this@MainActivity, it) }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        header.addView(modelSpinner)
        val aiRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val defs = listOf(
            "Összefoglaló" to Prompts.TASK_SUM, "Teendők" to Prompts.TASK_TODO,
            "Fontosak" to Prompts.TASK_IMP, "Ki miről" to Prompts.TASK_WHO,
        )
        val btns = ArrayList<Button>()
        defs.forEach { (label, task) ->
            btns.add(smallButton(label).apply { setOnClickListener { ask(task) } })
        }
        btns.add(smallButton("Saját kérdés…").apply { setOnClickListener { askCustom() } })
        btns.add(smallButton("Reggeli összefoglaló").apply { setOnClickListener { showSummary() } })
        btns.forEach { aiRow.addView(it) }
        aiButtons = btns
        header.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(aiRow)
        })
        aiStatus = TextView(this).apply { setTextColor(pal.muted); textSize = 13f }
        header.addView(aiStatus)
        stopBtn = smallButton("Leállítás").apply {
            visibility = View.GONE
            setOnClickListener { stopAi("Leállítva.") }
        }
        header.addView(stopBtn)
        aiAnswer = TextView(this).apply {
            setTextIsSelectable(true)
            textSize = 15f
            setTextColor(pal.text)
            setLinkTextColor(pal.accent)
            setPadding(0, dp(4), 0, dp(8))
        }
        header.addView(aiAnswer)

        val list = ListView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            addHeaderView(header, null, false)
            adapter = this@MainActivity.adapter
            divider = null
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pal.bg)
            addView(top)
            addView(list)
        })

        val debounce = Runnable { refilter() }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                main.removeCallbacks(debounce)
                main.postDelayed(debounce, 250)
            }
        })

        setRange("7", reload = false)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra(Daily.EXTRA_SHOW_SUMMARY, false) == true) {
            i.removeExtra(Daily.EXTRA_SHOW_SUMMARY)
            showSummary()
        }
    }

    private fun showSummary() {
        val text = Prefs.lastSummary(this)
        if (text.isBlank()) {
            aiStatus.text = "Még nem készült reggeli összefoglaló. Beállítás: ⚙ → Reggeli összefoglaló."
            aiAnswer.text = ""
            return
        }
        val ts = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(Prefs.lastSummaryTime(this)))
        aiStatus.text = "Reggeli összefoglaló – $ts"
        aiAnswer.text = Md.toSpanned(text)
    }

    private fun fillModels() {
        val choices = Models.choices(Prefs.customModel(this))
        modelIds = choices.map { it.id }
        modelSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            choices.map { "Modell: ${it.label}" })
        val idx = modelIds.indexOf(Prefs.model(this))
        modelSpinner.setSelection(if (idx >= 0) idx else 0, false)
    }

    private fun checkUpdateQuietly() {
        val now = System.currentTimeMillis()
        if (now - Prefs.lastUpdateCheck(this) < 12 * 3600_000L) return
        Prefs.setLastUpdateCheck(this, now)
        val app = applicationContext
        Thread {
            try {
                val rel = Updater.latest()
                if (rel.build > Updater.installedBuild(app)) runOnUiThread {
                    updBanner.text = "Új verzió érhető el (${rel.build}) – koppints a frissítéshez."
                    updBanner.visibility = View.VISIBLE
                }
            } catch (_: Exception) {}
        }.start()
    }

    override fun onResume() {
        super.onResume()
        if (Ui.isDark(this) != themeDark) { recreate(); return }
        fillModels()
        checkUpdateQuietly()
        val ok = Prefs.listenerEnabled(this) && LogWriter.treeUri(this) != null
        banner.visibility = if (ok) View.GONE else View.VISIBLE
        reload()
    }

    override fun onDestroy() {
        stopAi(null)
        super.onDestroy()
    }

    // ---------- időszak ----------
    private fun startOfDay(offset: Int): Long = Calendar.getInstance().run {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        add(Calendar.DAY_OF_MONTH, offset)
        timeInMillis
    }

    private fun setRange(id: String, reload: Boolean = true) {
        rangeId = id
        when (id) {
            "today" -> { from = startOfDay(0); to = startOfDay(1) - 1 }
            "yesterday" -> { from = startOfDay(-1); to = startOfDay(0) - 1 }
            "7" -> { from = startOfDay(-6); to = startOfDay(1) - 1 }
            "30" -> { from = startOfDay(-29); to = startOfDay(1) - 1 }
            "all" -> { from = null; to = null }
        }
        markRange()
        if (reload) reload()
    }

    private fun markRange() {
        for (i in 0 until rangeRow.childCount) {
            val b = rangeRow.getChildAt(i) as Button
            val on = b.tag == rangeId
            b.setTextColor(if (on) pal.accent else pal.text)
            b.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
            if (b.tag == "custom") {
                b.text = if (on && from != null && to != null)
                    "${shortFmt.format(Date(from!!))}–${shortFmt.format(Date(to!!))}" else "Egyéni…"
            }
        }
    }

    private fun pickCustom() {
        val c = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            val start = Calendar.getInstance().apply { clear(); set(y, m, d) }.timeInMillis
            DatePickerDialog(this, { _, y2, m2, d2 ->
                val endCal = Calendar.getInstance().apply { clear(); set(y2, m2, d2); add(Calendar.DAY_OF_MONTH, 1) }
                val end = endCal.timeInMillis - 1
                from = minOf(start, end); to = maxOf(start, end)
                rangeId = "custom"
                markRange()
                reload()
            }, y, m, d).apply { setTitle("Vége") }.show()
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH))
            .apply { setTitle("Kezdete") }.show()
    }

    // ---------- adatok ----------
    private fun reload() {
        val gen = ++loadGen
        val f = from; val t = to
        countView.text = "Betöltés…"
        LogStore.load(this, f?.let { monthFmt.format(Date(it)) }, t?.let { monthFmt.format(Date(it)) }) { msgs, err ->
            runOnUiThread {
                if (gen != loadGen || isFinishing) return@runOnUiThread
                rangeMsgs = msgs.filter { (f == null || it.ts >= f) && (t == null || it.ts <= t) }
                fillApps()
                refilter()
                if (err != null) countView.text = err
            }
        }
    }

    private fun fillApps() {
        val counts = rangeMsgs.groupingBy { it.app }.eachCount()
        appNames = counts.entries.sortedByDescending { it.value }.map { it.key }
        val labels = listOf("Minden alkalmazás") + appNames.map { "$it (${counts[it]})" }
        suppressSpinner = true
        appSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        val idx = selectedApp?.let { appNames.indexOf(it) } ?: -1
        if (idx < 0) selectedApp = null
        appSpinner.setSelection(if (idx >= 0) idx + 1 else 0, false)
        main.post { suppressSpinner = false }
    }

    private fun refilter() {
        terms = LogStore.norm(search.text.toString()).split(Regex("\\s+")).filter { it.isNotEmpty() }
        val app = selectedApp
        val hide = hideSys.isChecked
        filtered = rangeMsgs.filter { m ->
            (app == null || m.app == app) &&
                (!hide || m.pkg !in Prompts.SYS_PKGS) &&
                terms.all { m.norm.contains(it) }
        }
        val out = ArrayList<Any>(filtered.size + 32)
        val counts = HashMap<String, Int>()
        var last = ""
        for (m in filtered) {
            val k = keyFmt.format(Date(m.ts))
            counts[k] = (counts[k] ?: 0) + 1
            if (k != last) { out.add(DayHeader(k, m.ts)); last = k }
            out.add(m)
        }
        dayCounts = counts
        items = out
        adapter.notifyDataSetChanged()
        countView.text = "${filtered.size} üzenet"
    }

    // ---------- AI ----------
    private fun askCustom() {
        val input = EditText(this).apply { hint = "pl. Mikor beszéltünk a szerződésről?" }
        AlertDialog.Builder(this)
            .setTitle("Saját kérdés")
            .setView(input)
            .setPositiveButton("Kérdezés") { _, _ ->
                val q = input.text.toString().trim()
                if (q.isNotEmpty()) ask("Válaszolj erre a kérdésre az üzenetek alapján: $q")
            }
            .setNegativeButton("Mégse", null)
            .show()
    }

    private fun ask(task: String) {
        val model = Prefs.model(this)
        val client = AiClient(this, model)
        if (!client.hasKey()) {
            Toast.makeText(this, "Add meg a ${client.providerName} API-kulcsot a beállításokban.", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }
        if (filtered.isEmpty()) {
            aiStatus.text = "Nincs elemezhető üzenet a szűrőkkel."
            return
        }
        val period = if (from == null) "a teljes napló"
        else "${keyFmt.format(Date(from!!))} – ${keyFmt.format(Date(to!!))}"
        val (prompt, n) = Prompts.build(filtered, task, period)

        stopAi(null)
        ai = client
        val gen = ++aiGen
        aiStatus.text = (if (n < filtered.size)
            "A legfrissebb $n üzenet elemzése (${filtered.size}-ból)."
        else "$n üzenet elemzése.") + " ${Models.label(model)} gondolkodik…"
        aiAnswer.text = ""
        setBusy(true)
        Thread {
            val res = runCatching { client.ask(prompt) }
            runOnUiThread {
                if (gen != aiGen || isFinishing) return@runOnUiThread
                setBusy(false)
                ai = null
                res.onSuccess { (text, cut) ->
                    aiAnswer.text = Md.toSpanned(text)
                    aiStatus.text = "Kész – $n üzenet alapján, ${Models.label(model)}." +
                        if (cut) " A válasz a hosszkorlát miatt csonka." else ""
                }.onFailure { e ->
                    aiStatus.text = e.message ?: "Az elemzés nem sikerült."
                }
            }
        }.start()
    }

    private fun stopAi(msg: String?) {
        aiGen++
        ai?.let { c -> Thread { c.cancel() }.start() }
        ai = null
        if (::stopBtn.isInitialized) setBusy(false)
        if (msg != null) aiStatus.text = msg
    }

    private fun setBusy(b: Boolean) {
        stopBtn.visibility = if (b) View.VISIBLE else View.GONE
        aiButtons.forEach { it.isEnabled = !b }
    }

    // ---------- lista ----------
    private class DayHeader(val key: String, val ts: Long)

    private inner class MsgAdapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getViewTypeCount() = 2
        override fun getItemViewType(p: Int) = if (items[p] is DayHeader) 0 else 1
        override fun isEnabled(p: Int) = false
        override fun areAllItemsEnabled() = false

        override fun getView(p: Int, convert: View?, parent: ViewGroup?): View {
            val item = items[p]
            if (item is DayHeader) {
                val tv = (convert as? TextView) ?: TextView(this@MainActivity).apply {
                    setPadding(dp(12), dp(14), dp(12), dp(6))
                    textSize = 16f
                    setTypeface(typeface, Typeface.BOLD)
                    setBackgroundColor(pal.dayBg)
                    setTextColor(pal.text)
                }
                tv.text = "${dayFmt.format(Date(item.ts))}  ·  ${dayCounts[item.key] ?: 0} db"
                return tv
            }
            val m = item as Msg
            val box = (convert as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(8), dp(12), dp(8))
                addView(TextView(context).apply { textSize = 13f; setTextColor(pal.text) })
                addView(TextView(context).apply { textSize = 15f; setTextColor(pal.text) })
            }
            val head = box.getChildAt(0) as TextView
            val body = box.getChildAt(1) as TextView

            val h = SpannableStringBuilder()
            val t = timeFmt.format(Date(m.ts))
            h.append(t, ForegroundColorSpan(pal.muted), 0)
            h.append("  ")
            val s = h.length
            h.append(m.app)
            h.setSpan(ForegroundColorSpan(pal.appColor(m.pkg)), s, h.length, 0)
            h.setSpan(StyleSpan(Typeface.BOLD), s, h.length, 0)
            if (m.who.isNotEmpty()) {
                h.append("  ")
                val w = h.length
                h.append(highlight(m.who))
                h.setSpan(StyleSpan(Typeface.BOLD), w, h.length, 0)
            }
            head.text = h
            body.text = highlight(m.text)
            body.visibility = if (m.text.isEmpty()) View.GONE else View.VISIBLE
            return box
        }
    }

    private fun highlight(text: String): CharSequence {
        if (terms.isEmpty()) return text
        val map = ArrayList<Int>(text.length)
        val nsb = StringBuilder()
        for (i in text.indices) {
            val n = LogStore.norm(text[i].toString())
            for (ch in n) { nsb.append(ch); map.add(i) }
        }
        val ns = nsb.toString()
        val sp = SpannableStringBuilder(text)
        for (w in terms) {
            var p = ns.indexOf(w)
            while (p >= 0) {
                val st = map[p]
                val en = map[p + w.length - 1] + 1
                sp.setSpan(BackgroundColorSpan(pal.highlight), st, en, 0)
                sp.setSpan(ForegroundColorSpan(pal.highlightText), st, en, 0)
                p = ns.indexOf(w, p + w.length)
            }
        }
        return sp
    }

    private fun smallButton(label: String) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
