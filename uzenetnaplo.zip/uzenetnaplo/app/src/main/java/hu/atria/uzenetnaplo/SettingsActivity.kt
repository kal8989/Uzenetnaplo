package hu.atria.uzenetnaplo

import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.text.InputType
import android.view.View
import android.widget.Button
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SettingsActivity : Activity() {

    private lateinit var pal: Palette
    private lateinit var status: TextView
    private lateinit var anthropicEdit: EditText
    private lateinit var geminiEdit: EditText
    private lateinit var customEdit: EditText
    private lateinit var dailyCheck: CheckBox
    private lateinit var timeBtn: Button
    private lateinit var dailyStatus: TextView
    private lateinit var updStatus: TextView
    private lateinit var updBtn: Button
    private lateinit var smsStatus: TextView
    private lateinit var mailBox: LinearLayout
    private lateinit var mailStatus: TextView
    private lateinit var costStatus: TextView
    private lateinit var budgetEdit: EditText
    private lateinit var confirmEdit: EditText
    private lateinit var hufEdit: EditText
    private lateinit var newsHours: EditText
    private lateinit var newsModel: EditText
    private lateinit var newsKey: EditText
    private lateinit var newsFeeds: EditText
    private lateinit var newsStatus: TextView
    private lateinit var modelSpinner: Spinner
    private var modelIds: List<String> = emptyList()
    private lateinit var strideEdit: EditText
    private lateinit var ownEmails: EditText
    private lateinit var mboxBtn: Button
    private lateinit var mboxStatus: TextView
    private lateinit var cityBox: LinearLayout
    private lateinit var cityStatus: TextView
    private lateinit var gradPreview: View
    private lateinit var topSquare: View
    private lateinit var bottomSquare: View
    private lateinit var smsBtn: Button
    private var hour = 6
    private var minute = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        pal = Ui.apply(this)
        super.onCreate(savedInstanceState)
        title = "Beállítások"
        val pad = dp(16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, dp(40))
        }

        // --- AI-modell (legelöl) ---
        root.addView(heading("AI-modell"))
        modelSpinner = Spinner(this)
        val choices = Models.choices(Prefs.customModel(this))
        modelIds = choices.map { it.id }
        modelSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, choices.map { it.label }
        )
        val mi = modelIds.indexOf(Prefs.model(this))
        modelSpinner.setSelection(if (mi >= 0) mi else 0, false)
        modelSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                modelIds.getOrNull(pos)?.let { Prefs.setModel(this@SettingsActivity, it) }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(modelSpinner)
        root.addView(text(13f, "Ezt a modellt használják a főképernyő elemzőgombjai és a reggeli összefoglaló."))

        // --- lépésszám és helyi hőmérséklet ---
        root.addView(heading("Lépésszám és hőmérséklet"))
        root.addView(text(13f,
            "A telefon lépésszámlálójából a mai és a tegnapi lépésszám, a lépéshosszból számolt távolsággal. " +
                "A helyi hőmérséklet a legutóbbi ismert helyzeted alapján frissül, óránként."))
        root.addView(CheckBox(this).apply {
            text = "Lépésszám mutatása"
            setTextColor(pal.text)
            isChecked = Health.enabled(this@SettingsActivity)
            setOnCheckedChangeListener { _, on ->
                Health.setEnabled(this@SettingsActivity, on)
                if (on && !Health.hasPermission(this@SettingsActivity)) {
                    requestPermissions(arrayOf(android.Manifest.permission.ACTIVITY_RECOGNITION), REQ_STEPS)
                } else if (on) Health.sample(this@SettingsActivity)
            }
        })
        root.addView(text(13f, "Lépéshossz méterben (pl. 0,75):"))
        strideEdit = EditText(this).apply {
            setSingleLine()
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(Health.stride(this@SettingsActivity).toString())
        }
        root.addView(strideEdit)
        root.addView(button("Helyi hőmérséklet engedélyezése") {
            requestPermissions(arrayOf(android.Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOC)
        })
        root.addView(button("Mentés és frissítés") {
            Health.setStride(this, strideEdit.text.toString().replace(',', '.').toFloatOrNull() ?: 0.75f)
            strideEdit.setText(Health.stride(this).toString())
            val app = applicationContext
            Health.sample(app)
            Thread { Weather.refreshLocal(app) }.start()
            Toast.makeText(this, "Mentve", Toast.LENGTH_SHORT).show()
        })

        // --- naplózás ---
        root.addView(heading("Naplózás"))
        status = text(16f)
        root.addView(status)
        root.addView(button("1. Értesítés-hozzáférés megadása") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(button("2. Célmappa kiválasztása") {
            @Suppress("DEPRECATION")
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_TREE)
        })
        root.addView(button("3. Akkumulátor-optimalizálás kikapcsolása") {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })
        root.addView(button("Tesztbejegyzés írása") {
            val now = System.currentTimeMillis()
            val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(now))
            LogWriter.append(this, listOf(Entry(now, "$ts\tÜzenetnapló\t$packageName\tTeszt\tMűködik ✓")))
            Toast.makeText(this, "Tesztsor elküldve", Toast.LENGTH_SHORT).show()
            status.postDelayed({ refresh() }, 800)
        })

        // --- e-mail-fiókok ---
        root.addView(heading("E-mail-fiókok (Gmail)"))
        root.addView(text(13f,
            "Fiókonként egy alkalmazásjelszó kell: Google-fiók → Biztonság → Kétlépcsős azonosítás → " +
                "Alkalmazásjelszavak. A leveleket az app nem tárolja, kereséskor élőben kérdezi le a Gmailtől."))
        mailBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(mailBox)
        root.addView(button("Fiók hozzáadása") { editAccount(null) })
        mailStatus = text(13f)
        root.addView(mailStatus)

        // --- levélarchívum ---
        root.addView(heading("Levélarchívum (mbox)"))
        root.addView(text(13f,
            "Régi levelek beolvasása kereshető archívumba, hálózat nélkül. A Thunderbird vagy a Google Takeout " +
                "által készített mbox fájlt várja, és havi fájlokba írja a naplómappába. A beérkezett és az " +
                "elküldött mappa mehet ugyanazzal a névvel; ugyanannak a fájlnak az újraimportálása felülírja " +
                "a korábbit, így bármikor megismételhető."))
        root.addView(text(13f, "Saját e-mail címeid, vesszővel – ezekből lesz „Én → …”:"))
        ownEmails = EditText(this).apply {
            setSingleLine()
            hint = "pl. k.osvald@flexiton.hu, kal8989@gmail.com"
            setText(Prefs.ownEmails(this@SettingsActivity).ifBlank {
                MailStore.accounts(this@SettingsActivity).joinToString(", ") { it.address }
            })
        }
        root.addView(ownEmails)
        mboxBtn = button("mbox fájl importálása") {
            Prefs.setOwnEmails(this, ownEmails.text.toString())
            @Suppress("DEPRECATION")
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("*/*"),
                REQ_MBOX
            )
        }
        root.addView(mboxBtn)
        mboxStatus = text(13f)
        root.addView(mboxStatus)

        // --- SMS-archívum ---
        root.addView(heading("SMS-archívum"))
        root.addView(text(13f,
            "A telefon összes korábbi SMS- és MMS-üzenete (a Textra is ezt a tárat használja) " +
                "havi sms_ÉÉÉÉ-HH.txt fájlokba kerül a naplómappában. Az import bármikor megismételhető, " +
                "utána az app 15 percenként magától frissíti a friss hónapokat."))
        smsBtn = button("Összes SMS és MMS importálása") { startSmsImport() }
        root.addView(smsBtn)
        smsStatus = text(13f)
        root.addView(smsStatus)
        root.addView(button("SMS-diagnosztika…") {
            if (!SmsImport.canRead(this)) { startSmsImport(); return@button }
            val input = EditText(this).apply { hint = "keresett szó, pl. Olivola"; setSingleLine() }
            android.app.AlertDialog.Builder(this)
                .setTitle("SMS-diagnosztika")
                .setView(input)
                .setPositiveButton("Vizsgálat") { _, _ ->
                    val w = input.text.toString().trim()
                    val app = applicationContext
                    Thread {
                        val r = try { SmsImport.diagnose(app, w) } catch (e: Exception) { "Hiba: ${e.message}" }
                        runOnUiThread {
                            android.app.AlertDialog.Builder(this)
                                .setTitle("Eredmény")
                                .setMessage(r)
                                .setPositiveButton("OK", null)
                                .show()
                                .findViewById<TextView>(android.R.id.message)?.setTextIsSelectable(true)
                        }
                    }.start()
                }
                .setNegativeButton("Mégse", null)
                .show()
        })
        root.addView(button("Kereső-index újraépítése") {
            smsStatus.text = "Index újraépítése…"
            val app = applicationContext
            MsgIndex.exec.execute {
                MsgIndex.resetNow(app)
                val err = MsgIndex.sync(app) { p -> runOnUiThread { smsStatus.text = p } }
                val n = MsgIndex.totalCount(app)
                runOnUiThread { smsStatus.text = err ?: "Kész – $n üzenet az indexben." }
            }
        })

        // --- megjelenés ---
        root.addView(heading("Megjelenés"))
        val group = RadioGroup(this)
        val opts = listOf("dark" to "Sötét", "light" to "Világos", "system" to "A rendszer szerint")
        opts.forEachIndexed { i, (id, label) ->
            group.addView(RadioButton(this).apply {
                this.id = 100 + i
                text = label
                setTextColor(pal.text)
                isChecked = Prefs.theme(this@SettingsActivity) == id
            })
        }
        group.setOnCheckedChangeListener { _, checked ->
            val id = opts.getOrNull(checked - 100)?.first ?: return@setOnCheckedChangeListener
            if (id != Prefs.theme(this)) {
                Prefs.setTheme(this, id)
                recreate()
            }
        }
        root.addView(group)
        root.addView(CheckBox(this).apply {
            text = "Színátmenetes háttér"
            setTextColor(pal.text)
            isChecked = Prefs.gradient(this@SettingsActivity)
            setOnCheckedChangeListener { _, on ->
                Prefs.setGradient(this@SettingsActivity, on)
                recreate()
            }
        })
        val gradRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        gradPreview = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, dp(90), 1f)
        }
        gradRow.addView(gradPreview)
        val squares = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        topSquare = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(34), dp(34))
            setOnClickListener {
                ColorPicker.show(this@SettingsActivity, "Felső szín", Prefs.gradTop(this@SettingsActivity)) { c ->
                    Prefs.setGradColors(this@SettingsActivity, c, Prefs.gradBottom(this@SettingsActivity))
                    refreshGradient()
                }
            }
        }
        bottomSquare = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)).apply { topMargin = dp(22) }
            setOnClickListener {
                ColorPicker.show(this@SettingsActivity, "Alsó szín", Prefs.gradBottom(this@SettingsActivity)) { c ->
                    Prefs.setGradColors(this@SettingsActivity, Prefs.gradTop(this@SettingsActivity), c)
                    refreshGradient()
                }
            }
        }
        squares.addView(topSquare)
        squares.addView(bottomSquare)
        gradRow.addView(squares)
        root.addView(gradRow)
        root.addView(text(13f, "A kockákra koppintva állítható a kezdő (fent) és a záró (lent) szín."))

        // --- AI ---
        root.addView(heading("AI-elemzés"))
        root.addView(text(13f, "Anthropic API-kulcs (console.anthropic.com → API Keys)"))
        anthropicEdit = secret("sk-ant-…", Prefs.anthropicKey(this))
        root.addView(anthropicEdit)
        root.addView(text(13f, "Google Gemini API-kulcs (aistudio.google.com → Get API key)"))
        geminiEdit = secret("AIza…", Prefs.geminiKey(this))
        root.addView(geminiEdit)
        root.addView(text(13f, "Egyéni modellazonosító (nem kötelező; „gemini” kezdetű = Google, minden más = Anthropic)"))
        customEdit = EditText(this).apply {
            setSingleLine()
            hint = "pl. claude-fable-5-1"
            setText(Prefs.customModel(this@SettingsActivity))
        }
        root.addView(customEdit)
        root.addView(text(13f, "A modellt a főképernyőn, az AI-elemzés résznél választhatod ki."))
        root.addView(button("Kulcsok mentése") {
            Prefs.setKeys(this, anthropicEdit.text.toString(), geminiEdit.text.toString())
            val custom = customEdit.text.toString().trim()
            val old = Prefs.customModel(this)
            Prefs.setCustomModel(this, custom)
            if (custom.isNotEmpty()) Prefs.setModel(this, custom)
            else if (Prefs.model(this) == old) Prefs.setModel(this, Prefs.DEFAULT_MODEL)
            Toast.makeText(this, "Mentve", Toast.LENGTH_SHORT).show()
            refresh()
        })

        // --- költségek ---
        root.addView(heading("AI-költségek"))
        costStatus = text(14f)
        root.addView(costStatus)
        root.addView(text(13f, "Elemzési keret (karakter): mennyi szöveg mehet ki egy kérésben."))
        budgetEdit = EditText(this).apply {
            setSingleLine()
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(Prefs.charBudget(this@SettingsActivity).toString())
        }
        root.addView(budgetEdit)
        root.addView(text(13f, "Figyelmeztetés, ha a becsült ár ezt meghaladja (USD):"))
        confirmEdit = EditText(this).apply {
            setSingleLine()
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(Prefs.confirmOver(this@SettingsActivity).toString())
        }
        root.addView(confirmEdit)
        root.addView(text(13f, "Ft/USD árfolyam a kijelzéshez (0 = csak dollár):"))
        hufEdit = EditText(this).apply {
            setSingleLine()
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(Prefs.huf(this@SettingsActivity).toString())
        }
        root.addView(hufEdit)
        root.addView(CheckBox(this).apply {
            text = "Takarékos mód (Gemini: alacsony gondolkodási szint)"
            setTextColor(pal.text)
            isChecked = Prefs.saver(this@SettingsActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setSaver(this@SettingsActivity, on) }
        })
        root.addView(button("Költségbeállítások mentése") {
            Prefs.setCharBudget(this, budgetEdit.text.toString().toIntOrNull()?.coerceIn(5_000, 400_000) ?: 60_000)
            Prefs.setConfirmOver(this, confirmEdit.text.toString().toFloatOrNull() ?: 0.05f)
            Prefs.setHuf(this, hufEdit.text.toString().toIntOrNull() ?: 0)
            budgetEdit.setText(Prefs.charBudget(this).toString())
            Toast.makeText(this, "Mentve", Toast.LENGTH_SHORT).show()
            refresh()
        })

        // --- reggeli összefoglaló ---
        root.addView(heading("Reggeli összefoglaló"))
        hour = Prefs.dailyHour(this)
        minute = Prefs.dailyMinute(this)
        dailyCheck = CheckBox(this).apply {
            text = "Minden nap automatikusan elkészül (az elmúlt 24 óra)"
            setTextColor(pal.text)
            isChecked = Prefs.dailyEnabled(this@SettingsActivity)
            setOnCheckedChangeListener { _, on -> saveDaily(on) }
        }
        root.addView(dailyCheck)
        timeBtn = button("Időpont: ${fmtTime()}") {
            TimePickerDialog(this, { _, h, m ->
                hour = h; minute = m
                timeBtn.text = "Időpont: ${fmtTime()}"
                saveDaily(dailyCheck.isChecked)
            }, hour, minute, true).show()
        }
        root.addView(timeBtn)
        root.addView(CheckBox(this).apply {
            text = "A Gmail-fiókok levelei is (bejövő és elküldött)"
            setTextColor(pal.text)
            isChecked = Prefs.dailyMail(this@SettingsActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setDailyMail(this@SettingsActivity, on) }
        })
        root.addView(button("Összefoglaló készítése most (próba)") {
            dailyStatus.text = "Készül… (akár egy-két perc)"
            Daily.run(this, done = { ok, msg ->
                runOnUiThread {
                    dailyStatus.text = if (ok) "Kész – megnyitható az értesítésből vagy a főképernyőn." else msg
                }
            })
        })
        dailyStatus = text(13f)
        root.addView(dailyStatus)

        // --- hírek ---
        root.addView(heading("Hírek"))
        root.addView(text(13f,
            "Óránként letölti a megadott hírcsatornákat, és AI-val válogatott összeállítást készít " +
                "(sport nélkül). A főképernyő „Hírek” gombja azonnal megnyitja a kész anyagot."))
        root.addView(CheckBox(this).apply {
            text = "Hírek frissítése a háttérben"
            setTextColor(pal.text)
            isChecked = Prefs.newsEnabled(this@SettingsActivity)
            setOnCheckedChangeListener { _, on ->
                Prefs.setNewsEnabled(this@SettingsActivity, on)
                News.schedule(this@SettingsActivity)
            }
        })
        root.addView(CheckBox(this).apply {
            text = "Fotók a hírek mellé"
            setTextColor(pal.text)
            isChecked = Prefs.newsImages(this@SettingsActivity)
            setOnCheckedChangeListener { _, on -> Prefs.setNewsImages(this@SettingsActivity, on) }
        })
        root.addView(text(13f, "Frissítés óránként (1–12):"))
        newsHours = EditText(this).apply {
            setSingleLine()
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(Prefs.newsInterval(this@SettingsActivity).toString())
        }
        root.addView(newsHours)
        root.addView(text(13f, "Modell a hírekhez (a nyilvános tartalomhoz olcsó modell is elég):"))
        newsModel = EditText(this).apply {
            setSingleLine()
            setText(Prefs.newsModel(this@SettingsActivity))
        }
        root.addView(newsModel)
        root.addView(text(13f, "Külön API-kulcs a hírekhez (üresen hagyva a fenti kulcsot használja):"))
        newsKey = secret("pl. ingyenes Gemini-kulcs", Prefs.newsKey(this))
        root.addView(newsKey)
        root.addView(text(13f, "Hírcsatornák, soronként „Név|cím”:"))
        newsFeeds = EditText(this).apply {
            setText(Prefs.newsFeeds(this@SettingsActivity))
            textSize = 13f
        }
        root.addView(newsFeeds)
        root.addView(button("Hírbeállítások mentése") {
            Prefs.setNewsInterval(this, newsHours.text.toString().toIntOrNull()?.coerceIn(1, 12) ?: 1)
            Prefs.setNewsModel(this, newsModel.text.toString())
            Prefs.setNewsKey(this, newsKey.text.toString())
            Prefs.setNewsFeeds(this, newsFeeds.text.toString())
            News.schedule(this)
            Toast.makeText(this, "Mentve", Toast.LENGTH_SHORT).show()
        })
        root.addView(button("Hírcsatornák próbája") {
            newsStatus.text = "Letöltés…"
            val app = applicationContext
            Thread {
                val (items, errors) = News.fetchAll(app) { p -> runOnUiThread { newsStatus.text = p } }
                runOnUiThread {
                    newsStatus.text = "${items.size} hír érkezett" +
                        if (errors.isEmpty()) " – minden csatorna rendben." else ".\nHibák: " + errors.joinToString("\n")
                }
            }.start()
        })
        newsStatus = text(13f)
        root.addView(newsStatus)

        // --- időjárás ---
        root.addView(heading("Időjárás"))
        root.addView(text(13f,
            "A városok adatai az ingyenes Open-Meteo szolgáltatásból jönnek (kulcs és költség nélkül), " +
                "óránként a hírekkel együtt frissülnek. A városra koppintva az AccuWeather 30 napos oldala nyílik, " +
                "ha megadtál saját linket; egyébként keresés a város nevére."))
        cityBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(cityBox)
        root.addView(button("Város hozzáadása") { addCity() })
        cityStatus = text(13f)
        root.addView(cityStatus)

        // --- frissítés ---
        root.addView(heading("Frissítés"))
        updStatus = text(13f, "Telepített verzió: ${Updater.installedBuild(this)}")
        root.addView(updStatus)
        updBtn = button("Frissítés keresése és telepítése") { checkUpdate() }
        root.addView(updBtn)

        setContentView(ScrollView(this).apply {
            background = Ui.background(this@SettingsActivity, pal)
            addView(root)
        })
        refreshGradient()

        if (intent?.getBooleanExtra(EXTRA_UPDATE, false) == true) checkUpdate()
    }

    override fun onResume() {
        super.onResume()
        renderAccounts()
        renderCities()
        if (Prefs.listenerEnabled(this)) {
            NotificationListenerService.requestRebind(
                ComponentName(this, NotificationLogService::class.java)
            )
        }
        refresh()
    }

    private fun fmtTime() = String.format(Locale.US, "%02d:%02d", hour, minute)

    private fun saveDaily(on: Boolean) {
        Prefs.setDaily(this, on, hour, minute)
        Daily.schedule(this)
        if (on && Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
        refresh()
    }

    private fun renderCities() {
        if (!::cityBox.isInitialized) return
        cityBox.removeAllViews()
        val list = Weather.cities(this)
        if (list.isEmpty()) {
            cityBox.addView(text(13f, "Nincs felvett város."))
            return
        }
        list.forEachIndexed { i, c ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
            }
            row.addView(text(14f, c.name + if (c.url.isBlank()) "" else "  🔗").apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            row.addView(Button(this).apply {
                text = "Link"
                isAllCaps = false
                setOnClickListener { editCityLink(i) }
            })
            row.addView(Button(this).apply {
                text = "Törlés"
                isAllCaps = false
                setOnClickListener {
                    val l = Weather.cities(this@SettingsActivity).toMutableList()
                    l.removeAt(i)
                    Weather.saveCities(this@SettingsActivity, l)
                    renderCities()
                }
            })
            cityBox.addView(row)
        }
    }

    private fun addCity() {
        val input = EditText(this).apply { hint = "pl. Kecskemét"; setSingleLine() }
        android.app.AlertDialog.Builder(this)
            .setTitle("Város keresése")
            .setView(input)
            .setPositiveButton("Keresés") { _, _ ->
                val q = input.text.toString().trim()
                if (q.isEmpty()) return@setPositiveButton
                cityStatus.text = "Keresés…"
                Thread {
                    val res = try {
                        Weather.geocode(q)
                    } catch (e: Exception) {
                        emptyList()
                    }
                    runOnUiThread {
                        if (res.isEmpty()) {
                            cityStatus.text = "Nincs találat erre: $q"
                            return@runOnUiThread
                        }
                        val labels = res.map { it.name }.toTypedArray()
                        android.app.AlertDialog.Builder(this)
                            .setTitle("Melyik?")
                            .setItems(labels) { _, which ->
                                val l = Weather.cities(this).toMutableList()
                                l.add(res[which])
                                Weather.saveCities(this, l)
                                cityStatus.text = "Hozzáadva: ${res[which].name}"
                                renderCities()
                            }
                            .setNegativeButton("Mégse", null)
                            .show()
                    }
                }.start()
            }
            .setNegativeButton("Mégse", null)
            .show()
    }

    private fun editCityLink(index: Int) {
        val list = Weather.cities(this).toMutableList()
        val c = list[index]
        val input = EditText(this).apply {
            hint = "AccuWeather-link (megosztásból beillesztve)"
            setText(c.url)
        }
        android.app.AlertDialog.Builder(this)
            .setTitle(c.name)
            .setView(input)
            .setPositiveButton("Mentés") { _, _ ->
                list[index] = City(c.name, c.lat, c.lon, input.text.toString().trim())
                Weather.saveCities(this, list)
                renderCities()
            }
            .setNegativeButton("Mégse", null)
            .show()
    }

    private fun renderAccounts() {
        if (!::mailBox.isInitialized) return
        mailBox.removeAllViews()
        val list = MailStore.accounts(this)
        if (list.isEmpty()) {
            mailBox.addView(text(13f, "Nincs felvett fiók."))
            return
        }
        list.forEachIndexed { i, acc ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
            }
            row.addView(CheckBox(this).apply {
                text = acc.address
                setTextColor(pal.text)
                isChecked = acc.enabled
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnCheckedChangeListener { _, on ->
                    val l = MailStore.accounts(this@SettingsActivity).toMutableList()
                    l[i] = MailAccount(acc.address, acc.password, on)
                    MailStore.saveAccounts(this@SettingsActivity, l)
                }
            })
            row.addView(Button(this).apply {
                text = "Próba"
                isAllCaps = false
                setOnClickListener {
                    mailStatus.text = "Kapcsolódás: ${acc.address}…"
                    Thread {
                        val r = MailStore.test(acc)
                        runOnUiThread { mailStatus.text = "${acc.address}: $r" }
                    }.start()
                }
            })
            row.addView(Button(this).apply {
                text = "…"
                isAllCaps = false
                setOnClickListener { editAccount(i) }
            })
            mailBox.addView(row)
        }
    }

    private fun editAccount(index: Int?) {
        val list = MailStore.accounts(this).toMutableList()
        val acc = index?.let { list[it] }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val addr = EditText(this).apply {
            hint = "cim@gmail.com"
            setSingleLine()
            setText(acc?.address.orEmpty())
        }
        val pw = secret("alkalmazásjelszó (16 karakter)", acc?.password.orEmpty())
        box.addView(addr)
        box.addView(pw)
        val b = android.app.AlertDialog.Builder(this)
            .setTitle(if (acc == null) "Fiók hozzáadása" else "Fiók módosítása")
            .setView(box)
            .setPositiveButton("Mentés") { _, _ ->
                val a = addr.text.toString().trim()
                val p = pw.text.toString().replace(" ", "")
                if (a.isNotEmpty() && p.isNotEmpty()) {
                    val newAcc = MailAccount(a, p, acc?.enabled ?: true)
                    if (index == null) list.add(newAcc) else list[index] = newAcc
                    MailStore.saveAccounts(this, list)
                    renderAccounts()
                    mailStatus.text = "Mentve – érdemes a Próba gombbal ellenőrizni."
                }
            }
            .setNegativeButton("Mégse", null)
        if (index != null) b.setNeutralButton("Törlés") { _, _ ->
            list.removeAt(index)
            MailStore.saveAccounts(this, list)
            renderAccounts()
        }
        b.show()
    }

    private fun askMboxLabel(uri: Uri) {
        val name = fileName(uri)
        val input = EditText(this).apply {
            setSingleLine()
            setText(Prefs.lastMboxLabel(this@SettingsActivity).ifBlank { "Levelek" })
            setSelection(text.length)
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Melyik postafiók?")
            .setMessage(
                "A fájl: $name\n\nEz a név jelenik meg a lista „alkalmazás” oszlopában. A beérkezett és az " +
                    "elküldött leveleket add meg ugyanazzal a névvel – az app a feladó címe alapján " +
                    "magától tudja, melyik a kimenő."
            )
            .setView(input)
            .setPositiveButton("Import indítása") { _, _ ->
                val label = input.text.toString().trim().ifEmpty { "Levelek" }
                Prefs.setLastMboxLabel(this, label)
                runMbox(uri, label, name)
            }
            .setNegativeButton("Mégse", null)
            .show()
    }

    private fun fileName(uri: Uri): String = try {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) c.getString(i) else null
        } ?: uri.lastPathSegment.orEmpty()
    } catch (e: Exception) {
        "mail"
    }

    private fun runMbox(uri: Uri, label: String, source: String) {
        mboxBtn.isEnabled = false
        mboxStatus.text = "Import indul – maradj ezen a képernyőn…"
        val app = applicationContext
        val mine = (Prefs.ownEmails(app) + "," + MailStore.accounts(app).joinToString(",") { it.address })
            .split(',').map { it.trim() }.filter { it.contains('@') }
        MsgIndex.exec.execute {
            val msg = try {
                val r = MailImport.importMbox(app, uri, label, source, mine) { p ->
                    runOnUiThread { mboxStatus.text = p }
                }
                runOnUiThread { mboxStatus.text = "${r.count} levél kiírva – indexelés…" }
                val err = MsgIndex.sync(app) { p -> runOnUiThread { mboxStatus.text = p } }
                err ?: "Kész: ${r.count} levél, ${r.months} havi fájl" +
                    (if (r.skipped > 0) ", ${r.skipped} kihagyva (hiányzó dátum)" else "") +
                    ". Összesen ${MsgIndex.totalCount(app)} üzenet kereshető."
            } catch (e: Exception) {
                "Az import nem sikerült: ${e.message}"
            }
            runOnUiThread {
                mboxStatus.text = msg
                mboxBtn.isEnabled = true
            }
        }
    }

    private fun startSmsImport() {
        if (LogWriter.treeUri(this) == null) {
            smsStatus.text = "Előbb válaszd ki a naplómappát (2. lépés)."
            return
        }
        val missing = SmsImport.PERMS.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), REQ_SMS)
            return
        }
        smsBtn.isEnabled = false
        smsStatus.text = "Import indul…"
        val app = applicationContext
        MsgIndex.exec.execute {
            val msg = try {
                val n = SmsImport.import(app, null) { p -> runOnUiThread { smsStatus.text = p } }
                runOnUiThread { smsStatus.text = "$n üzenet kiírva – indexelés…" }
                val err = MsgIndex.sync(app) { p -> runOnUiThread { smsStatus.text = p } }
                err ?: "Kész: $n SMS/MMS importálva. Összesen ${MsgIndex.totalCount(app)} üzenet kereshető."
            } catch (e: Exception) {
                "Az import nem sikerült: ${e.message}"
            }
            runOnUiThread {
                smsStatus.text = msg
                smsBtn.isEnabled = true
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_STEPS) {
            if (Health.hasPermission(this)) Health.sample(this)
            return
        }
        if (requestCode == REQ_LOC) {
            val app = applicationContext
            Thread { Weather.refreshLocal(app) }.start()
            return
        }
        if (requestCode != REQ_SMS) return
        if (SmsImport.canRead(this)) startSmsImport()
        else smsStatus.text = "SMS-olvasási engedély nélkül nem megy. Ha a kapcsoló szürke: " +
            "Beállítások → Alkalmazások → Üzenetnapló → ⋮ → Korlátozott beállítások engedélyezése."
    }

    private fun checkUpdate() {
        if (!packageManager.canRequestPackageInstalls()) {
            Toast.makeText(this, "Engedélyezd az alkalmazások telepítését, majd nyomd meg újra a gombot.", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)
                    .setData(Uri.parse("package:$packageName"))
            )
            return
        }
        updBtn.isEnabled = false
        updStatus.text = "Keresés…"
        val app = applicationContext
        Thread {
            try {
                val rel = Updater.latest()
                Prefs.setLastUpdateCheck(app, System.currentTimeMillis())
                val cur = Updater.installedBuild(app)
                if (rel.build <= cur) {
                    runOnUiThread {
                        updStatus.text = "A legfrissebb verzió van telepítve ($cur)."
                        updBtn.isEnabled = true
                    }
                    return@Thread
                }
                runOnUiThread { updStatus.text = "Új verzió: ${rel.build}. Letöltés…" }
                Updater.download(app, rel.url) { p ->
                    runOnUiThread {
                        updStatus.text = if (p >= 0) "Letöltés: $p%" else "Letöltés…"
                    }
                }
                runOnUiThread {
                    updStatus.text = "Letöltve – telepítés indul."
                    updBtn.isEnabled = true
                    startActivity(
                        Intent(Intent.ACTION_VIEW)
                            .setDataAndType(Updater.contentUri(), Updater.APK_MIME)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            } catch (e: Exception) {
                runOnUiThread {
                    updStatus.text = "Nem sikerült: ${e.message}"
                    updBtn.isEnabled = true
                }
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_MBOX && resultCode == RESULT_OK) {
            data?.data?.let { askMboxLabel(it) }
            return
        }
        if (requestCode == REQ_TREE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            LogWriter.setTreeUri(this, uri)
            MsgIndex.reset(this)
            status.postDelayed({ refresh() }, 500)
        }
    }

    private fun refreshGradient() {
        if (!::gradPreview.isInitialized) return
        val top = Prefs.gradTop(this).let { if (it == 0) pal.bg else it }
        val bottom = Prefs.gradBottom(this).let { if (it == 0) pal.dayBg else it }
        gradPreview.background = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)
        )
        topSquare.setBackgroundColor(top)
        bottomSquare.setBackgroundColor(bottom)
        if (Prefs.gradient(this)) {
            (window.decorView.findViewById<View>(android.R.id.content) as? ViewGroup)
                ?.getChildAt(0)?.background = Ui.background(this, pal)
        }
    }

    private fun refresh() {
        val listener = Prefs.listenerEnabled(this)
        val tree = LogWriter.treeUri(this)
        val pm = getSystemService(PowerManager::class.java)
        val battery = pm?.isIgnoringBatteryOptimizations(packageName) == true
        val hasA = Prefs.anthropicKey(this).isNotBlank()
        val hasG = Prefs.geminiKey(this).isNotBlank()
        val ctx = applicationContext
        LogWriter.run {
            val pending = LogWriter.pendingCount(ctx)
            runOnUiThread {
                status.text = buildString {
                    append(mark(listener)).append(" Értesítés-hozzáférés\n")
                    append(mark(tree != null)).append(" Célmappa: ")
                        .append(tree?.lastPathSegment?.substringAfter(':') ?: "nincs kiválasztva").append('\n')
                    append(mark(battery)).append(" Akkumulátor-optimalizálás kikapcsolva\n")
                    append(mark(hasA)).append(" Anthropic-kulcs   ")
                    append(mark(hasG)).append(" Gemini-kulcs\n")
                    if (pending > 0) append("Átmásolásra vár: ").append(pending).append(" sor\n")
                }
            }
        }
        if (::costStatus.isInitialized) costStatus.text = Cost.monthSummary(this)
        if (::smsStatus.isInitialized && smsStatus.text.isNullOrEmpty()) {
            val last = SmsImport.lastFullImport(this)
            if (last > 0) smsStatus.text = "Utolsó teljes import: " +
                SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(last))
        }
        if (::dailyStatus.isInitialized && dailyStatus.text.isNullOrEmpty() && Prefs.dailyEnabled(this)) {
            val next = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(Daily.nextTime(this)))
            dailyStatus.text = "Következő: $next – modell: ${Models.label(Prefs.model(this))}"
        }
    }

    private fun mark(ok: Boolean) = if (ok) "✅" else "❌"

    private fun heading(t: String) = TextView(this).apply {
        text = t
        textSize = 19f
        setTextColor(pal.accent)
        setPadding(0, dp(22), 0, dp(6))
    }

    private fun text(size: Float, t: String = "") = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(pal.text)
    }

    private fun secret(hintText: String, value: String) = EditText(this).apply {
        hint = hintText
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        setSingleLine()
        setText(value)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener(View.OnClickListener { action() })
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQ_TREE = 42
        private const val REQ_SMS = 43
        private const val REQ_STEPS = 44
        private const val REQ_LOC = 45
        private const val REQ_MBOX = 46
        const val EXTRA_UPDATE = "start_update"
    }
}
