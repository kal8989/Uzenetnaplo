package hu.atria.uzenetnaplo

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SettingsActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var keyEdit: EditText
    private lateinit var modelEdit: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Beállítások"
        val pad = dp(16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        status = TextView(this).apply { textSize = 16f }
        root.addView(status)

        root.addView(button("1. Értesítés-hozzáférés megadása") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(button("2. Célmappa kiválasztása") {
            @Suppress("DEPRECATION")
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_TREE)
        })
        root.addView(button("3. Akkumulátor-optimalizálás kikapcsolása") {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })
        root.addView(button("Tesztbejegyzés írása") {
            val now = System.currentTimeMillis()
            val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(now))
            LogWriter.append(this, listOf(Entry(now, "$ts\tÜzenetnapló\t$packageName\tTeszt\tMűködik ✓")))
            Toast.makeText(this, "Tesztsor elküldve", Toast.LENGTH_SHORT).show()
            status.postDelayed({ refresh() }, 800)
        })

        root.addView(TextView(this).apply {
            text = "\nAI-elemzés (Anthropic API)"
            textSize = 18f
        })
        root.addView(TextView(this).apply {
            text = "API-kulcs (console.anthropic.com → API Keys). Csak ezen a telefonon tárolódik."
            textSize = 13f
        })
        keyEdit = EditText(this).apply {
            hint = "sk-ant-…"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
            setText(Prefs.apiKey(this@SettingsActivity))
        }
        root.addView(keyEdit)
        root.addView(TextView(this).apply { text = "Modell"; textSize = 13f })
        modelEdit = EditText(this).apply {
            setSingleLine()
            setText(Prefs.model(this@SettingsActivity))
        }
        root.addView(modelEdit)
        root.addView(button("Mentés") {
            Prefs.save(this, keyEdit.text.toString(), modelEdit.text.toString())
            Toast.makeText(this, "Mentve", Toast.LENGTH_SHORT).show()
            refresh()
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        if (Prefs.listenerEnabled(this)) {
            NotificationListenerService.requestRebind(
                ComponentName(this, NotificationLogService::class.java)
            )
        }
        refresh()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_TREE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            LogWriter.setTreeUri(this, uri)
            LogStore.clearCache()
            status.postDelayed({ refresh() }, 500)
        }
    }

    private fun refresh() {
        val listener = Prefs.listenerEnabled(this)
        val tree = LogWriter.treeUri(this)
        val pm = getSystemService(PowerManager::class.java)
        val battery = pm?.isIgnoringBatteryOptimizations(packageName) == true
        val hasKey = Prefs.apiKey(this).isNotBlank()
        val ctx = applicationContext
        LogWriter.run {
            val pending = LogWriter.pendingCount(ctx)
            runOnUiThread {
                status.text = buildString {
                    append(mark(listener)).append(" Értesítés-hozzáférés\n")
                    append(mark(tree != null)).append(" Célmappa: ")
                        .append(tree?.lastPathSegment?.substringAfter(':') ?: "nincs kiválasztva").append('\n')
                    append(mark(battery)).append(" Akkumulátor-optimalizálás kikapcsolva\n")
                    append(mark(hasKey)).append(" API-kulcs megadva\n")
                    if (pending > 0) append("Átmásolásra vár: ").append(pending).append(" sor\n")
                }
            }
        }
    }

    private fun mark(ok: Boolean) = if (ok) "✅" else "❌"

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener(View.OnClickListener { action() })
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQ_TREE = 42
    }
}
