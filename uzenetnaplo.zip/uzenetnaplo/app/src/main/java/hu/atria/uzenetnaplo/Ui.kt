package hu.atria.uzenetnaplo

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color

class Palette(val dark: Boolean) {
    val bg = Color.parseColor(if (dark) "#151B22" else "#FFFFFF")
    val text = Color.parseColor(if (dark) "#E3E8EE" else "#1D2733")
    val muted = Color.parseColor(if (dark) "#93A2B2" else "#6B7A8A")
    val accent = Color.parseColor(if (dark) "#8DB2F0" else "#2F5DA8")
    val dayBg = Color.parseColor(if (dark) "#222C37" else "#E8EDF2")
    val bannerBg = Color.parseColor(if (dark) "#4A2A22" else "#F6E3DC")
    val bannerText = Color.parseColor(if (dark) "#F2C4B6" else "#7A2E1C")
    val infoBg = Color.parseColor(if (dark) "#1F3350" else "#DDE8F7")
    val highlight = Color.parseColor("#F2D16B")
    val highlightText = Color.parseColor("#1D2733")

    fun appColor(pkg: String): Int {
        val hue = (((pkg.hashCode() % 360) + 360) % 360).toFloat()
        return Color.HSVToColor(
            if (dark) floatArrayOf(hue, 0.45f, 0.9f) else floatArrayOf(hue, 0.6f, 0.55f)
        )
    }
}

object Ui {
    fun isDark(ctx: Context): Boolean = when (Prefs.theme(ctx)) {
        "light" -> false
        "dark" -> true
        else -> (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
    }

    /** onCreate-ben, a super.onCreate ELŐTT hívandó. */
    fun apply(act: Activity): Palette {
        val dark = isDark(act)
        act.setTheme(
            if (dark) android.R.style.Theme_Material
            else android.R.style.Theme_Material_Light_DarkActionBar
        )
        return Palette(dark)
    }
}
