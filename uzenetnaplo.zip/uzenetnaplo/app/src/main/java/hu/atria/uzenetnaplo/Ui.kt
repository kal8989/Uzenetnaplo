package hu.atria.uzenetnaplo

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color

class Palette(val dark: Boolean) {
    val bg = Color.parseColor(if (dark) "#151B22" else "#FFFFFF")
    val text = Color.parseColor(if (dark) "#E3E8EE" else "#1D2733")
    val muted = Color.parseColor(if (dark) "#93A2B2" else "#6B7A8A")
    val accent = Color.parseColor(if (dark) "#8DB2F0" else "#2F5DA8")
    val dayBg = Color.parseColor(if (dark) "#222C37" else "#E8EDF2")
    val bannerBg = Color.parseColor(if (dark) "#4A2A22" else "#F6E3DC")
    val bannerText = Color.parseColor(if (dark) "#F2C4B6" else "#7A2E1C")
    val infoBg = Color.parseColor(if (dark) "#1F3350" else "#DDE8F7")
    val highlight = Color.parseColor("#F2D16B")
    val highlightText = Color.parseColor("#1D2733")

    fun appColor(pkg: String): Int {
        val hue = (((pkg.hashCode() % 360) + 360) % 360).toFloat()
        return Color.HSVToColor(
            if (dark) floatArrayOf(hue, 0.45f, 0.9f) else floatArrayOf(hue, 0.6f, 0.55f)
        )
    }
}

object Ui {
    /** A képernyők háttere: sima szín vagy színátmenet. */
    fun background(ctx: Context, pal: Palette): android.graphics.drawable.Drawable {
        if (!Prefs.gradient(ctx)) return android.graphics.drawable.ColorDrawable(pal.bg)
        val top = Prefs.gradTop(ctx).let { if (it == 0) pal.bg else it }
        val bottom = Prefs.gradBottom(ctx).let { if (it == 0) pal.dayBg else it }
        return android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(top, bottom)
        )
    }

    fun isDark(ctx: Context): Boolean = when (Prefs.theme(ctx)) {
        "light" -> false
        "dark" -> true
        else -> (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
    }

    /** onCreate-ben, a super.onCreate ELŐTT hívandó. */
    fun apply(act: Activity): Palette {
        val dark = isDark(act)
        act.setTheme(
            if (dark) android.R.style.Theme_Material
            else android.R.style.Theme_Material_Light_DarkActionBar
        )
        return Palette(dark)
    }

}

/** Egyszerű RGB-színválasztó, külső könyvtár nélkül. */
object ColorPicker {
    fun show(act: Activity, title: String, initial: Int, onPick: (Int) -> Unit) {
        val start = if (initial == 0) Color.parseColor("#1D2733") else initial
        val dp = { v: Int -> (v * act.resources.displayMetrics.density).toInt() }
        val box = android.widget.LinearLayout(act).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
        }
        val preview = android.view.View(act).apply {
            setBackgroundColor(start)
            layoutParams = android.widget.LinearLayout.LayoutParams(
                android.view.ViewGroup.LayoutParams.MATCH_PARENT, dp(60)
            )
        }
        box.addView(preview)
        val hex = android.widget.TextView(act).apply { setPadding(0, dp(8), 0, dp(4)) }
        box.addView(hex)
        var r = Color.red(start); var g = Color.green(start); var b = Color.blue(start)
        fun update() {
            val c = Color.rgb(r, g, b)
            preview.setBackgroundColor(c)
            hex.text = String.format("#%06X", c and 0xFFFFFF)
        }
        listOf("Vörös" to 0, "Zöld" to 1, "Kék" to 2).forEach { (name, idx) ->
            box.addView(android.widget.TextView(act).apply { text = name; textSize = 13f })
            box.addView(android.widget.SeekBar(act).apply {
                max = 255
                progress = when (idx) { 0 -> r; 1 -> g; else -> b }
                setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: android.widget.SeekBar?, value: Int, fromUser: Boolean) {
                        when (idx) { 0 -> r = value; 1 -> g = value; else -> b = value }
                        update()
                    }
                    override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
                    override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
                })
            })
        }
        update()
        android.app.AlertDialog.Builder(act)
            .setTitle(title)
            .setView(android.widget.ScrollView(act).apply { addView(box) })
            .setPositiveButton("Kész") { _, _ -> onPick(Color.rgb(r, g, b)) }
            .setNegativeButton("Mégse", null)
            .show()
    }
}
