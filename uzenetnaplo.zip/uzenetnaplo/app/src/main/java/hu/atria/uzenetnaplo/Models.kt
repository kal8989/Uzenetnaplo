package hu.atria.uzenetnaplo

class AiModel(val id: String, val label: String)

object Models {
    val list = listOf(
        AiModel("claude-opus-5", "Claude Opus 5 (legerősebb)"),
        AiModel("claude-sonnet-5", "Claude Sonnet 5"),
        AiModel("claude-haiku-4-5-20251001", "Claude Haiku 4.5 (gyors, olcsó)"),
        AiModel("gemini-3.1-pro-preview", "Gemini 3.1 Pro"),
        AiModel("gemini-3.8-flash", "Gemini 3.8 Flash"),
        AiModel("gemini-3.5-flash-lite", "Gemini 3.5 Flash-Lite (olcsó)"),
    )

    fun isGemini(id: String) = id.startsWith("gemini")

    /** A választható lista, kiegészítve az egyéni modellel, ha van. */
    fun choices(custom: String): List<AiModel> =
        if (custom.isBlank() || list.any { it.id == custom }) list
        else list + AiModel(custom, "Egyéni: $custom")

    fun label(id: String) = list.firstOrNull { it.id == id }?.label ?: id
}
