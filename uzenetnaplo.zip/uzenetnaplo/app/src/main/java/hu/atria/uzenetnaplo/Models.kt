package hu.atria.uzenetnaplo

/** [inUsd]/[outUsd]: USD / millió token; 0 = ismeretlen ár. */
class AiModel(val id: String, val label: String, val inUsd: Double = 0.0, val outUsd: Double = 0.0)

object Models {
    val list = listOf(
        AiModel("claude-opus-5", "Claude Opus 5 (legerősebb)", 5.0, 25.0),
        AiModel("claude-sonnet-5", "Claude Sonnet 5", 2.0, 10.0),
        AiModel("claude-haiku-4-5-20251001", "Claude Haiku 4.5 (gyors, olcsó)", 1.0, 5.0),
        AiModel("gemini-3.1-pro-preview", "Gemini 3.1 Pro", 2.0, 12.0),
        AiModel("gemini-3.8-flash", "Gemini 3.8 Flash"),
        AiModel("gemini-3.5-flash-lite", "Gemini 3.5 Flash-Lite (olcsó)", 0.30, 2.50),
    )

    fun isGemini(id: String) = id.startsWith("gemini")

    /** A választható lista, kiegészítve az egyéni modellel, ha van. */
    fun choices(custom: String): List<AiModel> =
        if (custom.isBlank() || list.any { it.id == custom }) list
        else list + AiModel(custom, "Egyéni: $custom")

    fun label(id: String) = list.firstOrNull { it.id == id }?.label ?: id

    fun price(id: String): AiModel? = list.firstOrNull { it.id == id && (it.inUsd > 0 || it.outUsd > 0) }

    /** Költség USD-ben, vagy null, ha az ár ismeretlen. */
    fun cost(id: String, inTok: Long, outTok: Long): Double? {
        val m = price(id) ?: return null
        return inTok / 1_000_000.0 * m.inUsd + outTok / 1_000_000.0 * m.outUsd
    }
}
