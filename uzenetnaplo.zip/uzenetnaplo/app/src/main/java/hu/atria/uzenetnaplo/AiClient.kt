package hu.atria.uzenetnaplo

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Egyszerű, nem streamelő hívás az Anthropic Messages API-ra. */
class AiClient(private val apiKey: String, private val model: String) {
    @Volatile private var conn: HttpURLConnection? = null

    fun cancel() {
        try { conn?.disconnect() } catch (_: Exception) {}
    }

    /** Blokkoló hívás – háttérszálról hívandó. Visszaad: (szöveg, csonka-e). */
    fun ask(prompt: String): Pair<String, Boolean> {
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn = c
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 20_000
            c.readTimeout = 300_000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", apiKey)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            val body = JSONObject()
                .put("model", model)
                .put("max_tokens", 4000)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val txt = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                val apiMsg = try {
                    JSONObject(txt).getJSONObject("error").getString("message")
                } catch (_: Exception) {
                    txt.take(300)
                }
                val hint = when (code) {
                    401 -> "Érvénytelen API-kulcs."
                    403 -> "A kulcsnak nincs jogosultsága."
                    404 -> "Ismeretlen modellnév – ellenőrizd a beállításokban."
                    413 -> "Túl sok az adat – szűkítsd az időszakot."
                    429 -> "Túl sok kérés vagy elfogyott a keret – próbáld később."
                    529, 503 -> "Az API most túlterhelt – próbáld később."
                    else -> "API-hiba ($code)."
                }
                throw IOException("$hint\n$apiMsg")
            }
            val json = JSONObject(txt)
            val arr = json.getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until arr.length()) {
                val b = arr.getJSONObject(i)
                if (b.optString("type") == "text") sb.append(b.optString("text"))
            }
            return sb.toString() to (json.optString("stop_reason") == "max_tokens")
        } finally {
            conn = null
            try { c.disconnect() } catch (_: Exception) {}
        }
    }
}
