package hu.atria.uzenetnaplo

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Nem streamelő hívás: Anthropic Messages API vagy Google Gemini API. */
class Answer(val text: String, val truncated: Boolean, val inTok: Long, val outTok: Long)

class AiClient(ctx: Context, private val model: String, keyOverride: String? = null) {
    private val gemini = Models.isGemini(model)
    private val key = keyOverride ?: if (gemini) Prefs.geminiKey(ctx) else Prefs.anthropicKey(ctx)
    private val saver = Prefs.saver(ctx)
    @Volatile private var conn: HttpURLConnection? = null

    val providerName get() = if (gemini) "Gemini" else "Anthropic"
    fun hasKey() = key.isNotBlank()

    fun cancel() {
        try { conn?.disconnect() } catch (_: Exception) {}
    }

    /** Blokkoló – háttérszálról. */
    fun ask(prompt: String): Answer = if (gemini) askGemini(prompt) else askAnthropic(prompt)

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        conn = c
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 20_000
            c.readTimeout = 300_000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            return code to (stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty())
        } finally {
            conn = null
            try { c.disconnect() } catch (_: Exception) {}
        }
    }

    private fun apiError(code: Int, txt: String): IOException {
        val msg = try {
            JSONObject(txt).getJSONObject("error").optString("message")
        } catch (_: Exception) {
            txt.take(300)
        }
        val hint = when {
            code == 401 || msg.contains("API key", true) && code == 400 -> "Érvénytelen $providerName API-kulcs."
            code == 403 -> "A $providerName-kulcsnak nincs jogosultsága ehhez."
            code == 404 -> "Ismeretlen modell: $model"
            code == 413 -> "Túl sok az adat – szűkítsd az időszakot."
            code == 429 -> "Túl sok kérés vagy elfogyott a keret ($providerName)."
            code == 503 || code == 529 -> "A $providerName most túlterhelt – próbáld később."
            else -> "$providerName API-hiba ($code)."
        }
        return IOException("$hint\n$msg")
    }

    private fun askAnthropic(prompt: String): Answer {
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 4000)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
        val (code, txt) = post(
            "https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"),
            body
        )
        if (code !in 200..299) throw apiError(code, txt)
        val json = JSONObject(txt)
        val arr = json.getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val b = arr.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.optString("text"))
        }
        val u = json.optJSONObject("usage")
        return Answer(
            sb.toString(), json.optString("stop_reason") == "max_tokens",
            u?.optLong("input_tokens") ?: 0, u?.optLong("output_tokens") ?: 0,
        )
    }

    private fun askGemini(prompt: String): Answer {
        val gen = JSONObject().put("maxOutputTokens", 16000)
        // takarékos mód: alacsony gondolkodási szint (a 3.x modelleknél ez a legkevesebb)
        if (saver) gen.put("thinkingConfig", JSONObject().put("thinkingLevel", "low"))
        val body = JSONObject()
            .put("contents", JSONArray().put(
                JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", prompt)))
            ))
            .put("generationConfig", gen)
        val url = "https://generativelanguage.googleapis.com/v1beta/models/" +
            URLEncoder.encode(model, "UTF-8") + ":generateContent"
        var (code, txt) = post(url, mapOf("x-goog-api-key" to key), body)
        if (code == 400 && saver && txt.contains("thinking", true)) {
            // a modell nem ismeri a gondolkodási szintet – újra, anélkül
            gen.remove("thinkingConfig")
            val r = post(url, mapOf("x-goog-api-key" to key), body)
            code = r.first; txt = r.second
        }
        if (code !in 200..299) throw apiError(code, txt)
        val json = JSONObject(txt)
        val block = json.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
        if (block.isNotEmpty()) throw IOException("A Gemini elutasította a kérést ($block).")
        val cands = json.optJSONArray("candidates")
            ?: throw IOException("A Gemini nem adott választ.")
        val cand = cands.getJSONObject(0)
        val parts = cand.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (p.optBoolean("thought", false)) continue
            sb.append(p.optString("text"))
        }
        if (sb.isBlank()) throw IOException("A Gemini üres választ adott (${cand.optString("finishReason")}).")
        val u = json.optJSONObject("usageMetadata")
        val inTok = u?.optLong("promptTokenCount") ?: 0
        val outTok = (u?.optLong("candidatesTokenCount") ?: 0) + (u?.optLong("thoughtsTokenCount") ?: 0)
        return Answer(sb.toString(), cand.optString("finishReason") == "MAX_TOKENS", inTok, outTok)
    }
}
