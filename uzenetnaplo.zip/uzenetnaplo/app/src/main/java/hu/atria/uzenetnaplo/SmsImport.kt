package hu.atria.uzenetnaplo

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TreeMap

/**
 * A rendszer SMS/MMS-tárának (ezt használja a Textra is) kiírása havi sms_ÉÉÉÉ-HH.txt fájlokba.
 * A fájlokat mindig teljes egészében újraírja, így az import tetszőlegesen ismételhető.
 */
object SmsImport {
    val PERMS = arrayOf(Manifest.permission.READ_SMS, Manifest.permission.READ_CONTACTS)
    private const val QUICK_EVERY = 15 * 60_000L

    fun canRead(ctx: Context) =
        ctx.checkSelfPermission(Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("sms", Context.MODE_PRIVATE)

    fun lastFullImport(ctx: Context) = prefs(ctx).getLong("full_ts", 0)

    /** Az előző hónap elejétől frissít, legfeljebb 15 percenként. Blokkoló. */
    fun quickSyncIfDue(ctx: Context) {
        if (!canRead(ctx) || lastFullImport(ctx) == 0L) return
        val p = prefs(ctx)
        val now = System.currentTimeMillis()
        if (now - p.getLong("quick_ts", 0) < QUICK_EVERY) return
        p.edit().putLong("quick_ts", now).apply()
        try {
            val since = Calendar.getInstance().run {
                set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                add(Calendar.MONTH, -1)
                timeInMillis
            }
            import(ctx, since, null)
        } catch (_: Exception) {
        }
    }

    /**
     * Import [since]-től (null = minden). Blokkoló. Visszaad: az üzenetek száma.
     */
    fun import(ctx: Context, since: Long?, progress: ((String) -> Unit)?): Int {
        val app = ctx.applicationContext
        val cr = app.contentResolver
        val canContacts = app.checkSelfPermission(Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED
        val names = HashMap<String, String>()
        fun name(addr: String): String {
            if (addr.isBlank()) return "ismeretlen"
            if (!canContacts) return addr
            return names.getOrPut(addr) {
                try {
                    val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(addr))
                    cr.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { c ->
                        if (c.moveToFirst()) c.getString(0) else null
                    } ?: addr
                } catch (_: Exception) {
                    addr
                }
            }
        }

        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        val byMonth = TreeMap<String, MutableList<Pair<Long, String>>>()
        var count = 0
        fun add(ts: Long, app: String, who: String, body: String) {
            val line = listOf(fmt.format(Date(ts)), app, "sms", who, body)
                .joinToString("\t") { NotificationLogService.clean(it) }
            byMonth.getOrPut(MsgIndex.monthOf(ts)) { ArrayList() }.add(ts to line)
            count++
            if (count % 500 == 0) progress?.invoke("Beolvasva: $count üzenet…")
        }

        // --- SMS ---
        val smsSel = if (since != null) "date >= ?" else null
        val smsArgs = if (since != null) arrayOf(since.toString()) else null
        cr.query(
            Uri.parse("content://sms"), arrayOf("_id", "address", "date", "type", "body"),
            smsSel, smsArgs, "date ASC"
        )?.use { c ->
            // 1 = beérkezett, 2 = elküldött, 3 = piszkozat (kihagyva), minden más: el nem küldött / függő
            val lastFailed = HashMap<String, Long>()
            while (c.moveToNext()) {
                val type = if (c.isNull(3)) 0 else c.getInt(3)
                if (type == 3) continue
                val addr = c.getString(1).orEmpty()
                val body = c.getString(4).orEmpty()
                val ts = c.getLong(2)
                val who = when (type) {
                    1 -> name(addr)
                    2 -> "Én → ${name(addr)}"
                    else -> "Én → ${name(addr)} (el nem küldött)"
                }
                if (type != 1 && type != 2) {
                    // az újrapróbálkozásokból csak egyet tartunk meg (10 percen belül azonos szöveg)
                    val key = "$addr\u0001$body"
                    val prev = lastFailed[key]
                    if (prev != null && ts - prev < 10 * 60_000L) continue
                    lastFailed[key] = ts
                }
                add(ts, "SMS", who, body)
            }
        }

        // --- MMS (a dátum másodpercben van) ---
        val mmsSel = if (since != null) "date >= ?" else null
        val mmsArgs = if (since != null) arrayOf((since / 1000).toString()) else null
        try {
            cr.query(Uri.parse("content://mms"), arrayOf("_id", "date", "msg_box"), mmsSel, mmsArgs, "date ASC")
                ?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getLong(0)
                        val box = c.getInt(2)
                        if (box == 3) continue
                        val text = mmsText(app, id)
                        val out = box != 1
                        val addr = mmsAddr(app, id, if (out) 151 else 137)
                        val who = if (!out) name(addr)
                        else "Én → ${addr.split(", ").joinToString(", ") { name(it) }}" +
                            if (box == 2) "" else " (el nem küldött)"
                        add(c.getLong(1) * 1000, "MMS", who, text)
                    }
                }
        } catch (_: Exception) {
            // néhány gyártónál az MMS-tár nem olvasható – az SMS-ek ettől még bekerülnek
        }

        // --- írás havonta ---
        val p = prefs(app)
        var i = 0
        for ((month, list) in byMonth) {
            i++
            progress?.invoke("Fájlok írása: $i/${byMonth.size} ($month)")
            list.sortBy { it.first }
            val text = list.joinToString(separator = "") { it.second + "\n" }
            val sig = "${text.length}:${text.hashCode()}"
            val key = "sig_$month"
            if (p.getString(key, null) == sig) continue
            if (LogWriter.writeWhole(app, "sms_$month.txt", text, "text/plain")) {
                p.edit().putString(key, sig).apply()
            }
        }
        if (since == null) p.edit().putLong("full_ts", System.currentTimeMillis()).apply()
        return count
    }

    private fun mmsText(ctx: Context, id: Long): String {
        val cr = ctx.contentResolver
        val sb = StringBuilder()
        var media = 0
        cr.query(Uri.parse("content://mms/part"), arrayOf("_id", "ct", "text"), "mid=?", arrayOf(id.toString()), null)
            ?.use { c ->
                while (c.moveToNext()) {
                    val ct = c.getString(1).orEmpty()
                    when {
                        ct == "text/plain" -> {
                            val t = c.getString(2) ?: try {
                                cr.openInputStream(Uri.parse("content://mms/part/${c.getLong(0)}"))
                                    ?.bufferedReader()?.use { it.readText() }
                            } catch (_: Exception) {
                                null
                            }
                            if (!t.isNullOrBlank()) {
                                if (sb.isNotEmpty()) sb.append('\n')
                                sb.append(t)
                            }
                        }
                        ct.startsWith("image/") || ct.startsWith("video/") || ct.startsWith("audio/") -> media++
                    }
                }
            }
        if (media > 0) {
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append("[$media melléklet]")
        }
        return if (sb.isEmpty()) "[MMS]" else sb.toString()
    }

    private fun mmsAddr(ctx: Context, id: Long, type: Int): String {
        val out = ArrayList<String>()
        ctx.contentResolver.query(
            Uri.parse("content://mms/$id/addr"), arrayOf("address"), "type=?", arrayOf(type.toString()), null
        )?.use { c ->
            while (c.moveToNext()) {
                val a = c.getString(0).orEmpty()
                if (a.isNotBlank() && a != "insert-address-token") out.add(a)
            }
        }
        return out.joinToString(", ")
    }

    /** Diagnosztika: hogyan tárolja a rendszer a [word]-öt tartalmazó SMS-eket. Blokkoló. */
    fun diagnose(ctx: Context, word: String): String {
        val cr = ctx.contentResolver
        val sb = StringBuilder()
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        val byType = TreeMap<Int, Int>()
        var total = 0
        cr.query(Uri.parse("content://sms"), arrayOf("type"), null, null, null)?.use { c ->
            while (c.moveToNext()) {
                total++
                val t = if (c.isNull(0)) -1 else c.getInt(0)
                byType[t] = (byType[t] ?: 0) + 1
            }
        }
        sb.append("SMS összesen: $total\n")
        byType.forEach { (t, n) -> sb.append("  típus $t: $n db\n") }
        sb.append("\nTalálatok erre: „$word”\n")
        var hits = 0
        cr.query(
            Uri.parse("content://sms"), arrayOf("date", "type", "status", "address", "body"),
            "body LIKE ?", arrayOf("%$word%"), "date DESC"
        )?.use { c ->
            while (c.moveToNext() && hits < 25) {
                hits++
                val body = c.getString(4).orEmpty().replace('\n', ' ')
                sb.append("${fmt.format(Date(c.getLong(0)))}  típus=${c.getInt(1)} állapot=${c.getInt(2)}  ${c.getString(3)}\n")
                sb.append("   ${body.take(60)}\n")
            }
        }
        if (hits == 0) sb.append("  nincs SMS-találat\n")
        var mms = 0
        try {
            cr.query(Uri.parse("content://mms"), arrayOf("_id"), null, null, null)?.use { mms = it.count }
        } catch (e: Exception) {
            sb.append("MMS-tár nem olvasható: ${e.message}\n")
        }
        sb.append("\nMMS összesen: $mms")
        return sb.toString()
    }
}
