package hu.atria.uzenetnaplo

import android.content.ComponentName
import android.content.Context
import android.provider.Settings

object Prefs {
    const val DEFAULT_MODEL = "claude-sonnet-5"
    private fun sp(ctx: Context) = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun apiKey(ctx: Context): String = sp(ctx).getString("api_key", "").orEmpty()
    fun model(ctx: Context): String =
        sp(ctx).getString("model", "").orEmpty().ifBlank { DEFAULT_MODEL }

    fun save(ctx: Context, key: String, model: String) {
        sp(ctx).edit().putString("api_key", key.trim()).putString("model", model.trim()).apply()
    }

    fun listenerEnabled(ctx: Context): Boolean {
        val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")
            ?: return false
        return flat.split(':').any {
            ComponentName.unflattenFromString(it)?.packageName == ctx.packageName
        }
    }
}
