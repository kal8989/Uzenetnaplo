package hu.atria.uzenetnaplo

import android.content.ComponentName
import android.content.Context
import android.provider.Settings

object Prefs {
    const val DEFAULT_MODEL = "claude-sonnet-5"
    private fun sp(ctx: Context) = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    private fun str(ctx: Context, k: String) = sp(ctx).getString(k, "").orEmpty()
    private fun put(ctx: Context, k: String, v: String) = sp(ctx).edit().putString(k, v).apply()

    fun anthropicKey(ctx: Context) = str(ctx, "api_key")
    fun geminiKey(ctx: Context) = str(ctx, "gemini_key")
    fun setKeys(ctx: Context, anthropic: String, gemini: String) =
        sp(ctx).edit().putString("api_key", anthropic.trim()).putString("gemini_key", gemini.trim()).apply()

    fun model(ctx: Context) = str(ctx, "model").ifBlank { DEFAULT_MODEL }
    fun setModel(ctx: Context, m: String) = put(ctx, "model", m.trim())
    fun customModel(ctx: Context) = str(ctx, "custom_model")
    fun setCustomModel(ctx: Context, m: String) = put(ctx, "custom_model", m.trim())

    /** "dark" | "light" | "system" */
    fun theme(ctx: Context) = str(ctx, "theme").ifBlank { "dark" }
    fun setTheme(ctx: Context, t: String) = put(ctx, "theme", t)

    fun dailyEnabled(ctx: Context) = sp(ctx).getBoolean("daily_on", false)
    fun dailyHour(ctx: Context) = sp(ctx).getInt("daily_h", 6)
    fun dailyMinute(ctx: Context) = sp(ctx).getInt("daily_m", 0)
    fun setDaily(ctx: Context, on: Boolean, h: Int, m: Int) =
        sp(ctx).edit().putBoolean("daily_on", on).putInt("daily_h", h).putInt("daily_m", m).apply()

    fun lastSummary(ctx: Context) = str(ctx, "last_summary")
    fun lastSummaryTime(ctx: Context) = sp(ctx).getLong("last_summary_ts", 0)
    fun setLastSummary(ctx: Context, text: String, ts: Long) =
        sp(ctx).edit().putString("last_summary", text).putLong("last_summary_ts", ts).apply()

    fun lastUpdateCheck(ctx: Context) = sp(ctx).getLong("upd_check", 0)
    fun setLastUpdateCheck(ctx: Context, ts: Long) = sp(ctx).edit().putLong("upd_check", ts).apply()

    /** Gördülő előzménylista (legfrissebb elöl, ismétlődés nélkül). */
    fun history(ctx: Context, key: String): List<String> = try {
        val a = org.json.JSONArray(sp(ctx).getString(key, "[]"))
        (0 until a.length()).map { a.getString(it) }
    } catch (_: Exception) {
        emptyList()
    }

    fun pushHistory(ctx: Context, key: String, value: String, max: Int = 20) {
        val list = listOf(value) + history(ctx, key).filter { it != value }
        val a = org.json.JSONArray()
        list.take(max).forEach { a.put(it) }
        sp(ctx).edit().putString(key, a.toString()).apply()
    }

    fun clearHistory(ctx: Context, key: String) = sp(ctx).edit().remove(key).apply()

    fun listenerEnabled(ctx: Context): Boolean {
        val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")
            ?: return false
        return flat.split(':').any {
            ComponentName.unflattenFromString(it)?.packageName == ctx.packageName
        }
    }
}
