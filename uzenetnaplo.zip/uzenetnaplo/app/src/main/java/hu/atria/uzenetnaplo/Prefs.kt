package hu.atria.uzenetnaplo

import android.content.ComponentName
import android.content.Context
import android.provider.Settings

object Prefs {
    const val DEFAULT_MODEL = "claude-sonnet-5"
    private fun sp(ctx: Context) = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    private fun str(ctx: Context, k: String) = sp(ctx).getString(k, "").orEmpty()
    private fun put(ctx: Context, k: String, v: String) = sp(ctx).edit().putString(k, v).apply()

    fun anthropicKey(ctx: Context) = str(ctx, "api_key")
    fun geminiKey(ctx: Context) = str(ctx, "gemini_key")
    fun setKeys(ctx: Context, anthropic: String, gemini: String) =
        sp(ctx).edit().putString("api_key", anthropic.trim()).putString("gemini_key", gemini.trim()).apply()

    fun model(ctx: Context) = str(ctx, "model").ifBlank { DEFAULT_MODEL }
    fun setModel(ctx: Context, m: String) = put(ctx, "model", m.trim())
    fun customModel(ctx: Context) = str(ctx, "custom_model")
    fun setCustomModel(ctx: Context, m: String) = put(ctx, "custom_model", m.trim())

    /** "dark" | "light" | "system" */
    fun theme(ctx: Context) = str(ctx, "theme").ifBlank { "dark" }
    fun setTheme(ctx: Context, t: String) = put(ctx, "theme", t)

    fun dailyEnabled(ctx: Context) = sp(ctx).getBoolean("daily_on", false)
    fun dailyHour(ctx: Context) = sp(ctx).getInt("daily_h", 6)
    fun dailyMinute(ctx: Context) = sp(ctx).getInt("daily_m", 0)
    fun setDaily(ctx: Context, on: Boolean, h: Int, m: Int) =
        sp(ctx).edit().putBoolean("daily_on", on).putInt("daily_h", h).putInt("daily_m", m).apply()

    fun lastSummary(ctx: Context) = str(ctx, "last_summary")
    fun lastSummaryTime(ctx: Context) = sp(ctx).getLong("last_summary_ts", 0)
    fun setLastSummary(ctx: Context, text: String, ts: Long) =
        sp(ctx).edit().putString("last_summary", text).putLong("last_summary_ts", ts).apply()

    /** Az AI-nak átadható szöveg felső határa karakterben. */
    fun charBudget(ctx: Context) = sp(ctx).getInt("char_budget", 60_000)
    fun setCharBudget(ctx: Context, v: Int) = sp(ctx).edit().putInt("char_budget", v).apply()

    /** Takarékos mód: a Gemini alacsony gondolkodási szinten fut. */
    fun saver(ctx: Context) = sp(ctx).getBoolean("saver", true)
    fun setSaver(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("saver", v).apply()

    /** Megerősítés, ha egy elemzés becsült ára ezt meghaladja (USD). */
    fun confirmOver(ctx: Context) = sp(ctx).getFloat("confirm_over", 0.05f)
    fun setConfirmOver(ctx: Context, v: Float) = sp(ctx).edit().putFloat("confirm_over", v).apply()

    /** Ft/USD árfolyam a kijelzéshez; 0 = csak dollár. */
    fun huf(ctx: Context) = sp(ctx).getInt("huf", 0)
    fun setHuf(ctx: Context, v: Int) = sp(ctx).edit().putInt("huf", v).apply()

    /** Havi költségnapló: kérésszám, tokenek, USD. */
    fun addSpend(ctx: Context, month: String, inTok: Long, outTok: Long, usd: Double) {
        val e = sp(ctx).edit()
        e.putInt("sp_n_$month", sp(ctx).getInt("sp_n_$month", 0) + 1)
        e.putLong("sp_in_$month", sp(ctx).getLong("sp_in_$month", 0) + inTok)
        e.putLong("sp_out_$month", sp(ctx).getLong("sp_out_$month", 0) + outTok)
        e.putFloat("sp_usd_$month", sp(ctx).getFloat("sp_usd_$month", 0f) + usd.toFloat())
        e.apply()
    }

    fun spend(ctx: Context, month: String): Triple<Int, Long, Double> = Triple(
        sp(ctx).getInt("sp_n_$month", 0),
        sp(ctx).getLong("sp_in_$month", 0) + sp(ctx).getLong("sp_out_$month", 0),
        sp(ctx).getFloat("sp_usd_$month", 0f).toDouble(),
    )

    // --- Színátmenetes háttér ---
    fun gradient(ctx: Context) = sp(ctx).getBoolean("grad_on", false)
    fun setGradient(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("grad_on", v).apply()
    fun gradTop(ctx: Context) = sp(ctx).getInt("grad_top", 0)
    fun gradBottom(ctx: Context) = sp(ctx).getInt("grad_bottom", 0)
    fun setGradColors(ctx: Context, top: Int, bottom: Int) =
        sp(ctx).edit().putInt("grad_top", top).putInt("grad_bottom", bottom).apply()

    // --- Hírek ---
    fun newsEnabled(ctx: Context) = sp(ctx).getBoolean("news_on", false)
    fun setNewsEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("news_on", v).apply()
    fun newsInterval(ctx: Context) = sp(ctx).getInt("news_hours", 1)
    fun setNewsInterval(ctx: Context, v: Int) = sp(ctx).edit().putInt("news_hours", v).apply()
    fun newsFeeds(ctx: Context) = str(ctx, "news_feeds").ifBlank { News.DEFAULT_FEEDS }
    fun setNewsFeeds(ctx: Context, v: String) = put(ctx, "news_feeds", v)
    fun newsModel(ctx: Context) = str(ctx, "news_model").ifBlank { "gemini-3.5-flash-lite" }
    fun setNewsModel(ctx: Context, v: String) = put(ctx, "news_model", v)
    /** Külön (pl. ingyenes) kulcs a hírekhez; üres = a szokásos kulcs. */
    fun newsKey(ctx: Context) = str(ctx, "news_key")
    fun setNewsKey(ctx: Context, v: String) = put(ctx, "news_key", v.trim())
    fun newsTs(ctx: Context) = sp(ctx).getLong("news_ts", 0)
    fun setNewsTs(ctx: Context, v: Long) = sp(ctx).edit().putLong("news_ts", v).apply()

    fun lastUpdateCheck(ctx: Context) = sp(ctx).getLong("upd_check", 0)
    fun setLastUpdateCheck(ctx: Context, ts: Long) = sp(ctx).edit().putLong("upd_check", ts).apply()

    /** Gördülő előzménylista (legfrissebb elöl, ismétlődés nélkül). */
    fun history(ctx: Context, key: String): List<String> = try {
        val a = org.json.JSONArray(sp(ctx).getString(key, "[]"))
        (0 until a.length()).map { a.getString(it) }
    } catch (_: Exception) {
        emptyList()
    }

    fun pushHistory(ctx: Context, key: String, value: String, max: Int = 20) {
        val list = listOf(value) + history(ctx, key).filter { it != value }
        val a = org.json.JSONArray()
        list.take(max).forEach { a.put(it) }
        sp(ctx).edit().putString(key, a.toString()).apply()
    }

    fun clearHistory(ctx: Context, key: String) = sp(ctx).edit().remove(key).apply()

    fun listenerEnabled(ctx: Context): Boolean {
        val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")
            ?: return false
        return flat.split(':').any {
            ComponentName.unflattenFromString(it)?.packageName == ctx.packageName
        }
    }
}
