package hu.atria.uzenetnaplo

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MailAccount(val address: String, val password: String, val enabled: Boolean) {
    fun json(): JSONObject = JSONObject().put("a", address).put("p", password).put("on", enabled)
}

class MailItem(
    val account: String,
    val uid: Long,
    val ts: Long,
    val from: String,
    val to: String,
    val subject: String,
) {
    @Volatile var body: String? = null
}

/** Élő Gmail-keresés IMAP-on: a levelek nem kerülnek az adatbázisba. */
object MailStore {
    private const val HOST = "imap.gmail.com"
    private const val PORT = 993
    private const val KEY = "mail_accounts"
    const val PER_ACCOUNT = 200

    private val clients = HashMap<String, ImapClient>()
    private val dayFmt = SimpleDateFormat("yyyy/MM/dd", Locale.US)

    fun accounts(ctx: Context): List<MailAccount> = try {
        val a = JSONArray(ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).getString(KEY, "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            MailAccount(o.getString("a"), o.getString("p"), o.optBoolean("on", true))
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveAccounts(ctx: Context, list: List<MailAccount>) {
        val a = JSONArray()
        list.forEach { a.put(it.json()) }
        ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply()
        closeAll()
    }

    fun enabledAccounts(ctx: Context) = accounts(ctx).filter { it.enabled && it.password.isNotBlank() }

    fun buildQuery(terms: List<String>, from: Long?, to: Long?): String {
        val sb = StringBuilder()
        terms.forEach { sb.append(it).append(' ') }
        sb.append("-category:promotions -category:social")
        from?.let { sb.append(" after:").append(dayFmt.format(Date(it - 86_400_000L))) }
        to?.let { sb.append(" before:").append(dayFmt.format(Date(it + 86_400_000L))) }
        return sb.toString().trim()
    }

    private fun client(acc: MailAccount): ImapClient {
        val c = clients[acc.address]
        if (c != null && c.isOpen) return c
        c?.close()
        val n = ImapClient(HOST, PORT, acc.address, acc.password)
        n.connect()
        clients[acc.address] = n
        return n
    }

    fun closeAll() {
        synchronized(clients) {
            clients.values.forEach { it.close() }
            clients.clear()
        }
    }

    class SearchResult(val items: List<MailItem>, val errors: List<String>)

    /** Blokkoló keresés minden engedélyezett fiókban, párhuzamosan. */
    fun search(ctx: Context, terms: List<String>, from: Long?, to: Long?): SearchResult {
        val accs = enabledAccounts(ctx)
        if (accs.isEmpty()) return SearchResult(emptyList(), emptyList())
        val query = buildQuery(terms, from, to)
        val pool = Executors.newFixedThreadPool(minOf(accs.size, 5))
        try {
            val tasks = accs.map { acc ->
                Callable {
                    try {
                        val c = synchronized(clients) { client(acc) }
                        synchronized(c) {
                            c.select(c.findAllMail())
                            val uids = c.searchRaw(query)
                            val take = uids.takeLast(PER_ACCOUNT)
                            val heads = c.fetchHeaders(take)
                            heads.map {
                                MailItem(acc.address, it.uid, it.ts, it.from, it.to, it.subject)
                            } to null as String?
                        }
                    } catch (e: Exception) {
                        synchronized(clients) { clients.remove(acc.address)?.close() }
                        emptyList<MailItem>() to "${acc.address}: ${e.message}"
                    }
                }
            }
            val out = ArrayList<MailItem>()
            val errs = ArrayList<String>()
            for (f in pool.invokeAll(tasks, 120, TimeUnit.SECONDS)) {
                try {
                    val (items, err) = f.get()
                    out.addAll(items)
                    err?.let { errs.add(it) }
                } catch (e: Exception) {
                    errs.add(e.message ?: "időtúllépés")
                }
            }
            out.sortByDescending { it.ts }
            return SearchResult(out, errs)
        } finally {
            pool.shutdownNow()
        }
    }

    /** Egy levél szövege (gyorsítótárazva). Blokkoló. */
    fun body(ctx: Context, item: MailItem): String {
        item.body?.let { return it }
        val acc = accounts(ctx).firstOrNull { it.address == item.account }
            ?: throw IllegalStateException("ismeretlen fiók: ${item.account}")
        val c = synchronized(clients) { client(acc) }
        val text = synchronized(c) {
            c.select(c.findAllMail())
            c.fetchBody(item.uid)
        }
        item.body = text
        return text
    }

    /** Kapcsolatpróba a beállításokhoz. Blokkoló. */
    fun test(acc: MailAccount): String = try {
        ImapClient(HOST, PORT, acc.address, acc.password).use { c ->
            c.connect()
            c.select(c.findAllMail())
            "Rendben – a fiók elérhető."
        }
    } catch (e: Exception) {
        "Hiba: ${e.message}"
    }
}
