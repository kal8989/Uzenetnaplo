# Üzenetnapló (Android)

Minden, az értesítési sávban megjelenő üzenetet (WhatsApp, Messenger, Viber, SMS, e-mail,
banki app stb.) sorszerűen szövegfájlba ír.

## Nézegető (2.0)

Az ikon a kereshető üzenetlistát nyitja meg: időszak (Ma, Tegnap, 7 nap, 30 nap, Mind, Egyéni),
alkalmazás, ékezetfüggetlen keresés. Alatta AI-elemzés a szűrt üzenetekről (Anthropic API,
saját kulccsal). A ⚙ gomb a beállításokhoz visz (naplózás, API-kulcs, modell).

## Kimenet

A kiválasztott mappában havi fájlok: `uzenetek_2026-09.txt`, UTF-8, soronként egy üzenet,
tabulátorral tagolva:

    dátum idő   app neve   csomagnév   beszélgetés / feladó   szöveg

A többsoros üzenetek sortörései ` ⏎ ` jelként kerülnek a sorba. A fájl Excelbe, QGIS-be,
Pythonba közvetlenül betölthető (TSV).

## APK készítése (Android Studio nélkül)

1. Új GitHub-repó, ebbe a mappa teljes tartalma (a `.github` mappával együtt).
2. A feltöltés után az **Actions** fül elindítja a fordítást (~4–6 perc).
3. Kész APK: **Releases** oldal → `uzenetnaplo.apk` (telefonról is letölthető).

## Telepítés és beállítás a telefonon

1. APK megnyitása → „Ismeretlen forrás” engedélyezése a böngészőnek/fájlkezelőnek.
2. **Android 13+:** az értesítés-hozzáférés elsőre szürke lehet („korlátozott beállítás”).
   Ilyenkor: Beállítások → Alkalmazások → Üzenetnapló → jobb felső ⋮ →
   **Korlátozott beállítások engedélyezése**, majd vissza az apphoz.
3. Az appban sorban a három gomb:
   1. Értesítés-hozzáférés megadása
   2. Célmappa kiválasztása (pl. Dokumentumok/Uzenetnaplo – új mappát is lehet létrehozni)
   3. Akkumulátor-optimalizálás kikapcsolása
4. „Tesztbejegyzés írása” → a lista alján meg kell jelennie.

Gyártói plusz (Xiaomi, Huawei, Samsung): az app beállításainál érdemes az
„Automatikus indítás” engedélyezése és a „Nem korlátozott” akkumulátorhasználat is.

## Korlátok

- Csak az kerül be, ami az értesítésben megjelenik; a telefonon már elolvasott,
  értesítést nem kapó üzenetek nem.
- Az appok szövegét csonkolhatja a rendszer; a csoportos összesítő értesítéseket az app kihagyja.
- Ha egy app a lezárt képernyőn elrejti a tartalmat, a szöveg üres lehet.
- Duplikátumszűrés: az utolsó 3000 üzenet ujjlenyomata alapján (újraindítás után is megmarad).
- Folyamatban lévő értesítések (zenelejátszás, letöltés, navigáció) kimaradnak.
- Ha még nincs mappa kiválasztva, az üzenetek belső tárban gyűlnek, és a mappa
  kiválasztásakor átkerülnek.
