# Üzenetnapló (Android)

Minden, az értesítési sávban megjelenő üzenetet (WhatsApp, Messenger, Viber, SMS, e-mail,
banki app stb.) sorszerűen szövegfájlba ír.

## Reggeli összefoglaló levelekkel (10.x)

- az összefoglaló az elmúlt 24 óra Gmail-leveleit is figyelembe veszi: a beérkezetteket és az elküldötteket is
- legfeljebb 30 levél, levelenként 2500 karakterig; a ⚙ → Reggeli összefoglaló alatt kikapcsolható

## Lépésszám és elrendezés (9.x)

- a szűrősorban: helyi hőmérséklet, mai lépésszám és távolság, tegnapi összesítés
- lépésszám a telefon beépített számlálójából (⚙ → Lépésszám és hőmérséklet), állítható lépéshosszal
- az AI-modell választója a beállítások tetején
- keskenyebb alkalmazásgomb

## Időjárás (8.x)

- „Időjárás” gomb: több város, mai nap részletesen + 5 nap, Open-Meteo (ingyenes, kulcs nélkül)
- a városra koppintva az AccuWeather 30 napos oldala nyílik (saját link), egyébként keresés
- óránként a hírekkel együtt frissül

## Kezelés (7.x)

- alkalmazásszűrés jelölőnégyzetekkel (több app egyszerre)
- lefelé húzás a listán: frissítés és a keresőmező ürítése
- színátmenetes háttér: a beállításokban két kockával állítható kezdő- és zárószín

## Hírek és költségkorlátok (6.x)

- „Hírek” gomb: RSS-ből (Telex, 444, Index, 24.hu, Portfolio – a lista szerkeszthető) óránként
  frissülő, AI-val válogatott összeállítás, sport nélkül, kattintható linkekkel
- a hírekhez külön modell és külön (akár ingyenes) API-kulcs adható meg
- minden elemzés után látszik a tokenszám és az ár, a ⚙-ben havi összesítővel
- állítható elemzési keret (alapból 60 ezer karakter), megerősítés drága kérés előtt
- takarékos mód: a Gemini alacsony gondolkodási szinten fut

## Élő Gmail-keresés (5.x)

- ⚙ → E-mail-fiókok: több Gmail-fiók, fiókonként alkalmazásjelszóval (IMAP)
- a főképernyőn „E-mailek keresése a Gmail-fiókokban” kapcsoló; a levelek nem kerülnek adatbázisba,
  a keresés élőben fut a Gmail keresőnyelvén (`-category:promotions -category:social` + időszak)
- fiókonként a legfrissebb 200 találat, koppintásra a teljes levél (idézett előzmény nélkül)
- bekapcsolva a Gmail/Outlook-értesítések rejtve, hogy ne duplázódjanak
- AI-elemzésnél a legfrissebb 40 levél szövege is bekerül (levelenként 3000 karakterig)

## SMS-archívum és nagy adatmennyiség (4.x)

- ⚙ → SMS-archívum: a rendszer SMS/MMS-tárának (Textra, Samsung Üzenetek) teljes importja havi `sms_ÉÉÉÉ-HH.txt` fájlokba, névjegynevekkel
- utána 15 percenként automatikus frissítés az előző hónap elejétől
- SQLite + FTS4 kereső-index: évek, több százezer üzenet mellett is gyors keresés és lapozás
- az SMS-appok értesítései rejtve, ha ugyanaz az üzenet az SMS-archívumban is megvan
- új időszak: „1 év”

## Újdonságok (3.x)

- Sötét / világos / rendszer szerinti megjelenés (⚙ → Megjelenés)
- Modellválasztás a főképernyőn: Claude Opus 5, Sonnet 5, Haiku 4.5, Gemini 3.1 Pro, 3.8 Flash, 3.5 Flash-Lite, egyéni azonosító
- Reggeli összefoglaló megadott időpontban (alapból 06:00), értesítésként és `osszefoglalo_ÉÉÉÉ-HH-NN.md` fájlként
- Frissítés az appból (⚙ → Frissítés), automatikus figyelmeztetés új verzióról

## Nézegető (2.0)

Az ikon a kereshető üzenetlistát nyitja meg: időszak (Ma, Tegnap, 7 nap, 30 nap, Mind, Egyéni),
alkalmazás, ékezetfüggetlen keresés. Alatta AI-elemzés a szűrt üzenetekről (Anthropic API,
saját kulccsal). A ⚙ gomb a beállításokhoz visz (naplózás, API-kulcs, modell).

## Kimenet

A kiválasztott mappában havi fájlok: `uzenetek_2026-09.txt`, UTF-8, soronként egy üzenet,
tabulátorral tagolva:

    dátum idő   app neve   csomagnév   beszélgetés / feladó   szöveg

A többsoros üzenetek sortörései ` ⏎ ` jelként kerülnek a sorba. A fájl Excelbe, QGIS-be,
Pythonba közvetlenül betölthető (TSV).

## APK készítése (Android Studio nélkül)

1. Új GitHub-repó, ebbe a mappa teljes tartalma (a `.github` mappával együtt).
2. A feltöltés után az **Actions** fül elindítja a fordítást (~4–6 perc).
3. Kész APK: **Releases** oldal → `uzenetnaplo.apk` (telefonról is letölthető).

## Telepítés és beállítás a telefonon

1. APK megnyitása → „Ismeretlen forrás” engedélyezése a böngészőnek/fájlkezelőnek.
2. **Android 13+:** az értesítés-hozzáférés elsőre szürke lehet („korlátozott beállítás”).
   Ilyenkor: Beállítások → Alkalmazások → Üzenetnapló → jobb felső ⋮ →
   **Korlátozott beállítások engedélyezése**, majd vissza az apphoz.
3. Az appban sorban a három gomb:
   1. Értesítés-hozzáférés megadása
   2. Célmappa kiválasztása (pl. Dokumentumok/Uzenetnaplo – új mappát is lehet létrehozni)
   3. Akkumulátor-optimalizálás kikapcsolása
4. „Tesztbejegyzés írása” → a lista alján meg kell jelennie.

Gyártói plusz (Xiaomi, Huawei, Samsung): az app beállításainál érdemes az
„Automatikus indítás” engedélyezése és a „Nem korlátozott” akkumulátorhasználat is.

## Korlátok

- Csak az kerül be, ami az értesítésben megjelenik; a telefonon már elolvasott,
  értesítést nem kapó üzenetek nem.
- Az appok szövegét csonkolhatja a rendszer; a csoportos összesítő értesítéseket az app kihagyja.
- Ha egy app a lezárt képernyőn elrejti a tartalmat, a szöveg üres lehet.
- Duplikátumszűrés: az utolsó 3000 üzenet ujjlenyomata alapján (újraindítás után is megmarad).
- Folyamatban lévő értesítések (zenelejátszás, letöltés, navigáció) kimaradnak.
- Ha még nincs mappa kiválasztva, az üzenetek belső tárban gyűlnek, és a mappa
  kiválasztásakor átkerülnek.
